# PreQual Packaging: Active: Carton of 50 vials(50 doses) [Dimensions: 5.0 x 9.5 x 18.5 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Active: Carton of 50 vials(50 doses) [Dimensions: 5.0 x 9.5 x 18.5 cm]**

## Example Binary: PreQual Packaging: Active: Carton of 50 vials(50 doses) [Dimensions: 5.0 x 9.5 x 18.5 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaepUAC"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "17.58",
  "description": "Active: Carton of 50 vials(50 doses) [Dimensions: 5.0 x 9.5 x 18.5 cm]",
  "height": "9.5",
  "length": "5.0",
  "width": "18.5",
  "primaryContainers": "50"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
