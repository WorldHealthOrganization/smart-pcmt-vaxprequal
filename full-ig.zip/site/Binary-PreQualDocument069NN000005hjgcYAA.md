# PreQual Document: Container Photo (Bigger Higher Resolution)-pq_15_TT_10dose_BioFarma_carton%2Bvial_image - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo (Bigger Higher Resolution)-pq_15_TT_10dose_BioFarma_carton%2Bvial_image**

## Example Binary: PreQual Document: Container Photo (Bigger Higher Resolution)-pq_15_TT_10dose_BioFarma_carton%2Bvial_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005hjgcYAA"
  },
  "documentName": "Container Photo (Bigger Higher Resolution)-pq_15_TT_10dose_BioFarma_carton%2Bvial_image",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005yT18YAE",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
