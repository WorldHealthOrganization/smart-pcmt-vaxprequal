# PreQual Document: PQ_354_Td_20dose_BiolE_vial_image - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: PQ_354_Td_20dose_BiolE_vial_image**

## Example Binary: PreQual Document: PQ_354_Td_20dose_BiolE_vial_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005lDJwYAM"
  },
  "documentName": "PQ_354_Td_20dose_BiolE_vial_image",
  "documentType": "PhotoMainImage",
  "versionId": "068NN0000061z64YAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
