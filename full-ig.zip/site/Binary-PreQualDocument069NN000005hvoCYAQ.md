# PreQual Document: Container Photo-pq_17_TT_1dose_BioFarma_Unijet-pouch_image - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_17_TT_1dose_BioFarma_Unijet-pouch_image**

## Example Binary: PreQual Document: Container Photo-pq_17_TT_1dose_BioFarma_Unijet-pouch_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005hvoCYAQ"
  },
  "documentName": "Container Photo-pq_17_TT_1dose_BioFarma_Unijet-pouch_image",
  "documentType": "Photo",
  "versionId": "068NN000005yfBwYAI",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
