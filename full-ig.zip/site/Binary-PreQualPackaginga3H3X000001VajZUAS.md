# PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials/ 24000 doses)[Dimensions: 58 x 46.5 x 37.5 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials/ 24000 doses)[Dimensions: 58 x 46.5 x 37.5 cm]**

## Example Binary: PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials/ 24000 doses)[Dimensions: 58 x 46.5 x 37.5 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VajZUAS"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Box of 24 cartons of 50 vials (1200 vials/ 24000 doses)[Dimensions: 58 x 46.5 x 37.5 cm]",
  "volume": "58 x 46.5 x 37.5 cm",
  "totalDoses": "24000",
  "totalContainers": "1200"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
