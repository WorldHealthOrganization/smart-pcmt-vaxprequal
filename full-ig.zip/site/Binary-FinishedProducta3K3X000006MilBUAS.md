# PreQual Product: JEEV® (6µg) - JE - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Product: JEEV® (6µg) - JE**

## Example Binary: PreQual Product: JEEV® (6µg) - JE

This content is an example of the [WHO Vaccine PreQual DB - Finished Vaccine Products](StructureDefinition-FinishedVaccineProducts.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts",
  "productType": "FinishedVaccineProduct",
  "dateOfPrequal": "2013-07-12",
  "assessmentProcedure": "PrequalificationStandard",
  "status": "Prequalified",
  "pharmaceuticalForm": "LiquidReadytouse",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 1,
  "productId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3K3X000006MilBUAS"
  },
  "productName": "FVP-P-263",
  "vaccineFullName": "Japanese encephalitis vaccine (inactivated) for human use",
  "vaccineAbbreviatedName": "JE",
  "vaccineCommercialName": "JEEV® (6µg)",
  "vaccineTypeId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3S3X000003cSpWUAU"
  },
  "routeOfAdministration": "Intramuscular",
  "vialMonitor": "Type 14",
  "applicantId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X00003cPkfbQAC"
  },
  "applicantName": "Biological E. Limited",
  "nraId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p4fQAA"
  },
  "nraName": "Central Drugs Standard Control Organization (CDSCO)",
  "nraCountry": "India",
  "shelfLife": "36 months",
  "storageTemperature": "2 - 8°C",
  "lastPublishingDate": "2024-09-10",
  "publishingRemarks": "June 2014: based on review of stability data a change in shelf life from 24 to 36 months at 2-8°C and a change from VVM type 7 to VVM type 14 was approved.June 2014: Updated product insert and VPSAR refer to additional indication for 12-35 month old infants. In that age range the dose is 0.25mL. For paediatric use this presentation of the vaccine (6 mcg/0.5mL) îs a two-dose preservative free presentation and the issues of programmatic readiness for use of that presentation are described in the VPSAR.  In July 2016 a single dose vial presentation of a formulation (3 mcg/0.5mL dose) was prequalified for paediatric use.  [link above in \"other presentations of this vaccine\"]",
  "manufacturerReference": {
    "reference": "Organization/Manufacturer0013X00003cPkfbQAC"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holder0013X0000498p4fQAA"
  },
  "manufacturerLM": {
    "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer/PreQualManufacturer0013X00003cPkfbQAC"
  },
  "nraLM": {
    "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA/PreQualNRA0013X0000498p4fQAA"
  },
  "vaccineLM": {
    "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine/PreQualVaccinea3S3X000003cSpWUAU"
  },
  "packagingLM": [
    {
      "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging/PreQualPackaginga3H3X000001VaiXUAS"
    }
  ],
  "documentLM": [
    {
      "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail/PreQualDocument069NN000005j9FaYAI"
    }
  ],
  "siteLM": [
    {
      "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail/PreQualSite0013X00003cPkfbQAC"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
