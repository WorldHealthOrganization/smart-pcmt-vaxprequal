# PreQual Packaging: Carton of 10 ampoules (50 doses) [Dimensions: 9.0 x 3.5 x 9.5 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Carton of 10 ampoules (50 doses) [Dimensions: 9.0 x 3.5 x 9.5 cm]**

## Example Binary: PreQual Packaging: Carton of 10 ampoules (50 doses) [Dimensions: 9.0 x 3.5 x 9.5 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VajjUAC"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "5.99",
  "description": "Carton of 10 ampoules (50 doses) [Dimensions: 9.0 x 3.5 x 9.5 cm]",
  "height": "3.5",
  "length": "9.0",
  "width": "9.5",
  "primaryContainers": "10"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
