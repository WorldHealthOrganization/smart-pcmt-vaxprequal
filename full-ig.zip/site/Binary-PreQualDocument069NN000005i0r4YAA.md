# PreQual Document: pq_21_YFV_10doses_Bio-Manguinhos_carton%2Bvials_image_580 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: pq_21_YFV_10doses_Bio-Manguinhos_carton%2Bvials_image_580**

## Example Binary: PreQual Document: pq_21_YFV_10doses_Bio-Manguinhos_carton%2Bvials_image_580

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i0r4YAA"
  },
  "documentName": "pq_21_YFV_10doses_Bio-Manguinhos_carton%2Bvials_image_580",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005ykDDYAY",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
