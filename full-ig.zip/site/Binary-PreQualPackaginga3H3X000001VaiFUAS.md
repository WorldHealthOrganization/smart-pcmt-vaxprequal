# PreQual Packaging: Carton of 50 vials (active)(500 doses) [dimensions 18.5x9.5x6.0] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Carton of 50 vials (active)(500 doses) [dimensions 18.5x9.5x6.0]**

## Example Binary: PreQual Packaging: Carton of 50 vials (active)(500 doses) [dimensions 18.5x9.5x6.0]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaiFUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "2.11",
  "description": "Carton of 50 vials (active)(500 doses) [dimensions 18.5x9.5x6.0]",
  "height": "9.5",
  "length": "18.5",
  "width": "6.0",
  "primaryContainers": "50"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
