# PreQual Packaging: Carton of 10 vials (100 doses)[Dimensions: 5.0 x 13.2 x 5.7 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Carton of 10 vials (100 doses)[Dimensions: 5.0 x 13.2 x 5.7 cm]**

## Example Binary: PreQual Packaging: Carton of 10 vials (100 doses)[Dimensions: 5.0 x 13.2 x 5.7 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VafRUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "3.76",
  "description": "Carton of  10 vials (100 doses)[Dimensions: 5.0 x 13.2 x 5.7 cm]",
  "height": "13.2",
  "length": "5.0",
  "width": "5.7",
  "primaryContainers": "10"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
