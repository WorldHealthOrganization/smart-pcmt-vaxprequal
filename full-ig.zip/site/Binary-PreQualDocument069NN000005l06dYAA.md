# PreQual Document: Package Insert-pq_330_331_Rotavirus_SII_PI-PAHO-2021 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Package Insert-pq_330_331_Rotavirus_SII_PI-PAHO-2021**

## Example Binary: PreQual Document: Package Insert-pq_330_331_Rotavirus_SII_PI-PAHO-2021

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005l06dYAA"
  },
  "documentName": "Package Insert-pq_330_331_Rotavirus_SII_PI-PAHO-2021",
  "documentType": "ProductInsert",
  "versionId": "068NN0000061lw0YAA",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
