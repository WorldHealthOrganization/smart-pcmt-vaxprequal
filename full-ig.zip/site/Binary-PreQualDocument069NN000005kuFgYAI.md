# PreQual Document: pq_307_IPV_1dose_SIIPL_vial_image-2021 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: pq_307_IPV_1dose_SIIPL_vial_image-2021**

## Example Binary: PreQual Document: pq_307_IPV_1dose_SIIPL_vial_image-2021

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005kuFgYAI"
  },
  "documentName": "pq_307_IPV_1dose_SIIPL_vial_image-2021",
  "documentType": "PhotoMainImage",
  "versionId": "068NN0000061g8GYAQ",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
