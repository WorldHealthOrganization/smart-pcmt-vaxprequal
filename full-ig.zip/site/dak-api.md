# DAK API Documentation Hub - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* **DAK API Documentation Hub**

## DAK API Documentation Hub

# DAK API Documentation Hub

This page provides access to Data Access Kit (DAK) API documentation and schemas.

## Table of Contents

1. [DAK API Documentation Hub](#dak-api-documentation-hub)

### API Enumeration Endpoints

These endpoints provide lists of all available schemas and vocabularies of each type:

#### ValueSets.schema.json

Enumeration of all available ValueSet schemas

##### Available Endpoints:

* [ValueSet-PreQualProductIds.schema.json](schemas/ValueSet-PreQualProductIds.schema.json) - JSON Schema for WHO PreQualificaiton Vaccine Product Ids Schema
* [ValueSet-PreQualProductIds.jsonld](ValueSet-PreQualProductIds.jsonld) - JSON-LD vocabulary for WHO PreQualificaiton Vaccine Product Ids Schema
* [ValueSet-PreQualPresentation.schema.json](schemas/ValueSet-PreQualPresentation.schema.json) - JSON Schema for WHO PreQualificaiton Presentation Schema
* [ValueSet-PreQualPresentation.jsonld](ValueSet-PreQualPresentation.jsonld) - JSON-LD vocabulary for WHO PreQualificaiton Presentation Schema
* [ValueSet-PreQualVaccineType.schema.json](schemas/ValueSet-PreQualVaccineType.schema.json) - JSON Schema for WHO PreQualificaiton VaccineType Schema
* [ValueSet-PreQualVaccineType.jsonld](ValueSet-PreQualVaccineType.jsonld) - JSON-LD vocabulary for WHO PreQualificaiton VaccineType Schema
* [ValueSet-PreQualDatabaseMetadata.schema.json](schemas/ValueSet-PreQualDatabaseMetadata.schema.json) - JSON Schema for WHO PreQualification Database Metadata Schema
* [ValueSet-PreQualDatabaseMetadata.jsonld](ValueSet-PreQualDatabaseMetadata.jsonld) - JSON-LD vocabulary for WHO PreQualification Database Metadata Schema

#### LogicalModels.schema.json

Enumeration of all available Logical Model schemas

##### Available Endpoints:

* [StructureDefinition-PreQualDocumentDetail.schema.json](schemas/StructureDefinition-PreQualDocumentDetail.schema.json) - JSON Schema for WHO PreQual Document Detail
* [StructureDefinition-PreQualNRA.schema.json](schemas/StructureDefinition-PreQualNRA.schema.json) - JSON Schema for WHO PreQual NRA
* [StructureDefinition-PreQualVaccine.schema.json](schemas/StructureDefinition-PreQualVaccine.schema.json) - JSON Schema for WHO PreQual Vaccine
* [StructureDefinition-PreQualSiteDetail.schema.json](schemas/StructureDefinition-PreQualSiteDetail.schema.json) - JSON Schema for WHO PreQual Site Detail
* [StructureDefinition-PreQualProductPackaging.schema.json](schemas/StructureDefinition-PreQualProductPackaging.schema.json) - JSON Schema for WHO PreQual Product Packaging
* [StructureDefinition-FinishedVaccineProducts.schema.json](schemas/StructureDefinition-FinishedVaccineProducts.schema.json) - JSON Schema for WHO Vaccine PreQual DB - Finished Vaccine Products
* [StructureDefinition-PreQualManufacturer.schema.json](schemas/StructureDefinition-PreQualManufacturer.schema.json) - JSON Schema for WHO PreQual Manufacturer
* [StructureDefinition-PreQualBulkSupplier.schema.json](schemas/StructureDefinition-PreQualBulkSupplier.schema.json) - JSON Schema for WHO PreQual Bulk Supplier
* [StructureDefinition-PreQualProductIngredient.schema.json](schemas/StructureDefinition-PreQualProductIngredient.schema.json) - JSON Schema for WHO PreQual Product Ingredient

### ValueSet Schemas (4 available)

JSON Schema definitions for FHIR ValueSets, providing structured enumeration of allowed code values:

#### WHO PreQualificaiton Vaccine Product Ids Schema

JSON Schema for WHO PreQualificaiton Vaccine Product Ids ValueSet codes. Generated from FHIR expansions using IRI format.

[🩺 FHIR](ValueSet-PreQualProductIds.md)
[📄 JSON Schema](schemas/ValueSet-PreQualProductIds.schema.json)
[🏷️ Displays](schemas/ValueSet-PreQualProductIds.displays.json)
[🗂️ JSON-LD](ValueSet-PreQualProductIds.jsonld)
[🔗 OpenAPI](schemas/ValueSet-PreQualProductIds.openapi.json)

#### WHO PreQualificaiton Presentation Schema

JSON Schema for WHO PreQualificaiton Presentation ValueSet codes. Generated from FHIR expansions using IRI format.

[🩺 FHIR](ValueSet-PreQualPresentation.md)
[📄 JSON Schema](schemas/ValueSet-PreQualPresentation.schema.json)
[🏷️ Displays](schemas/ValueSet-PreQualPresentation.displays.json)
[🗂️ JSON-LD](ValueSet-PreQualPresentation.jsonld)
[🔗 OpenAPI](schemas/ValueSet-PreQualPresentation.openapi.json)

#### WHO PreQualificaiton VaccineType Schema

JSON Schema for WHO PreQualificaiton VaccineType ValueSet codes. Generated from FHIR expansions using IRI format.

[🩺 FHIR](ValueSet-PreQualVaccineType.md)
[📄 JSON Schema](schemas/ValueSet-PreQualVaccineType.schema.json)
[🏷️ Displays](schemas/ValueSet-PreQualVaccineType.displays.json)
[🗂️ JSON-LD](ValueSet-PreQualVaccineType.jsonld)
[🔗 OpenAPI](schemas/ValueSet-PreQualVaccineType.openapi.json)

#### WHO PreQualification Database Metadata Schema

JSON Schema for WHO PreQualification Database Metadata ValueSet codes. Generated from FHIR expansions using IRI format.

[🩺 FHIR](ValueSet-PreQualDatabaseMetadata.md)
[📄 JSON Schema](schemas/ValueSet-PreQualDatabaseMetadata.schema.json)
[🏷️ Displays](schemas/ValueSet-PreQualDatabaseMetadata.displays.json)
[🗂️ JSON-LD](ValueSet-PreQualDatabaseMetadata.jsonld)
[🔗 OpenAPI](schemas/ValueSet-PreQualDatabaseMetadata.openapi.json)

### Logical Model Schemas (9 available)

JSON Schema definitions for FHIR Logical Models, defining structured data elements and their relationships:

#### WHO PreQual Document Detail

Logical model for document details from the WHO PreQual API (DocumentDetails).

[🩺 FHIR](StructureDefinition-PreQualDocumentDetail.md)
[📄 JSON Schema](schemas/StructureDefinition-PreQualDocumentDetail.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualDocumentDetail.openapi.json)

#### WHO PreQual NRA

Logical model for the responsible National Regulatory Authority (NRA) from the WHO PreQual API (ProductDetails.NRADetails).

[🩺 FHIR](StructureDefinition-PreQualNRA.md)
[📄 JSON Schema](schemas/StructureDefinition-PreQualNRA.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualNRA.openapi.json)

#### WHO PreQual Vaccine

Logical model for the vaccine type details from the WHO PreQual API (ProductDetails.VaccineDetails). Contains only vaccine-type-level fields that are stable across products. Product-specific fields (CommercialName, RouteOfAdministration) remain on FinishedVaccineProducts.

[🩺 FHIR](StructureDefinition-PreQualVaccine.md)
[📄 JSON Schema](schemas/StructureDefinition-PreQualVaccine.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualVaccine.openapi.json)

#### WHO PreQual Site Detail

Logical model for manufacturing site details from the WHO PreQual API (SiteDetails).

[🩺 FHIR](StructureDefinition-PreQualSiteDetail.md)
[📄 JSON Schema](schemas/StructureDefinition-PreQualSiteDetail.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualSiteDetail.openapi.json)

#### WHO PreQual Product Packaging

Logical model for product packaging details from the WHO PreQual API (ProductPackaging).

[🩺 FHIR](StructureDefinition-PreQualProductPackaging.md)
[📄 JSON Schema](schemas/StructureDefinition-PreQualProductPackaging.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualProductPackaging.openapi.json)

#### WHO Vaccine PreQual DB - Finished Vaccine Products

WHO Vaccine PreQual DB - Finished Vaccine Products. Logical model for the WHO PreQual DB as provided by the backend API at: https://extranet.who.int/prequal/vaccines/prequalified-vaccines This model provides authoritative vaccine product IDs and a richer data structure compared to the CSV export. Sub-objects with Identification.Id are modeled as separate logical models and linked via references. Key fields from the API (FinishedVaccineProducts): ProductDetails.Identification.Id - Vaccine Product ID (authoritative) ProductDetails.Identification.Name - Product reference name (e.g. FVP-P-447) ProductDetails.Type - Product type code (e.g. Finished Vaccine Product) ProductDetails.DateOfPreQualifiedAcceptance - Date of prequalification ProductDetails.AssessmentProcedure - Assessment procedure code ProductDetails.ApplicantOrganization - Manufacturer/applicant with ID, name, address ProductDetails.Presentation - Presentation form (Vial, Ampoule, etc.) ProductDetails.PharmaceuticalForm - Pharmaceutical form details ProductDetails.DosageDetails.NoOfDosagesPerPrimaryContainer - Number of doses ProductDetails.NRADetails - Responsible NRA with ID, name, address ProductDetails.VaccineDetails - Vaccine type with full, abbreviated, and commercial names ProductDetails.StorageDetails - Storage temperature and shelf life ProductDetails.Status - Prequalification status code

[🩺 FHIR](StructureDefinition-FinishedVaccineProducts.md)
[📄 JSON Schema](schemas/StructureDefinition-FinishedVaccineProducts.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-FinishedVaccineProducts.openapi.json)

#### WHO PreQual Manufacturer

Logical model for the manufacturer/applicant organization from the WHO PreQual API (ProductDetails.ApplicantOrganization).

[🩺 FHIR](StructureDefinition-PreQualManufacturer.md)
[📄 JSON Schema](schemas/StructureDefinition-PreQualManufacturer.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualManufacturer.openapi.json)

#### WHO PreQual Bulk Supplier

Logical model for the bulk supplier organization from the WHO PreQual API (ProductDetails.BulkSupplier).

[🩺 FHIR](StructureDefinition-PreQualBulkSupplier.md)
[📄 JSON Schema](schemas/StructureDefinition-PreQualBulkSupplier.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualBulkSupplier.openapi.json)

#### WHO PreQual Product Ingredient

Logical model for product ingredient details from the WHO PreQual API (ProductIngredients).

[🩺 FHIR](StructureDefinition-PreQualProductIngredient.md)
[📄 JSON Schema](schemas/StructureDefinition-PreQualProductIngredient.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualProductIngredient.openapi.json)

### OpenAPI Documentation

Complete API specification documentation for all available endpoints:

#### ValueSet-PreQualProductIds Endpoints

API endpoints for WHO PreQualificaiton Vaccine Product Ids Schema

[📄 JSON Schema](schemas/ValueSet-PreQualProductIds.schema.json)
[🗂️ JSON-LD](ValueSet-PreQualProductIds.jsonld)
[🔗 OpenAPI](schemas/ValueSet-PreQualProductIds.openapi.json)

#### ValueSet-PreQualPresentation Endpoints

API endpoints for WHO PreQualificaiton Presentation Schema

[📄 JSON Schema](schemas/ValueSet-PreQualPresentation.schema.json)
[🗂️ JSON-LD](ValueSet-PreQualPresentation.jsonld)
[🔗 OpenAPI](schemas/ValueSet-PreQualPresentation.openapi.json)

#### ValueSet-PreQualVaccineType Endpoints

API endpoints for WHO PreQualificaiton VaccineType Schema

[📄 JSON Schema](schemas/ValueSet-PreQualVaccineType.schema.json)
[🗂️ JSON-LD](ValueSet-PreQualVaccineType.jsonld)
[🔗 OpenAPI](schemas/ValueSet-PreQualVaccineType.openapi.json)

#### ValueSet-PreQualDatabaseMetadata Endpoints

API endpoints for WHO PreQualification Database Metadata Schema

[📄 JSON Schema](schemas/ValueSet-PreQualDatabaseMetadata.schema.json)
[🗂️ JSON-LD](ValueSet-PreQualDatabaseMetadata.jsonld)
[🔗 OpenAPI](schemas/ValueSet-PreQualDatabaseMetadata.openapi.json)

#### StructureDefinition-PreQualDocumentDetail Endpoints

API endpoints for WHO PreQual Document Detail

[📄 JSON Schema](schemas/StructureDefinition-PreQualDocumentDetail.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualDocumentDetail.openapi.json)

#### StructureDefinition-PreQualNRA Endpoints

API endpoints for WHO PreQual NRA

[📄 JSON Schema](schemas/StructureDefinition-PreQualNRA.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualNRA.openapi.json)

#### StructureDefinition-PreQualVaccine Endpoints

API endpoints for WHO PreQual Vaccine

[📄 JSON Schema](schemas/StructureDefinition-PreQualVaccine.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualVaccine.openapi.json)

#### StructureDefinition-PreQualSiteDetail Endpoints

API endpoints for WHO PreQual Site Detail

[📄 JSON Schema](schemas/StructureDefinition-PreQualSiteDetail.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualSiteDetail.openapi.json)

#### StructureDefinition-PreQualProductPackaging Endpoints

API endpoints for WHO PreQual Product Packaging

[📄 JSON Schema](schemas/StructureDefinition-PreQualProductPackaging.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualProductPackaging.openapi.json)

#### StructureDefinition-FinishedVaccineProducts Endpoints

API endpoints for WHO Vaccine PreQual DB - Finished Vaccine Products

[📄 JSON Schema](schemas/StructureDefinition-FinishedVaccineProducts.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-FinishedVaccineProducts.openapi.json)

#### StructureDefinition-PreQualManufacturer Endpoints

API endpoints for WHO PreQual Manufacturer

[📄 JSON Schema](schemas/StructureDefinition-PreQualManufacturer.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualManufacturer.openapi.json)

#### StructureDefinition-PreQualBulkSupplier Endpoints

API endpoints for WHO PreQual Bulk Supplier

[📄 JSON Schema](schemas/StructureDefinition-PreQualBulkSupplier.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualBulkSupplier.openapi.json)

#### StructureDefinition-PreQualProductIngredient Endpoints

API endpoints for WHO PreQual Product Ingredient

[📄 JSON Schema](schemas/StructureDefinition-PreQualProductIngredient.schema.json)
[🔗 OpenAPI](schemas/StructureDefinition-PreQualProductIngredient.openapi.json)

#### ValueSets Enumeration Endpoint

Complete list of all available ValueSet schemas

[📄 JSON Schema](ValueSets.schema.json)
[🔗 OpenAPI](ValueSets-enumeration.openapi.json)

#### LogicalModels Enumeration Endpoint

Complete list of all available Logical Model schemas

[📄 JSON Schema](LogicalModels.schema.json)
[🔗 OpenAPI](LogicalModels-enumeration.openapi.json)

#### StructureDefinition-PreQualNRA API

OpenAPI specification for StructureDefinition-PreQualNRA

[📖 Documentation](StructureDefinition-PreQualNRA.md)
[🔗 OpenAPI Spec](schemas/StructureDefinition-PreQualNRA.openapi.json)

#### ValueSet-PreQualVaccineType API

OpenAPI specification for ValueSet-PreQualVaccineType

[📖 Documentation](ValueSet-PreQualVaccineType.md)
[🔗 OpenAPI Spec](schemas/ValueSet-PreQualVaccineType.openapi.json)

#### StructureDefinition-PreQualProductPackaging API

OpenAPI specification for StructureDefinition-PreQualProductPackaging

[📖 Documentation](StructureDefinition-PreQualProductPackaging.md)
[🔗 OpenAPI Spec](schemas/StructureDefinition-PreQualProductPackaging.openapi.json)

#### StructureDefinition-PreQualDocumentDetail API

OpenAPI specification for StructureDefinition-PreQualDocumentDetail

[📖 Documentation](StructureDefinition-PreQualDocumentDetail.md)
[🔗 OpenAPI Spec](schemas/StructureDefinition-PreQualDocumentDetail.openapi.json)

#### ValueSet-PreQualProductIds API

OpenAPI specification for ValueSet-PreQualProductIds

[📖 Documentation](ValueSet-PreQualProductIds.md)
[🔗 OpenAPI Spec](schemas/ValueSet-PreQualProductIds.openapi.json)

#### StructureDefinition-FinishedVaccineProducts API

OpenAPI specification for StructureDefinition-FinishedVaccineProducts

[📖 Documentation](StructureDefinition-FinishedVaccineProducts.md)
[🔗 OpenAPI Spec](schemas/StructureDefinition-FinishedVaccineProducts.openapi.json)

#### StructureDefinition-PreQualBulkSupplier API

OpenAPI specification for StructureDefinition-PreQualBulkSupplier

[📖 Documentation](StructureDefinition-PreQualBulkSupplier.md)
[🔗 OpenAPI Spec](schemas/StructureDefinition-PreQualBulkSupplier.openapi.json)

#### ValueSet-PreQualPresentation API

OpenAPI specification for ValueSet-PreQualPresentation

[📖 Documentation](ValueSet-PreQualPresentation.md)
[🔗 OpenAPI Spec](schemas/ValueSet-PreQualPresentation.openapi.json)

#### StructureDefinition-PreQualProductIngredient API

OpenAPI specification for StructureDefinition-PreQualProductIngredient

[📖 Documentation](StructureDefinition-PreQualProductIngredient.md)
[🔗 OpenAPI Spec](schemas/StructureDefinition-PreQualProductIngredient.openapi.json)

#### StructureDefinition-PreQualSiteDetail API

OpenAPI specification for StructureDefinition-PreQualSiteDetail

[📖 Documentation](StructureDefinition-PreQualSiteDetail.md)
[🔗 OpenAPI Spec](schemas/StructureDefinition-PreQualSiteDetail.openapi.json)

#### ValueSet-PreQualDatabaseMetadata API

OpenAPI specification for ValueSet-PreQualDatabaseMetadata

[📖 Documentation](ValueSet-PreQualDatabaseMetadata.md)
[🔗 OpenAPI Spec](schemas/ValueSet-PreQualDatabaseMetadata.openapi.json)

#### StructureDefinition-PreQualManufacturer API

OpenAPI specification for StructureDefinition-PreQualManufacturer

[📖 Documentation](StructureDefinition-PreQualManufacturer.md)
[🔗 OpenAPI Spec](schemas/StructureDefinition-PreQualManufacturer.openapi.json)

#### StructureDefinition-PreQualVaccine API

OpenAPI specification for StructureDefinition-PreQualVaccine

[📖 Documentation](StructureDefinition-PreQualVaccine.md)
[🔗 OpenAPI Spec](schemas/StructureDefinition-PreQualVaccine.openapi.json)

### Using the DAK API

#### Schema Validation

Each JSON Schema can be used to validate data structures in your applications.

* Type definitions and constraints
* Property descriptions and examples
* Required field specifications
* Enumeration values with links to definitions

#### JSON-LD Semantic Integration

The JSON-LD vocabularies provide semantic web integration for ValueSet enumerations.

#### Integration with FHIR

All schemas are derived from the FHIR definitions in this implementation guide.

#### API Endpoints

The enumeration endpoints provide machine-readable lists of all available schemas.

-------

**This documentation hub is automatically generated from the available schema and API definitions.**

