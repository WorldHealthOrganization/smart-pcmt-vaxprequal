# PreQual Packaging: Shipping Container - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Shipping Container**

## Example Binary: PreQual Packaging: Shipping Container

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VajSUAS"
  },
  "packagingType": "ShippingContainer",
  "componentPacked": "ActiveVaccine",
  "volume": "64 x 69 x 41 cm",
  "totalDoses": "14400",
  "totalContainers": "3600 vials"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
