# PreQual Packaging: Diluent:Carton of 50 ampoules/ 250 doses. [Dimensions: 16.3 x 8.3 x 6 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Diluent:Carton of 50 ampoules/ 250 doses. [Dimensions: 16.3 x 8.3 x 6 cm]**

## Example Binary: PreQual Packaging: Diluent:Carton of 50 ampoules/ 250 doses. [Dimensions: 16.3 x 8.3 x 6 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VafaUAC"
  },
  "packagingType": "Secondary",
  "componentPacked": "Diluent",
  "coldChainVolume": "3.25",
  "description": "Diluent:Carton of 50 ampoules/ 250 doses. [Dimensions: 16.3 x 8.3 x 6 cm]",
  "height": "8.3",
  "length": "16.3",
  "width": "6.0",
  "primaryContainers": "50"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
