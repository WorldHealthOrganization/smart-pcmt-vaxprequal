# PreQual Document: pq_210_H1N1_1dose_MedImmune_carton%2Bsprayer_image_510 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: pq_210_H1N1_1dose_MedImmune_carton%2Bsprayer_image_510**

## Example Binary: PreQual Document: pq_210_H1N1_1dose_MedImmune_carton%2Bsprayer_image_510

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iOwjYAE"
  },
  "documentName": "pq_210_H1N1_1dose_MedImmune_carton%2Bsprayer_image_510",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005z8FeYAI",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
