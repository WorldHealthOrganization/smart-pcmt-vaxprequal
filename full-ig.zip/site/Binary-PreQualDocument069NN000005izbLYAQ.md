# PreQual Document: Container Photo (Bigger Higher Resolution)-pq_260_H1N1_LAIV_1dose_SII_container_image_NASOVAC - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo (Bigger Higher Resolution)-pq_260_H1N1_LAIV_1dose_SII_container_image_NASOVAC**

## Example Binary: PreQual Document: Container Photo (Bigger Higher Resolution)-pq_260_H1N1_LAIV_1dose_SII_container_image_NASOVAC

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005izbLYAQ"
  },
  "documentName": "Container Photo (Bigger Higher Resolution)-pq_260_H1N1_LAIV_1dose_SII_container_image_NASOVAC",
  "documentType": "Photo",
  "versionId": "068NN000005zkMdYAI",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
