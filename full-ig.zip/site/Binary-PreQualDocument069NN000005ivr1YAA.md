# PreQual Document: pq_235_mOPV_20dose_GSK_container_image-2022 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: pq_235_mOPV_20dose_GSK_container_image-2022**

## Example Binary: PreQual Document: pq_235_mOPV_20dose_GSK_container_image-2022

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005ivr1YAA"
  },
  "documentName": "pq_235_mOPV_20dose_GSK_container_image-2022",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005zgcEYAQ",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
