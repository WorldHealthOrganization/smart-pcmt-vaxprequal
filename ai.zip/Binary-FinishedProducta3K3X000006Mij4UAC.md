# PreQual Product: Afluria® Quadrivalent - IIV4 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Product: Afluria® Quadrivalent - IIV4**

## Example Binary: PreQual Product: Afluria® Quadrivalent - IIV4

This content is an example of the [WHO Vaccine PreQual DB - Finished Vaccine Products](StructureDefinition-FinishedVaccineProducts.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts",
  "productType": "FinishedVaccineProduct",
  "dateOfPrequal": "2019-03-05",
  "assessmentProcedure": "PrequalificationAbridged",
  "status": "Prequalified",
  "pharmaceuticalForm": "LiquidReadytouse",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 10,
  "productId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3K3X000006Mij4UAC"
  },
  "productName": "FVP-P-350",
  "vaccineFullName": "Influenza vaccine quadrivalent (split virion, inactivated)",
  "vaccineAbbreviatedName": "IIV4",
  "vaccineCommercialName": "Afluria® Quadrivalent",
  "vaccineTypeId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3S3X000003cSpRUAU"
  },
  "routeOfAdministration": "Intramuscular",
  "vialMonitor": "Type 2",
  "multidoseVialPolicy": "WHO recommends that opened vials of this vaccine may be used in subsequent immunization sessions (up to 28 days) if the conditions outlined in the WHO Policy Statement are met.",
  "applicantId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p4PQAQ"
  },
  "applicantName": "Seqirus Australia Pty Ltd",
  "nraId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p6CQAQ"
  },
  "nraName": "US Food and Drug Administration- Office of Vaccine Research and Review (US FDA)",
  "nraCountry": "United States of America",
  "shelfLife": "12 months",
  "storageTemperature": "2 - 8°C",
  "lastPublishingDate": "2024-09-10",
  "publishingRemarks": "Pallet shipper contains 119 shipping boxes (9520 vials/ 95200 doses of 0.5 mL or 190400 of 0.25 mL)",
  "preservative": "Thiomersal",
  "preservativeConcentration": "0.01 % w/v",
  "manufacturerReference": {
    "reference": "Organization/Manufacturer0013X0000498p4PQAQ"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holder0013X0000498p6CQAQ"
  },
  "manufacturerLM": {
    "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer/PreQualManufacturer0013X0000498p4PQAQ"
  },
  "nraLM": {
    "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA/PreQualNRA0013X0000498p6CQAQ"
  },
  "vaccineLM": {
    "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine/PreQualVaccinea3S3X000003cSpRUAU"
  },
  "packagingLM": [
    {
      "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging/PreQualPackaginga3H3X000001Vad8UAC"
    }
  ],
  "documentLM": [
    {
      "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail/PreQualDocument069NN000005l3h7YAA"
    }
  ],
  "siteLM": [
    {
      "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail/PreQualSite0013X0000498p4PQAQ"
    }
  ],
  "ingredientLM": [
    {
      "reference": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient/PreQualIngredienta3K3X000006Mij4UACIng5"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
