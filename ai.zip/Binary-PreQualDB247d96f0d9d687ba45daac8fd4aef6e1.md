# PreQualDB247d96f0d9d687ba45daac8fd4aef6e1 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB247d96f0d9d687ba45daac8fd4aef6e1**

## Binary: PreQualDB247d96f0d9d687ba45daac8fd4aef6e1

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2018-01-05",
  "vaccineType": {
    "coding": [
      {
        "code": "Rotavirusliveattenuated",
        "display": "Rotavirus (live, attenuated)"
      }
    ]
  },
  "commercialName": "Rotavac",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 10,
  "manufacturer": {
    "text": "Bharat Biotech International Limited"
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "247d96f0d9d687ba45daac8fd4aef6e1"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer23f34f1a92ebdeb8c55ddd34c31ad564"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/RotavirusliveattenuatedProduct247d96f0d9d687ba45daac8fd4aef6e1"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
