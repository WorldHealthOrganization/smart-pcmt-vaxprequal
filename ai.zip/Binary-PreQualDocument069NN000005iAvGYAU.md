# PreQual Document: pq_113_YF_10dose_SP_vial%26carton_image - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: pq_113_YF_10dose_SP_vial%26carton_image**

## Example Binary: PreQual Document: pq_113_YF_10dose_SP_vial%26carton_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iAvGYAU"
  },
  "documentName": "pq_113_YF_10dose_SP_vial%26carton_image",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005yuJ0YAI",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
