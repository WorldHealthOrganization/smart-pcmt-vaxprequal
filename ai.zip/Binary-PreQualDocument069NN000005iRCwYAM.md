# PreQual Document: Package Insert-pq_196_296_bOPV1-3_BioFarma_PI-2020 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Package Insert-pq_196_296_bOPV1-3_BioFarma_PI-2020**

## Example Binary: PreQual Document: Package Insert-pq_196_296_bOPV1-3_BioFarma_PI-2020

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iRCwYAM"
  },
  "documentName": "Package Insert-pq_196_296_bOPV1-3_BioFarma_PI-2020",
  "documentType": "ProductInsert",
  "versionId": "068NN000005zAR0YAM",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
