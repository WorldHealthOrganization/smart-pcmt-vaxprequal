# PreQualDB2d90fb090e2c500ab939d14b59fe7b4c - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB2d90fb090e2c500ab939d14b59fe7b4c**

## Binary: PreQualDB2d90fb090e2c500ab939d14b59fe7b4c

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2014-09-17",
  "vaccineType": {
    "coding": [
      {
        "code": "DiphtheriaTetanusreduced",
        "display": "Diphtheria-Tetanus (reduced antigen content)"
      }
    ]
  },
  "commercialName": "None used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  BE Td",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 1,
  "manufacturer": {
    "text": "Biological E. Limited"
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "2d90fb090e2c500ab939d14b59fe7b4c"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer54a4cbdf74f251158fb034e8f5e1ff5b"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/DiphtheriaTetanusreducedProduct2d90fb090e2c500ab939d14b59fe7b4c"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
