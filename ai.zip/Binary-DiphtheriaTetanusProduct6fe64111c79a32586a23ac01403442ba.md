# DiphtheriaTetanusProduct6fe64111c79a32586a23ac01403442ba - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DiphtheriaTetanusProduct6fe64111c79a32586a23ac01403442ba**

## Binary: DiphtheriaTetanusProduct6fe64111c79a32586a23ac01403442ba

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/Product",
  "status": "active",
  "name": [
    {
      "nameType": "official",
      "value": "Diphtheria and Tetanus Vaccine Adsorbed (Pediatric)"
    }
  ],
  "manufacturer": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "doseQuantity": {
    "value": 10,
    "code": "doses",
    "system": "http://unitsofmeasure.org"
  },
  "classification": [
    {
      "coding": [
        {
          "code": "DiphtheriaTetanus"
        }
      ]
    }
  ],
  "unitOfUse": {
    "coding": [
      {
        "code": "doses"
      }
    ]
  },
  "dosageForm": {
    "coding": [
      {
        "code": "Vial"
      }
    ]
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
