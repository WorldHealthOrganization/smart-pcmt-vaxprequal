# WHO PreQualificaiton Vaccine Product Ids - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **WHO PreQualificaiton Vaccine Product Ids**

## CodeSystem: WHO PreQualificaiton Vaccine Product Ids (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualProductIds | *Version*:0.2.0 |
| Active as of 2026-03-23 | *Computable Name*:PreQualProductIds |

 
WHO PreQualificaiton Vaccine Product Ids 

 This Code system is referenced in the content logical definition of the following value sets: 

* [PreQualProductIds](ValueSet-PreQualProductIds.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "PreQualProductIds",
  "url" : "http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualProductIds",
  "version" : "0.2.0",
  "name" : "PreQualProductIds",
  "title" : "WHO PreQualificaiton Vaccine Product Ids",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-03-23T12:05:55+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "WHO PreQualificaiton Vaccine Product Ids",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 275,
  "concept" : [{
    "code" : "HepatitisBPaediatricProduct0a80755033118a426f1d2a571df1b6df",
    "display" : "16/01/2025Hepatitis B (Paediatric)BEVAC®Vial1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "HepatitisBProduct29a71534ef44b701da06062075100739",
    "display" : "20/01/2025Hepatitis BBEVAC®Vial1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "HaemophilusinfluenzaetypProductf455a733c51ebd231f8e748ff2d54292",
    "display" : "01/04/1998Haemophilus influenzae type bAct-HIBVial1Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct2b5b9b19671826d92dff00f622588487",
    "display" : "08/05/2017Diphtheria-Tetanus-Pertussis (acellular)AdacelVial1Sanofi Pasteur LimitedHealth Canada - Santé Canada"
  },
  {
    "code" : "DiphtheriaTetanusProduct0b291aa3e71f93edc6e5020d6702012c",
    "display" : "11/03/1999Diphtheria-TetanusAdsorbed DT VaccineVial10PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProductd748a38574e356813c814007a57c7781",
    "display" : "07/02/2020Influenza, seasonal (Trivalent)Afluria®Vial10Seqirus LimitedUS Food and Drug Administration- Office of Vaccine Research and Review"
  },
  {
    "code" : "InfluenzaseasonalQuadrivProduct0e15fb29d9353a3e14d4b6d4180efb5a",
    "display" : "05/03/2019Influenza, seasonal (Quadrivalent)Afluria® QuadrivalentVial10Seqirus LimitedUS Food and Drug Administration- Office of Vaccine Research and Review"
  },
  {
    "code" : "VaricellaProduct68d1e94dee14002a478bb763192fd4c8",
    "display" : "14/02/2023VaricellaBARYCELA inj.Vial1GC Biopharma Corp.Ministry of Food and Drug Safety"
  },
  {
    "code" : "BCGProducta225473ed705ece5111f5bfcaf99f216",
    "display" : "01/01/1987BCGBCG Freeze Dried Glutamate vaccineAmpoule10Japan BCG LaboratoryPharmaceutical and Medical Devices Agency"
  },
  {
    "code" : "BCGProducte40454e099c809e80e245d28528c4f40",
    "display" : "01/01/1987BCGBCG Freeze Dried Glutamate vaccineAmpoule20Japan BCG LaboratoryPharmaceutical and Medical Devices Agency"
  },
  {
    "code" : "BCGProductee4fa99e6bfabbc2a99fe3b0ec7f6db4",
    "display" : "29/05/2003BCGBCG VaccineVial20Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "BCGProduct508c17fc4a3f649c75478d6bc83ab3b4",
    "display" : "03/12/2024BCGBCG VaccineVial + Ampoule20GreenSignal Bio Pharma Pvt LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "BCGProduct92b29c115b94bfd6959395add8189921",
    "display" : "01/02/1991BCGBCG VaccineAmpoule10BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)Bulgarian Drug Agency"
  },
  {
    "code" : "BCGProductfa2cfb4dc7d79771ed47d86a3efc9167",
    "display" : "01/02/1991BCGBCG VaccineAmpoule20BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)Bulgarian Drug Agency"
  },
  {
    "code" : "BCGProduct133dc209d46d1398e03c452ad1a537ed",
    "display" : "27/09/1994BCGBCG Vaccine AJVTwo vial set (active + excipient)10AJ Vaccines A/SDanish Medicines Agency"
  },
  {
    "code" : "HepatitisBPaediatricProduct12ac64a6373a51fb383f4d55fc5e32b8",
    "display" : "16/01/2025Hepatitis B (Paediatric)BEVAC®Vial10Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "HepatitisBProduct790d33df8e93799f8894daabb900d356",
    "display" : "16/01/2025Hepatitis BBEVAC®Vial10Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "Covid19Product8da0ece0c48e47a9df9e0ad312343219",
    "display" : "09/10/2023Covid-19BIMERVAXVial1HIPRA HUMAN HEALTH, S.L.UEuropean Medicines Agency"
  },
  {
    "code" : "PolioVaccineOralOPVTrivaProductfa4849f7532d522134f4102063af1617",
    "display" : "20/03/2015Polio Vaccine - Oral (OPV) TrivalentBIOPOLIOVial10Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVTrivaProduct4df3a93ab495d85b3583d0cd1ae3d83e",
    "display" : "20/03/2015Polio Vaccine - Oral (OPV) TrivalentBIOPOLIOVial20Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProduct16e883911ea0108b8213bc213c9972fe",
    "display" : "25/08/2017Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3BIOPOLIO B1/3Vial10Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProduct0e59118bc5938520115bac65a45be04d",
    "display" : "20/03/2015Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3BIOPOLIO B1/3Vial20Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProductb62fbc87532804be42afa8d9050ef452",
    "display" : "16/11/2021Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent OPV Type 1 and 3 Poliomyelitis Vaccine, Live (Oral)Vial10Panacea Biotec Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProduct02c099d69cd245e7fcd3280a96f1dccb",
    "display" : "07/12/2018Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent OPV Type 1 and 3 Poliomyelitis Vaccine, Live (Oral)Vial20Panacea Biotec Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProductdecf3a77facc0b8f1443db5f7a806857",
    "display" : "05/11/2015Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent Oral Poliomyelitis Vaccine Type 1&3 (bOPV 1&3)Vial10PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProduct10aa94cef126e62542c2c45dc3604c0b",
    "display" : "26/05/2010Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent Oral Poliomyelitis Vaccine Type 1&3 (bOPV 1&3)Vial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProduct26e6c50dfb385f223a12238dc6e202dd",
    "display" : "19/03/2010Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Bivalent type 1&3 Oral Poliomyelitis vaccine, IP (bOPV1&3)Vial20Haffkine Bio Pharmaceutical Corporation LtdCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProductd86fa01b474096e0551b7c34b93fcdfc",
    "display" : "09/07/2013Diphtheria-Tetanus-Pertussis (acellular)BoostrixVial1GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "HumanPapillomavirusBivalProductb342f0044a178c79f90b581a4a5208ba",
    "display" : "14/10/2021Human Papillomavirus (Bivalent)Cecolin®Vial1Xiamen Innovax Biotech Co. Ltd.National Medical Products Administration"
  },
  {
    "code" : "InfluenzaPandemicH1N1Product8cb910c5702efa28db66bc22c8243188",
    "display" : "17/12/2009Influenza, Pandemic (H1N1)CelturaVial17Seqirus GmbHPaul-Ehrlich-Institut"
  },
  {
    "code" : "HumanPapillomavirusBivalProduct90bc0971e6434227a7385b7965be0958",
    "display" : "08/07/2009Human Papillomavirus (Bivalent)CervarixVial1GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "HumanPapillomavirusBivalProductd74dd5ffaeebfbdedd5ee981b05b45f5",
    "display" : "08/07/2009Human Papillomavirus (Bivalent)CervarixVial2GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "Covid19Product2afac141c6a2f5d7231a1db67e0613a5",
    "display" : "09/10/2024Covid-19Comirnaty®VialBioNTech Manufacturing GmbHEuropean Medicines Agency"
  },
  {
    "code" : "MalariaProduct88d9bdf685abb8563d94dae08fc1d860",
    "display" : "19/12/2023MalariaCYVACVial2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DengueTetravalentliveattProduct8ffab92f1c77bcdc5b542565b27784b1",
    "display" : "25/03/2020Dengue Tetravalent (live, attenuated)DengvaxiaTwo vial set (active + excipient)5Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "DiphtheriaTetanusProducta0aba531248cc7cc61d06551ad5ff9d7",
    "display" : "09/05/2006Diphtheria-TetanusDiftetVial10BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)Bulgarian Drug Agency"
  },
  {
    "code" : "DiphtheriaTetanusProducta5dce7e8e00b2b288510772a7a75649c",
    "display" : "09/05/2006Diphtheria-TetanusDiftetVial20BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)Bulgarian Drug Agency"
  },
  {
    "code" : "DiphtheriaTetanusProduct4ceaeaed5cbda00d6675bc8593b37b9f",
    "display" : "04/04/1995Diphtheria-TetanusDiphtheria and Tetanus Vaccine Adsorbed (Paediatric)Ampoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusProduct6fe64111c79a32586a23ac01403442ba",
    "display" : "04/04/1995Diphtheria-TetanusDiphtheria and Tetanus Vaccine Adsorbed (Pediatric)Vial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusProduct6049297c180d7c6e46f6a9a817dcabb3",
    "display" : "04/04/1995Diphtheria-TetanusDiphtheria and Tetanus Vaccine Adsorbed (Pediatric)Vial20Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct5fd73b2ccd79a39acb5eb336e53f8315",
    "display" : "04/04/1995Diphtheria-Tetanus (reduced antigen content)Diphtheria and Tetanus Vaccine Adsorbed for Adults and AdolescentsVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct5b6b854e1885d59887a4eea0f4bd7a0c",
    "display" : "04/04/1995Diphtheria-Tetanus (reduced antigen content)Diphtheria and Tetanus Vaccine Adsorbed for Adults and AdolescentsVial20Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct39c0ef6a00b0846fb19fe4ca8fb376f7",
    "display" : "04/04/1995Diphtheria-Tetanus (reduced antigen content)Diphtheria and Tetanus Vaccine Adsorbed for Adults and AdolescentsAmpoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProductc63556bc39df77ae14833feb5ac10a35",
    "display" : "04/04/1995Diphtheria-Tetanus-Pertussis (whole cell)Diphtheria-Tetanus-Pertussis Vaccine AdsorbedVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct927cff21ed0a901aa884339b766ee662",
    "display" : "04/04/1995Diphtheria-Tetanus-Pertussis (whole cell)Diphtheria-Tetanus-Pertussis Vaccine AdsorbedVial20Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct7b8002a4a273e0a9f749c44ac968cf44",
    "display" : "04/04/1995Diphtheria-Tetanus-Pertussis (whole cell)Diphtheria-Tetanus-Pertussis Vaccine AdsorbedAmpoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct2029c7c29c39910766a76fc788115bbc",
    "display" : "23/06/2010Diphtheria-Tetanus-Pertussis (whole cell)-Haemophilus influenzae type bDiphtheria, Tetanus, Pertussis and Haemophilus influenzae type b Conjugate VaccineVial + Ampoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct60c498d6555dec24de8a8ecc48ab1a02",
    "display" : "26/05/2010Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bDiphtheria, Tetanus, Pertussis, Hepatitis B and Haemophilus influenzae type b Conjugate VaccineVial + Ampoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct828f395532066d11d360768aa0793f54",
    "display" : "26/05/2010Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bDiphtheria, Tetanus, Pertussis, Hepatitis B and Haemophilus influenzae type b Conjugate VaccineVial + Ampoule2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProductfdb459366fa4a85d1a7555bcad51264b",
    "display" : "26/05/2010Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bDiphtheria, Tetanus, Pertussis, Hepatitis B and Haemophilus influenzae type b Conjugate VaccineVial + Ampoule10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProducta438e46e3587ece79794373e69bafc4d",
    "display" : "22/09/2010Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bDiphtheria, Tetanus, Pertussis, Hepatitis B and Haemophilus influenzae type b Conjugate Vaccine AdsorbedVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct08be2bd220651dc1c79b4d7f252461ef",
    "display" : "22/09/2010Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bDiphtheria, Tetanus, Pertussis, Hepatitis B and Haemophilus influenzae type b Conjugate Vaccine AdsorbedVial2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct344e3ef97d8fe6c7d58c108f82a18dfb",
    "display" : "22/09/2010Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bDiphtheria, Tetanus, Pertussis, Hepatitis B and Haemophilus influenzae type b Conjugate Vaccine AdsorbedVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct456bd99d59edd5a285d7ca2451541021",
    "display" : "06/04/2001Diphtheria-Tetanus-Pertussis (whole cell)DTP VaccineVial10PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "cholerainactivatedoralProductf1c03e02b729d1b9da196f4dbfe675f1",
    "display" : "25/10/2001cholera: inactivated oralDukoralVial + Buffer Sachet1Valneva Sweden ABMedical Products Agency"
  },
  {
    "code" : "DiphtheriaTetanusPertussProductb45f38ad231b3faff40a3b3aa2d61cca",
    "display" : "02/10/2013Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bEasyfive-TTVial1Panacea Biotec Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct4e2900c73c70158b90a240513998895d",
    "display" : "02/10/2013Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bEasyfive-TTVial10Panacea Biotec Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "HepatitisBProduct624c420054fd62b8831ca6db7627ac9a",
    "display" : "01/01/1987Hepatitis BEngerixVial1GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "HepatitisBProduct6ac3603e086e99d1f9727d94433b276f",
    "display" : "01/01/1987Hepatitis BEngerixVial10GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "HepatitisBProduct53bb991260516f314ee605085dd1ba2c",
    "display" : "01/01/1987Hepatitis BEngerixVial20GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "EbolaZairerVSVGZEBOVGPliProducta2f4a9e07cfeebbb99d5ae2e4cc0257f",
    "display" : "12/11/2019Ebola Zaire (rVSV∆G-ZEBOV-GP, live attenuated)ERVEBOVial1Merck Sharp & Dohme LLCEuropean Medicines Agency"
  },
  {
    "code" : "DiphtheriaTetanusPertussProductf949888fce8cdf016cfc06644a16afbb",
    "display" : "10/02/2016Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bEupentaVial1LG Chem LtdMinistry of Food and Drug Safety"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct9d194caa1c66fb809622f25ec6f79f5c",
    "display" : "10/02/2016Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bEupentaVial10LG Chem LtdMinistry of Food and Drug Safety"
  },
  {
    "code" : "PolioVaccineInactivatedSProduct0854d534a200bbeffa8be0f57dad584a",
    "display" : "01/06/2021Polio Vaccine - Inactivated Sabin (sIPV)Eupolio Inj.Vial1LG Chem LtdMinistry of Food and Drug Safety"
  },
  {
    "code" : "PolioVaccineInactivatedSProduct031f63df3184acdf0cb82f90f316b6c3",
    "display" : "21/12/2020Polio Vaccine - Inactivated Sabin (sIPV)Eupolio Inj.Vial5LG Chem LtdMinistry of Food and Drug Safety"
  },
  {
    "code" : "HepatitisBPaediatricProduct7431cfff77d30de2a89868b3bd4a2f9d",
    "display" : "21/01/2020Hepatitis B (Paediatric)Euvax BVial1LG Chem LtdMinistry of Food and Drug Safety"
  },
  {
    "code" : "HepatitisBProduct2c48b25fdefb970fc85dbb63e04fe744",
    "display" : "22/11/1996Hepatitis BEuvax BVial1LG Chem LtdMinistry of Food and Drug Safety"
  },
  {
    "code" : "HepatitisBProduct953ab5cac67cbb23eeab9e794501209d",
    "display" : "22/11/1996Hepatitis BEuvax BVial10LG Chem LtdMinistry of Food and Drug Safety"
  },
  {
    "code" : "cholerainactivatedoralProduct9e735ce376b3d71987e9c2054ba0590a",
    "display" : "23/12/2015cholera: inactivated oralEuvicholVial1EuBiologics Co., Ltd.Ministry of Food and Drug Safety"
  },
  {
    "code" : "cholerainactivatedoralProduct242d7b0c599da706838dbbdaa4d78d9b",
    "display" : "11/08/2017cholera: inactivated oralEuvichol-PlusPlastic Tube1EuBiologics Co., Ltd.Ministry of Food and Drug Safety"
  },
  {
    "code" : "cholerainactivatedoralProductd628c6599248f979f6fdf6145e8606b0",
    "display" : "12/04/2024cholera: inactivated oralEuvichol®-SPlastic Tube1EuBiologics Co., Ltd.Ministry of Food and Drug Safety"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProduct888045063db8e551a4e395130d66cd64",
    "display" : "09/01/2025Influenza, seasonal (Trivalent)FLU-M®Vial10Saint Petersburg Scientific Research Institute of Vaccines and Serums of the FMBA of RussiaCentro para el Control Estatal de la Calidad de los Medicamentos"
  },
  {
    "code" : "InfluenzaseasonalQuadrivProduct8b43bd5416101efc433940c20e424971",
    "display" : "04/11/2015Influenza, seasonal (Quadrivalent)Fluzone Quadrivalent (labelled as FluQuadri in other markets)Vial1Sanofi Pasteur Inc.US Food and Drug Administration- Office of Vaccine Research and Review"
  },
  {
    "code" : "InfluenzaseasonalQuadrivProduct37f198a748f37e28fa533b43fb8b4ca4",
    "display" : "04/11/2015Influenza, seasonal (Quadrivalent)Fluzone Quadrivalent (labelled as FluQuadri in other markets)Vial10Sanofi Pasteur Inc.US Food and Drug Administration- Office of Vaccine Research and Review"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProducte6bf7aa0fe6620e314ba0c0c24a45d07",
    "display" : "09/07/2024Influenza, seasonal (Trivalent)Fluzone® (Fluprevli™ in other markets)Vial10Sanofi Pasteur Inc.US Food and Drug Administration- Office of Vaccine Research and Review"
  },
  {
    "code" : "InfluenzaPandemicH1N1Productc76596a60cfa755021c2efe65100805b",
    "display" : "16/12/2009Influenza, Pandemic (H1N1)FocetriaVial10Seqirus Vaccines LimitedCBER/FDA"
  },
  {
    "code" : "HumanPapillomavirusNinevProduct6d6849ce69076acc0842734b9a0d375c",
    "display" : "09/02/2018Human Papillomavirus (Ninevalent)Gardasil 9Vial1Merck Sharp & Dohme LLCEuropean Medicines Agency"
  },
  {
    "code" : "HumanPapillomavirusQuadrProduct551b21b1ec1a67bbb0009f875faf7823",
    "display" : "20/05/2009Human Papillomavirus (Quadrivalent)GardasilVial1Merck Sharp & Dohme LLCEuropean Medicines Agency"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProductf45d14eded02944191a947ce6ede1a69",
    "display" : "12/04/2011Influenza, seasonal (Trivalent)GC FLU  injVial1GC Biopharma Corp.Ministry of Food and Drug Safety"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProducte9f09e6a7002d6c130969c9ee5076b1d",
    "display" : "07/11/2012Influenza, seasonal (Trivalent)GC FLU Multi inj.Vial10GC Biopharma Corp.Ministry of Food and Drug Safety"
  },
  {
    "code" : "InfluenzaseasonalQuadrivProductb9a1bcee5471105a80864fdc3ca80945",
    "display" : "21/12/2016Influenza, seasonal (Quadrivalent)GC FLU Quadrivalent inj.Vial1GC Biopharma Corp.Ministry of Food and Drug Safety"
  },
  {
    "code" : "InfluenzaseasonalQuadrivProduct183176ddf9c8c8d8a60d3fa2d8ce467f",
    "display" : "03/04/2017Influenza, seasonal (Quadrivalent)GC FLU Quadrivalent Multi inj.Vial10GC Biopharma Corp.Ministry of Food and Drug Safety"
  },
  {
    "code" : "InfluenzaPandemicH1N1Product6a7cb8b1df3d2ff48b3e61cf5924c482",
    "display" : "11/05/2010Influenza, Pandemic (H1N1)Green Flu-SVial1GC Biopharma Corp.Ministry of Food and Drug Safety"
  },
  {
    "code" : "HaemophilusinfluenzaetypProduct8c2914a22ad193c8db2d3ef514ff2d77",
    "display" : "17/11/2008Haemophilus influenzae type bHaemophilus influenzae type b Conjugate VaccineVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "HepatitisAHumanDiploidCeProducta1708bd501df3103f85e2df44bcf0003",
    "display" : "19/07/2013Hepatitis A (Human Diploid Cell), Inactivated (Adult)Havrix 1440 AdultVial1GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "HepatitisAHumanDiploidCeProductbfeb5b5e99ae6a86b27432faa78da48c",
    "display" : "19/07/2013Hepatitis A (Human Diploid Cell), Inactivated (Paediatric)Havrix 720 JuniorVial1GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "HepatitisAHumanDiploidCeProductb1b534f4defa78597b059a190a77b357",
    "display" : "22/12/2017Hepatitis A (Human Diploid Cell), Inactivated (Paediatric)HEALIVEVial1Sinovac Biotech Co. LtdNational Medical Products Administration"
  },
  {
    "code" : "HepatitisAHumanDiploidCeProductc760d423dd3f53b4b1d83226d36a8f40",
    "display" : "22/12/2017Hepatitis A (Human Diploid Cell), Inactivated (Adult)HEALIVEVial1Sinovac Biotech Co. LtdNational Medical Products Administration"
  },
  {
    "code" : "HepatitisBProduct7402fe6f607aee04fc3800e7258809a9",
    "display" : "11/12/2001Hepatitis BHeberbiovac HBVial1Centro de Ingenieria Genetica y BiotecnologiaCentro para el Control Estatal de la Calidad de los Medicamentos"
  },
  {
    "code" : "HepatitisBProducta2e0420d94f1d5dcf054685ca8d84336",
    "display" : "11/12/2001Hepatitis BHeberbiovac HBVial10Centro de Ingenieria Genetica y BiotecnologiaCentro para el Control Estatal de la Calidad de los Medicamentos"
  },
  {
    "code" : "HepatitisBProductc63592587d84458436293a1b52964f2d",
    "display" : "12/11/2004Hepatitis BHepatitis B Vaccine (rDNA) (Adult)Vial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "HepatitisBProduct5d90a5f85cfbcea91790d1d66c17c8ed",
    "display" : "12/11/2004Hepatitis BHepatitis B Vaccine (rDNA) (Adult)Ampoule or Vial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "HepatitisBProduct2c7bb1d3d1f6b656f2b91e6399ac8935",
    "display" : "12/11/2004Hepatitis BHepatitis B Vaccine (rDNA) (Paediatric)Vial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "HepatitisBProductb2a3129f600781cc753b011290b09acb",
    "display" : "12/11/2004Hepatitis BHepatitis B Vaccine (rDNA) (Paedriatic)Ampoule or Vial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProductf4177b409d09d83e48630717437c5aea",
    "display" : "21/03/2024Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated)HEXASIILVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct0e63b58e2976f385b77a9b5a356b68b5",
    "display" : "21/03/2024Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated)HEXASIILVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProductd54558e2851d29311ee7f90975827dc7",
    "display" : "19/12/2014Diphtheria-Tetanus-Pertussis (acellular)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated)HexaximVial1Sanofi PasteurEuropean Medicines Agency"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProduct30b66eeb49e7056ae34bdeae70658f8b",
    "display" : "25/05/2018Influenza, seasonal (Trivalent)IL-YANG FLU Vaccine INJ.Vial1IL-YANG PHARMACEUTICAL CO., LTD.Ministry of Food and Drug Safety"
  },
  {
    "code" : "JapaneseEncephalitisVaccProduct25fc0fcf4e56d016e349a170104a5840",
    "display" : "18/09/2014Japanese Encephalitis Vaccine (live, attenuated)IMOJEV MDTwo vial set (active + excipient)4Global Biotech Products Co., LtdThai Food and Drug Administration"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct01c42855480e72f00caf639ab9157baf",
    "display" : "22/07/1997Diphtheria-Tetanus (reduced antigen content)IMOVAX dT adultVial10Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "PolioVaccineInactivatedIProduct532ef986c8042bbb15fee24056fdc4ed",
    "display" : "09/12/2005Polio Vaccine - Inactivated (IPV)IMOVAX POLIOVial10Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "SmallpoxandMpoxvaccineLiProduct1b03f110ef15d36c9664465098d3adec",
    "display" : "13/09/2024Smallpox and Mpox vaccine (Live Modified Vaccinia Virus Ankara)Imvanex® (also approved under the name of JYNNEOS by the USFDA and IMVAMUNE by Health Canada)Vial1Bavarian Nordic A/SEuropean Medicines Agency"
  },
  {
    "code" : "InfluenzaPandemicH1N1Product13ecad42baa7d2234f337b12f32b52de",
    "display" : "28/01/2010Influenza, Pandemic (H1N1)Influenza A (H1N1) 2009 monovalent vaccineVial1Sanofi Pasteur Inc.CBER/FDA"
  },
  {
    "code" : "InfluenzaPandemicH1N1Product967a1c59b6590047a341c18013831c4b",
    "display" : "28/01/2010Influenza, Pandemic (H1N1)Influenza A (H1N1) 2009 monovalent vaccineVial10Sanofi Pasteur Inc.CBER/FDA"
  },
  {
    "code" : "InfluenzaPandemicH1N1Product4326726a809bbcd312e4f29a90082bb6",
    "display" : "25/02/2010Influenza, Pandemic (H1N1)Influenza A (H1N1) 2009 monovalent vaccineSprayer1MedImmuneCBER/FDA"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProduct5268d009fa44e51462fcdcbcbc80ebf3",
    "display" : "26/04/2021Influenza, seasonal (Trivalent)influenza trivalent vaccine (split virion, inactivated)Vial10Instituto ButantanAgencia Nacional da Vigilancia Sanitaria"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProduct3ec4a63eb2160bf9a65d9fd69f5de160",
    "display" : "09/06/2015Influenza, seasonal (Trivalent)Influenza Vaccine (Split virion, inactivated)Vial1Hualan Biological Bacterin Inc.National Medical Products Administration"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProduct096666bb5a86521c6c6046227092334d",
    "display" : "20/10/2023Influenza, seasonal (Trivalent)Influenza Vaccine (Split Virion), InactivatedVial1Changchun Institute of Biological Products Co., LtdNational Medical Products Administration"
  },
  {
    "code" : "InfluenzaseasonalQuadrivProduct30fd25d892863f955ec6f9b57c328dbb",
    "display" : "19/02/2024Influenza, seasonal (Quadrivalent)Influvac® TetraVial1Abbott Biologicals BVMedicines Evaluation Board (MEB)"
  },
  {
    "code" : "PolioVaccineInactivatedIProduct087ff26057e89c006517428347dfbc3c",
    "display" : "23/12/2010Polio Vaccine - Inactivated (IPV)IPV Vaccine AJVVial1AJ Vaccines A/SDanish Medicines Agency"
  },
  {
    "code" : "JapaneseEncephalitisVaccProduct88482ae2796337d6f7832238bdf003fb",
    "display" : "08/10/2013Japanese Encephalitis Vaccine (live, attenuated)Japanese Encephalitis Vaccine Live (SA14-14-2)Two vial set (active + excipient)1Chengdu Institute of Biological Products Co.,LtdNational Medical Products Administration"
  },
  {
    "code" : "JapaneseEncephalitisVaccProductc6a1b72f22ca5f875ca681973d42742c",
    "display" : "08/10/2013Japanese Encephalitis Vaccine (live, attenuated)Japanese Encephalitis Vaccine Live (SA14-14-2)Two vial set (active + excipient)5Chengdu Institute of Biological Products Co.,LtdNational Medical Products Administration"
  },
  {
    "code" : "JapaneseEncephalitisVaccProduct030f186c51ac8780d767bcba8f2762b2",
    "display" : "03/08/2016Japanese Encephalitis Vaccine (Inactivated) (3µg Pediatric)JEEV® (3µg)Vial1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "JapaneseEncephalitisVaccProduct436f9ace27daebdccddb8279b66a3e98",
    "display" : "02/10/2018Japanese Encephalitis Vaccine (Inactivated) (3µg Pediatric)JEEV® (3µg)Vial5Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "JapaneseEncephalitisVaccProduct7d5507cd0733a44eaa4072b888176783",
    "display" : "12/07/2013Japanese Encephalitis Vaccine (Inactivated) 6µgJEEV® (6µg)Vial1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "JapaneseEncephalitisVaccProduct94b97202e37b591c7b7da316ff2bca00",
    "display" : "02/10/2018Japanese Encephalitis Vaccine (Inactivated) 6µgJEEV® (6µg)Vial5Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesandRubellaProducta64cf480e98d911934cc1e33dd1d99dd",
    "display" : "24/09/2019Measles and RubellaMeasles and Rubella Vaccine (Live) (Attenuated, Freeze Dried)Vial + Ampoule1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesandRubellaProductd3425606d671107b4265df9a9b33c318",
    "display" : "24/09/2019Measles and RubellaMeasles and Rubella Vaccine (Live) (Attenuated, Freeze Dried)Vial + Ampoule5Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesandRubellaProduct77c8d21c6e4f7faaa12d93564b5c97bc",
    "display" : "24/09/2019Measles and RubellaMeasles and Rubella Vaccine (Live) (Attenuated, Freeze Dried)Vial + Ampoule10Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesandRubellaProductb59a78efc3a033a13b483b20d386fca5",
    "display" : "18/07/2000Measles and RubellaMeasles and Rubella Vaccine, Live, AttenuatedVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesandRubellaProduct635f19b7add7fab78d60262e086e4543",
    "display" : "18/07/2000Measles and RubellaMeasles and Rubella Vaccine, Live, AttenuatedVial2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesandRubellaProduct65d4761f7dd7345dd02cd11109a1cf8c",
    "display" : "18/07/2000Measles and RubellaMeasles and Rubella Vaccine, Live, AttenuatedVial5Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesandRubellaProduct9fa0f8f3b99bdc45a172ae498f3f0105",
    "display" : "18/07/2000Measles and RubellaMeasles and Rubella Vaccine, Live, AttenuatedVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesProductf1e33f21c2c353e67218f267dd73ea38",
    "display" : "04/09/2006MeaslesMeasles vaccineVial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "MeaslesProductf4749d5c7dc03738b6fad169dd71fa00",
    "display" : "09/04/1997MeaslesMeasles vaccineVial + Ampoule10PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "MeaslesProductaa790a232317076de88d43837608f860",
    "display" : "15/02/1993MeaslesMeasles Vaccine, Live, AttenuatedVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesProduct0269fa56eaf4988d90c519518ec6282e",
    "display" : "15/02/1993MeaslesMeasles Vaccine, Live, AttenuatedVial2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesProduct8f5df4935259a7c2d8a2dc97918336fc",
    "display" : "15/02/1993MeaslesMeasles Vaccine, Live, AttenuatedVial5Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesProduct22043a8ed978f482a283310ca4b73aa0",
    "display" : "15/02/1993MeaslesMeasles Vaccine, Live, AttenuatedVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesMumpsandRubellaProductbe9b0af328a5e3832c8004f7ec7d7657",
    "display" : "08/08/2003Measles, Mumps and RubellaMeasles, Mumps and Rubella Vaccine, Live, AttenuatedVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesMumpsandRubellaProduct3e4662a10c91ed08c81f3163d43da4eb",
    "display" : "08/08/2003Measles, Mumps and RubellaMeasles, Mumps and Rubella Vaccine, Live, AttenuatedVial2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesMumpsandRubellaProducta1b8577c56035c4ad388e6a93986a21e",
    "display" : "08/08/2003Measles, Mumps and RubellaMeasles, Mumps and Rubella Vaccine, Live, AttenuatedVial5Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesMumpsandRubellaProduct83ee5151e18552493e5441543f6cc8cb",
    "display" : "08/08/2003Measles, Mumps and RubellaMeasles, Mumps and Rubella Vaccine, Live, AttenuatedVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeningococcalACYW135conjProduct4caa75a5785775ab99aa60248da4fc29",
    "display" : "21/03/2014Meningococcal ACYW-135 (conjugate vaccine)MenactraVial1Sanofi Pasteur Inc.CBER/FDA"
  },
  {
    "code" : "MenigococcalACYWXPolysacProduct62f4ead3da74f2f31a51006339af12fe",
    "display" : "06/07/2023Menigococcal ACYWX (Polysaccharide conjugate)MenFive™Vial + Ampoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MenigococcalACYWXPolysacProduct6e9e4e4a66528692b80623cf9b12d209",
    "display" : "06/07/2023Menigococcal ACYWX (Polysaccharide conjugate)MenFive™Vial + Ampoule5Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeningococcalAConjugate5Product59a4a8dd61e6115a46849c83d7b6fd2c",
    "display" : "30/12/2014Meningococcal A Conjugate 5 µgMeningococcal A Conjugate 5 micrograms MenAfriVac 5µgVial + Ampoule10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeningococcalAConjugate1Product41addf46a75c0e97534853e5745f15d0",
    "display" : "23/06/2010Meningococcal A Conjugate 10 µgMeningococcal A Conjugate MenAfriVacVial + Ampoule10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeningococcalACYW135TetaProduct85e37fdf8b368c828f1e3bf048f6ca6d",
    "display" : "28/01/2022Meningococcal ACYW-135 Tetanus Toxoid (conjugate vaccine)MenQuadfiVial1Sanofi Pasteur Inc.European Medicines Agency"
  },
  {
    "code" : "MeningococcalACYW135conjProduct95cae3b1768b8647e3f971137397d84f",
    "display" : "31/07/2013Meningococcal ACYW-135 (conjugate vaccine)MenveoTwo vial set (active + active)1GlaxoSmithKline Vaccines S.r.l.European Medicines Agency"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProductcea74be2c728329aad7b9b33ae16a0b1",
    "display" : "03/11/2009Polio Vaccine - Oral (OPV) Monovalent Type 1Monovalent Oral Poliomyelitis Vaccine Type 1 (mOPV1)Vial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProductef716e2b9567223ce6c95b090480ecfe",
    "display" : "21/06/2019Polio Vaccine - Oral (OPV) Monovalent Type 2Monovalent Oral Poliomyelitis Vaccine Type 2Vial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProductae7e506ca48a3aa605b188cd11eaceab",
    "display" : "03/11/2009Polio Vaccine - Oral (OPV) Monovalent Type 1Monovalent type 1 Oral Poliomyelitis vaccine, IP (mOPV1)Vial20Haffkine Bio Pharmaceutical Corporation LtdCentral Drugs Standard Control Organization"
  },
  {
    "code" : "MalariaProduct483f7a671c76d38fef929bed60c3934f",
    "display" : "15/07/2022MalariaMosquirixTwo vial set (active + active)2GlaxoSmithKline Biologicals SAEuropean Medicines Agency"
  },
  {
    "code" : "EbolavaccineMVABNFilorecProducte447fe0b4d8469dedecdf17870fdae80",
    "display" : "27/04/2021Ebola vaccine (MVA-BN-Filo [recombinant])MvabeaVial1Janssen Cilag International N.V.European Medicines Agency"
  },
  {
    "code" : "YellowFeverProductd2c75a15ed309658b3968519ddb31690",
    "display" : "26/03/2009Yellow Fevern/aAmpoule2Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products», Russian Academy of SciencesFederal Service on Surveillance in Healthcare (ROSZDRAVNADZOR) of the Russian Federation"
  },
  {
    "code" : "YellowFeverProduct771d1a5c0acaee3e2dc9d56af1aba49d",
    "display" : "26/03/2009Yellow Fevern/aAmpoule5Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products», Russian Academy of SciencesFederal Service on Surveillance in Healthcare (ROSZDRAVNADZOR) of the Russian Federation"
  },
  {
    "code" : "YellowFeverProducte929626497bdbb71adbe925f0c09c79f",
    "display" : "26/03/2009Yellow Fevern/aAmpoule10Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products», Russian Academy of SciencesFederal Service on Surveillance in Healthcare (ROSZDRAVNADZOR) of the Russian Federation"
  },
  {
    "code" : "InfluenzaPandemicH1N1Product48693eb423ca747a21dc8951d0c84948",
    "display" : "26/11/2012Influenza, Pandemic (H1N1)NASOVAC Influenza Vaccine, Live Attenuated (Human) Freeze-DriedVial + Ampoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "InfluenzaPandemicH1N1Product7168c312db80310f2cd6012ffa5e2f8f",
    "display" : "26/11/2012Influenza, Pandemic (H1N1)NASOVAC Influenza Vaccine, Live Attenuated (Human) Freeze-DriedVial + Ampoule5Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProducteb55e6f37bc19bec445ee030c5bce405",
    "display" : "30/09/2015Influenza, seasonal (Trivalent)Nasovac-S Influenza Vaccine, Live, Attenuated (Human)Vial + Ampoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeningococcalACYW135conjProductb59403bf43f59483bc3d5811fbbe99ae",
    "display" : "31/08/2016Meningococcal ACYW-135 (conjugate vaccine)NimenrixVial + Ampoule1Pfizer Europe MA EEIGEuropean Medicines Agency"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct844b4cd71587aa7b05205985fadc54bf",
    "display" : "06/07/2011Diphtheria-Tetanus (reduced antigen content)noneVial10PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct2d90fb090e2c500ab939d14b59fe7b4c",
    "display" : "17/09/2014Diphtheria-Tetanus (reduced antigen content)None used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  BE TdVial1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct765d85d2d2e92fc0aa155a4189f60843",
    "display" : "17/09/2014Diphtheria-Tetanus (reduced antigen content)None used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  BE TdVial10Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct93f61c0e63644a7adbd43720ad096a6b",
    "display" : "09/03/2020Diphtheria-Tetanus (reduced antigen content)None used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  BE TdVial20Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "TetanusToxoidProductf9fde2170e347e77162f463b9c3a2753",
    "display" : "12/07/2012Tetanus ToxoidNone used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  BEtt.Vial1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "TetanusToxoidProduct5d2f3b492c9af0f21b268c22a11400c0",
    "display" : "12/07/2012Tetanus ToxoidNone used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  BEtt.Vial10Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "TetanusToxoidProduct28645bb5f0babbccee86ce69b98ec9d6",
    "display" : "21/12/2009Tetanus ToxoidNone used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  BEtt.Vial20Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct493bac374b484cee83f218d75bca265e",
    "display" : "18/05/2012Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bNone used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  ComBE Five (Liquid).Vial1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct588074b4bc22a6afb41276d6e3a1bc57",
    "display" : "27/11/2014Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bNone used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  ComBE Five (Liquid).Vial2Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct32779e6bf47670e22e3b351cfc5530c4",
    "display" : "27/11/2014Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bNone used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  ComBE Five (Liquid).Vial5Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProducte3b135252953c7f29f4a82b3cdfded35",
    "display" : "18/05/2012Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bNone used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  ComBE Five (Liquid).Vial10Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct120c366956f5490de6fe5fa85ba7e9ae",
    "display" : "01/09/2011Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bNone used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  ComBE Five (Reconstituted).Two vial set (active + active)1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct520f511adb804a1ca5d7fa29d15799b3",
    "display" : "01/09/2011Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bNone used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  ComBE Five (Reconstituted).Two vial set (active + active)10Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProducta0ac41f8d8a64a093a5e07f7c9bbc8e4",
    "display" : "31/07/2014Diphtheria-Tetanus-Pertussis (whole cell)None used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  TRIPVACVial1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct76f7fbefcf37814d2dbf2af5d784ad74",
    "display" : "31/07/2014Diphtheria-Tetanus-Pertussis (whole cell)None used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  TRIPVACVial10Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProductf6d840e9cf722a80b38d0be001f47caf",
    "display" : "14/01/2016Polio Vaccine - Oral (OPV) Monovalent Type 2ORAL MONOVALENT TYPE 2 POLIOMYELITIS VACCINE (mOPV2)Vial20Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "PolioVaccineOralOPVTrivaProducte0bcdc085107751b3df34ad04620ac21",
    "display" : "31/08/2020Polio Vaccine - Oral (OPV) TrivalentOral Poliomyelitis Vaccines (Oral Drops)Vial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "InfluenzaPandemicH5N1Product98147a8d5841bb5826a0742c93febdb7",
    "display" : "18/12/2020Influenza, Pandemic (H5N1)Pandemic Live Attenuated VaccineSprayer1AstraZeneca Pharmaceuticals LP.European Medicines Agency"
  },
  {
    "code" : "InfluenzaPandemicH1N1Product088d100de56d00ac49ab0a216ffd4424",
    "display" : "22/01/2010Influenza, Pandemic (H1N1)PanenzaVial10Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "InfluenzaPandemicH1N1Product526f1bed643beeed056c10f07a683f71",
    "display" : "01/12/2009Influenza, Pandemic (H1N1)PanvaxVial10Seqirus LimitedTherapeutic Goods Administration"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct4aadc8e795e664423aad5161f0118f34",
    "display" : "19/12/2014Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bPentabioVial5PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "DiphtheriaTetanusPertussProduct54d8790e5e5db152340b4fd96e6f2f11",
    "display" : "19/12/2014Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type bPentabioVial10PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "PolioVaccineInactivatedIProduct096d9e8c31e30cc1148311ee66359a50",
    "display" : "21/04/2020Polio Vaccine - Inactivated (IPV)PicovaxVial5AJ Vaccines A/SDanish Medicines Agency"
  },
  {
    "code" : "PneumococcalconjugateProduct81604632fc612703d280e60af24938ea",
    "display" : "18/12/2019Pneumococcal (conjugate)PNEUMOSIL®Vial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PneumococcalconjugateProduct300c6fe07dc895ee2b3022528850d26e",
    "display" : "18/12/2019Pneumococcal (conjugate)PNEUMOSIL®Vial5Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PneumococcalconjugateProduct82c42719edaea37e1696ebde6674128c",
    "display" : "19/01/2024Pneumococcal (conjugate)PNEUMOSILVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProduct7d442364610244382098e1c4a3ba54c3",
    "display" : "29/10/2009Polio Vaccine - Oral (OPV) Monovalent Type 1Polio Sabin Mono T1Vial10GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProduct4580ab03228ed6c70bb6c117b408f7e5",
    "display" : "29/10/2009Polio Vaccine - Oral (OPV) Monovalent Type 1Polio Sabin Mono T1Vial20GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProduct7a252b223173567f21721ee15a36f057",
    "display" : "05/10/2010Polio Vaccine - Oral (OPV) Monovalent Type 3Polio Sabin Mono Three (oral)Vial10GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProductf22fcdfa611173d0afbce56d49867530",
    "display" : "05/10/2010Polio Vaccine - Oral (OPV) Monovalent Type 3Polio Sabin Mono Three (oral)Vial20GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProduct1b2bdb769d38e0b45eb60707ff9a36cb",
    "display" : "11/05/2011Polio Vaccine - Oral (OPV) Monovalent Type 2Polio Sabin Mono Two (oral)Vial10GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "PolioVaccineOralOPVMonovProductb4755cab194f57a5fecc8d890856bbdf",
    "display" : "11/05/2011Polio Vaccine - Oral (OPV) Monovalent Type 2Polio Sabin Mono Two (oral)Vial20GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProduct14c88c2e9b35698b4726903940c58037",
    "display" : "29/10/2009Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Polio Sabin One and ThreeVial10GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProduct2d10261076734e48cd7b289de6ea802e",
    "display" : "29/10/2009Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Polio Sabin One and ThreeVial20GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "PolioVaccineInactivatedIProductc726fd7210023aa5738617a79cae2b40",
    "display" : "06/12/2010Polio Vaccine - Inactivated (IPV)Poliomyelitis vaccineVial1Bilthoven Biologicals B.V.Medicines Evaluation Board (MEB)"
  },
  {
    "code" : "PolioVaccineNovelOralnOPProduct65b137f0201901bc43fc8759e4f35f35",
    "display" : "29/07/2024Polio Vaccine - Novel Oral (nOPV) Type 2Poliomyelitis Vaccine - Novel Oral (nOPV) Type 2Vial20Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineNovelOralnOPProduct278e9af5dc50904dd144a7ceb4d42dd7",
    "display" : "27/12/2023Polio Vaccine - Novel Oral (nOPV) Type 2Polio Vaccine - Novel Oral (nOPV) Type 2Vial50PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "PolioVaccineNovelOralnOPProductab7589153ddbc7968e1749119c5b1678",
    "display" : "29/07/2024Polio Vaccine - Novel Oral (nOPV) Type 2Poliomyelitis Vaccine - Novel Oral (nOPV) Type 2Vial50Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineInactivatedIProduct1d63ab46cee67d02439c47ed91439667",
    "display" : "28/10/2016Polio Vaccine - Inactivated (IPV)Poliomyelitis Vaccine (Inactivated)Vial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineInactivatedIProduct13e82343f8e192fe6e3fbfbf2a47ffd7",
    "display" : "28/10/2016Polio Vaccine - Inactivated (IPV)Poliomyelitis Vaccine (Inactivated)Vial2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineInactivatedIProductf8085a2bd9a1c84fba1adee2ec6f6fb1",
    "display" : "28/10/2016Polio Vaccine - Inactivated (IPV)Poliomyelitis Vaccine (Inactivated)Vial5Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineInactivatedIProductfea93261bf2f096ea48aed825522dc2d",
    "display" : "11/07/2019Polio Vaccine - Inactivated (IPV)Poliomyelitis Vaccine (Inactivated)Vial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProductdcbfa0a541c65032a917c39fa762c2f9",
    "display" : "21/12/2017Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Poliomyelitis Vaccine (live, oral attenuated, human Diploid Cell), type 1 and 3Vial20Beijing Institute of Biological Products Co., Ltd.National Medical Products Administration"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProduct06bf2d06adcc6d9e2bea8ac21846bb09",
    "display" : "22/10/2014Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Poliomyelitis Vaccine (Oral), Bivalent types 1 and 3Vial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineOralOPVBivalProducta5416e91021f0c00915e4688ff508717",
    "display" : "04/02/2013Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3Poliomyelitis Vaccine (Oral), Bivalent types 1 and 3Vial20Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineInactivatedSProduct2050ea67709cfcde28a01f0546276e96",
    "display" : "06/06/2022Polio Vaccine - Inactivated Sabin (sIPV)Poliomyelitis Vaccine (Vero Cell), Inactivated, Sabin StrainsVial1Sinovac Biotech Co. LtdNational Medical Products Administration"
  },
  {
    "code" : "PolioVaccineInactivatedSProduct25383b1f589d42af3719c7074f982c9b",
    "display" : "15/02/2022Polio Vaccine - Inactivated Sabin (sIPV)Poliomyelitis Vaccine (Vero Cell), Inactivated, Sabin StrainsVial1Beijing Institute of Biological Products Co., Ltd.National Medical Products Administration"
  },
  {
    "code" : "PolioVaccineInactivatedSProductd554f4c3848920ca8bcd00d44afd18a4",
    "display" : "29/08/2024Polio Vaccine - Inactivated Sabin (sIPV)Poliomyelitis Vaccine (Vero Cell), Inactivated, Sabin StrainsVial5Sinovac Biotech Co. LtdNational Medical Products Administration"
  },
  {
    "code" : "PolioVaccineInactivatedIProduct3cde3a30cacdc23b9ec3bdf4ba9d23ff",
    "display" : "28/11/2014Polio Vaccine - Inactivated (IPV)Poliomyelitis vaccine multidoseVial5Bilthoven Biologicals B.V.Medicines Evaluation Board (MEB)"
  },
  {
    "code" : "PolioVaccineInactivatedIProduct4562bbd80c6e57dbe29b122817623854",
    "display" : "29/02/2024Polio Vaccine - Inactivated (IPV)Poliomyelitis vaccine multidoseVial10Bilthoven Biologicals B.V.Medicines Evaluation Board (MEB)"
  },
  {
    "code" : "PolioVaccineOralOPVTrivaProductbd7faeaf3f0e633420fba396895d6cc9",
    "display" : "02/02/2006Polio Vaccine - Oral (OPV) TrivalentPolioviral vaccineVial20Haffkine Bio Pharmaceutical Corporation LtdCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PneumococcalconjugateProductd76340c94c13863d00dcf437778fc804",
    "display" : "20/08/2010Pneumococcal (conjugate)Prevenar 13Vial1Pfizer Europe MA EEIGEuropean Medicines Agency"
  },
  {
    "code" : "PneumococcalconjugateProduct083cce20a86e6f530b905d4d6e72136c",
    "display" : "14/07/2016Pneumococcal (conjugate)Prevenar 13 Multidose VialVial4Pfizer Europe MA EEIGEuropean Medicines Agency"
  },
  {
    "code" : "MeaslesMumpsandRubellaProducta83fd7c161c4c48ad786e3ff49073adf",
    "display" : "09/03/2001Measles, Mumps and RubellaPriorixVial1GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "MeaslesMumpsandRubellaProduct5391a66b3bec700dd62d02c2687a9f2f",
    "display" : "21/12/2011Measles, Mumps and RubellaPriorixVial2GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "DengueTetravalentliveattProducta742565a0d07d6c92f087a1c055ab278",
    "display" : "09/05/2024Dengue Tetravalent (live, attenuated)QdengaTwo vial set (active + excipient)1Takeda GmbH.European Medicines Agency"
  },
  {
    "code" : "HaemophilusinfluenzaetypProduct99ca7b265fb87731abd4ff27d13b44cd",
    "display" : "26/04/2010Haemophilus influenzae type bQuimi-HibVial1Centro de Ingenieria Genetica y BiotecnologiaCentro para el Control Estatal de la Calidad de los Medicamentos"
  },
  {
    "code" : "MalariaProduct34cd73607a9432893b41df94a5a9d0d2",
    "display" : "19/12/2023MalariaCYVACVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RabiesProductf2b192bfc92c1c7871308ada29a061c4",
    "display" : "20/12/2018RabiesRabies Vaccine Inactivated (Freeze Dried)(RABIVAX-S)Vial + Ampoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "MeaslesMumpsandRubellaProductf53615897edbe997d964e625d344ccdc",
    "display" : "06/01/2009Measles, Mumps and RubellarHA M-M-R IIVial1Merck Sharp & Dohme LLCEuropean Medicines Agency"
  },
  {
    "code" : "RotavirusProduct0b0dd154bb4274f5fd8784b59e2fe275",
    "display" : "12/03/2009RotavirusRotarixPlastic Tube1GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "RotavirusProduct53fcb319f717ccabdb38629caa624b20",
    "display" : "14/02/2019RotavirusRotarixPlastic Tube5GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "RotavirusProductbc017d15d7f431bd0424354df11c18c8",
    "display" : "12/03/2009RotavirusRotarixApplicator1GlaxoSmithKline Biologicals SAFederal Agency for Medicines and Health Products"
  },
  {
    "code" : "RotavirusliveattenuatedProductaba1269c8eed435e58d27f99062aab7f",
    "display" : "21/09/2018Rotavirus (live, attenuated)ROTASIILTwo vial set (active + excipient)1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusliveattenuatedProduct846073e8efc59e6bde4f3aa8c7008f8e",
    "display" : "21/09/2018Rotavirus (live, attenuated)ROTASIILTwo vial set (active + excipient)2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusliveattenuatedProduct5d0aee9435820780b60fc3f11ce1cfb0",
    "display" : "13/09/2023Rotavirus (live, attenuated)ROTASIIL-LiquidVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusliveattenuatedProduct84971742b6ec638f100087e1907dd8ad",
    "display" : "08/10/2021Rotavirus (live, attenuated)ROTASIIL-LiquidVial2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusliveattenuatedProducta28f27ab86847575f0c86632fa40e736",
    "display" : "18/02/2021Rotavirus (live, attenuated)ROTASIIL-LiquidPlastic Tube1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusliveattenuatedProductbab8551131e5a5ecce02dcb55bce1647",
    "display" : "28/01/2020Rotavirus (live, attenuated)ROTASIIL®ThermoTwo vial set (active + excipient)1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusliveattenuatedProductc988bcb87cb2a881e4e0193a1794c184",
    "display" : "28/01/2020Rotavirus (live, attenuated)ROTASIIL®ThermoTwo vial set (active + excipient)2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusProductf4c0952b7ac2caea70a5dd2b4e44a705",
    "display" : "07/10/2008RotavirusRotateqPlastic Tube1Merck Sharp & Dohme LLCCBER/FDA"
  },
  {
    "code" : "RotavirusliveattenuatedProducta4d4cf1eeafbb570eaec6b91bd8c1642",
    "display" : "05/01/2018Rotavirus (live, attenuated)RotavacVial5Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusliveattenuatedProduct247d96f0d9d687ba45daac8fd4aef6e1",
    "display" : "05/01/2018Rotavirus (live, attenuated)RotavacVial10Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusliveattenuatedProduct6cf88a56e306e621e5f6c06e754d492d",
    "display" : "18/06/2021Rotavirus (live, attenuated)ROTAVAC 5D®Vial1Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "RotavirusliveattenuatedProduct44f5911f2722c9c2ab4caa5e4a2ee009",
    "display" : "18/06/2021Rotavirus (live, attenuated)ROTAVAC 5D®Vial5Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "RubellaProductb58ecc88973c368d2929674f7588dcaf",
    "display" : "01/09/2006RubellaRubella Vaccine, Live, AttenuatedVial1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RubellaProduct92d62b88e7a6bda1cdffd774c099112d",
    "display" : "01/09/2006RubellaRubella Vaccine, Live, AttenuatedVial2Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RubellaProduct5256bec4bd8bae0e45743e9d569db466",
    "display" : "01/09/2006RubellaRubella Vaccine, Live, AttenuatedVial5Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "RubellaProduct0bb48b4861045ee347f5539609d92bbd",
    "display" : "01/09/2006RubellaRubella Vaccine, Live, AttenuatedVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProduct1de83fee04f2d8630ea4ff089ae47443",
    "display" : "25/05/2018Influenza, seasonal (Trivalent)SerinfluVial1Abbott Biologicals BVMedicines Evaluation Board (MEB)"
  },
  {
    "code" : "cholerainactivatedoralProductbcc643f5ed406d46ed23bf1e0ff46cd1",
    "display" : "29/09/2011cholera: inactivated oralShancholVial1Sanofi Healthcare India Private LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineInactivatedIProduct81ee9ba77c4419bbfe44a27cfd10027e",
    "display" : "01/10/2018Polio Vaccine - Inactivated (IPV)ShanIPV™Vial5Sanofi Healthcare India Private LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "PolioVaccineInactivatedIProduct8b13b5fcf5e9268b345775be7c3f077c",
    "display" : "22/04/2022Polio Vaccine - Inactivated (IPV)ShanIPV™Vial10Sanofi Healthcare India Private LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "YellowFeverProduct01a3b83cf13e87948437db11cf5c34eb",
    "display" : "14/10/2022Yellow FeverSinSaVac™Vial10Federal State Autonomous Scientific Institution «Chumakov Federal Scientific Center for Research & Development of Immune-And Biological Products», Russian Academy of SciencesFederal Service on Surveillance in Healthcare (ROSZDRAVNADZOR) of the Russian Federation"
  },
  {
    "code" : "InfluenzaseasonalQuadrivProduct857b54237833aa49172d24b749788cd8",
    "display" : "27/12/2019Influenza, seasonal (Quadrivalent)SKYCellflu Quadrivalent inj.Vial1SK Bioscience Co., Ltd.Ministry of Food and Drug Safety"
  },
  {
    "code" : "InfluenzaseasonalQuadrivProduct2329c9c335034cc9d169c85cb142f137",
    "display" : "27/12/2019Influenza, seasonal (Quadrivalent)SKYCellflu Quadrivalent Multi inj.Vial10SK Bioscience Co., Ltd.Ministry of Food and Drug Safety"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProducta7caaed8ed28906a817fdfe7f26bb696",
    "display" : "15/05/2019Influenza, seasonal (Trivalent)SKYCellflu® inj.Vial1SK Bioscience Co., Ltd.Ministry of Food and Drug Safety"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProductbc5b1b4b2ba40fb3b9743077a086766e",
    "display" : "08/04/2019Influenza, seasonal (Trivalent)SKYCellflu® Multi inj.Vial10SK Bioscience Co., Ltd.Ministry of Food and Drug Safety"
  },
  {
    "code" : "TyphoidConjugateProduct14f33effe6b84f89d3c5d07663cce92b",
    "display" : "21/02/2024Typhoid (Conjugate)SKYTyphoid Multi Inj.Vial5SK Bioscience Co., Ltd.Ministry of Food and Drug Safety"
  },
  {
    "code" : "VaricellaProduct8133c14443b0a3b1b10b846723961fee",
    "display" : "09/12/2019VaricellaSKYVaricella Inj.Two vial set (active + excipient)1SK Bioscience Co., Ltd.Ministry of Food and Drug Safety"
  },
  {
    "code" : "YellowFeverProductf82b015dfb3b1feeacd4c44d95b3b3ec",
    "display" : "20/03/2001Yellow FeverStabilized Yellow Fever VaccineAmpoule5Institut Pasteur de DakarMinistère de la Santé publique"
  },
  {
    "code" : "YellowFeverProduct223330a7c15da86b21cc363f591de002",
    "display" : "20/03/2001Yellow FeverStabilized Yellow Fever VaccineAmpoule10Institut Pasteur de DakarMinistère de la Santé publique"
  },
  {
    "code" : "YellowFeverProductffea8448252ee58b7a92add05f0c3431",
    "display" : "20/03/2001Yellow FeverStabilized Yellow Fever VaccineAmpoule20Institut Pasteur de DakarMinistère de la Santé publique"
  },
  {
    "code" : "YellowFeverProductd8a09f80301dc05e124f99ffe7711fc0",
    "display" : "01/01/1987Yellow FeverSTAMARILVial + Ampoule10Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "PneumococcalconjugateProductfcf21ee9ff8e209c022200a4d776dda0",
    "display" : "30/10/2009Pneumococcal (conjugate)SynflorixVial1GlaxoSmithKline Biologicals SAEuropean Medicines Agency"
  },
  {
    "code" : "PneumococcalconjugateProduct0defc68f369dcb9815e2bc4a6ee5533f",
    "display" : "19/03/2010Pneumococcal (conjugate)SynflorixVial2GlaxoSmithKline Biologicals SAEuropean Medicines Agency"
  },
  {
    "code" : "PneumococcalconjugateProduct1bc532b4004e4c37e8503a66c775e9cd",
    "display" : "16/10/2017Pneumococcal (conjugate)SynflorixVial4GlaxoSmithKline Biologicals SAEuropean Medicines Agency"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct015e0d747befdc032a505ac960851497",
    "display" : "09/05/2006Diphtheria-Tetanus (reduced antigen content)TetadifVial10BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)Bulgarian Drug Agency"
  },
  {
    "code" : "DiphtheriaTetanusreducedProduct36463c650975ef84b1519bc55647a533",
    "display" : "09/05/2006Diphtheria-Tetanus (reduced antigen content)TetadifVial20BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)Bulgarian Drug Agency"
  },
  {
    "code" : "TetanusToxoidProduct3d3b58060f5dc09709e826ea5b7f635d",
    "display" : "04/04/1995Tetanus ToxoidTetanus  Toxoid Vaccine AdsorbedVial10Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "TetanusToxoidProduct0cb7838cdb9015a56943ac3256e7c9e0",
    "display" : "04/04/1995Tetanus ToxoidTetanus  Toxoid Vaccine AdsorbedVial20Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "TetanusToxoidProduct918ff9b5bd4b52ff9f2adf81368501a5",
    "display" : "04/04/1995Tetanus ToxoidTetanus  Toxoid Vaccine AdsorbedAmpoule1Serum Institute of India Pvt. Ltd.Central Drugs Standard Control Organization"
  },
  {
    "code" : "TetanusToxoidProduct74a886b0b82debce2c05ff10507db46e",
    "display" : "09/05/2006Tetanus ToxoidTetatoxVial10BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)Bulgarian Drug Agency"
  },
  {
    "code" : "TetanusToxoidProduct1071c914359919dd58d72663a018511b",
    "display" : "09/05/2006Tetanus ToxoidTetatoxVial20BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)Bulgarian Drug Agency"
  },
  {
    "code" : "TetanusToxoidProductda7044cc9c5d3a1c5e4cb5c88ee081f0",
    "display" : "11/03/1999Tetanus ToxoidTT vaccineVial10PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "TetanusToxoidProductf8b5e42854cc1ae2255649171e9a8e5c",
    "display" : "11/03/1999Tetanus ToxoidTT vaccineVial20PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "TetanusToxoidProductd0dc36feabc50a33cc8f2f89d2342919",
    "display" : "29/10/2003Tetanus ToxoidTT vaccineUniject1PT Bio Farma (Persero)National Agency of Drug and Food Control Indonesia"
  },
  {
    "code" : "TyphoidConjugateProductc8a79556c41225d558dae1807a41b38f",
    "display" : "22/12/2017Typhoid (Conjugate)Typbar-TCVVial1Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "TyphoidConjugateProduct1bd8cf70f560d4ac1a937963c2fd44ba",
    "display" : "22/12/2017Typhoid (Conjugate)Typbar-TCVVial5Bharat Biotech International LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "TyphoidConjugateProduct2ae65ee169c9a71896965301d90f4ee2",
    "display" : "04/12/2020Typhoid (Conjugate)TYPHIBEV®Vial1Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "TyphoidConjugateProduct888fc7936a47fcc7c2f59c465bb8e7ed",
    "display" : "04/12/2020Typhoid (Conjugate)TYPHIBEV®Vial5Biological E. LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "VaricellaProduct0997806769699913a3f450d32a1932b4",
    "display" : "03/11/2022VaricellaVaricella Vaccine, LiveVial1Sinovac (Dalian) Vaccine Technology Co., Ltd.National Medical Products Administration"
  },
  {
    "code" : "VaricellaProduct640db8992fe6d85bb1aed3872583dd5c",
    "display" : "09/02/2018VaricellaVarivaxTwo vial set (active + excipient)1Merck Sharp & Dohme LLCCBER/FDA"
  },
  {
    "code" : "InfluenzaseasonalTrivaleProduct60da9ef23c1068c0b6922abd7e25ff17",
    "display" : "30/06/2011Influenza, seasonal (Trivalent)VaxigripVial10Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "InfluenzaseasonalQuadrivProducta39febbd4fc1b31f1ea3e43bc91baea0",
    "display" : "15/10/2020Influenza, seasonal (Quadrivalent)VaxigripTetraVial10Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "RabiesProduct3a0b2112f0d5e10d24b6063b5e91a025",
    "display" : "06/02/2019RabiesVaxiRab NVial1Zydus Lifesciences LimitedCentral Drugs Standard Control Organization"
  },
  {
    "code" : "RabiesProducte3f874e7b89ed3e777f03ede68bb6fe5",
    "display" : "22/06/2005RabiesVERORABVial1Sanofi PasteurAgence nationale de sécurité du médicament et des produits de santé"
  },
  {
    "code" : "HumanPapillomavirusBivalProduct2ce0838fa87a21625f2bb12e269b26a2",
    "display" : "02/08/2024Human Papillomavirus (Bivalent)Walrinvax®Vial1Yuxi Zerun Biotechnology Co., LtdNational Medical Products Administration"
  },
  {
    "code" : "YellowFeverProductab01f006f8b24113f4a28cb50bfe6d9d",
    "display" : "17/10/2001Yellow FeverYellow FeverTwo vial set (active + excipient)5Bio-Manguinhos/FiocruzAgencia Nacional da Vigilancia Sanitaria"
  },
  {
    "code" : "YellowFeverProduct5f0639d8e4d52afef089aa7148c5060c",
    "display" : "10/12/2007Yellow FeverYellow FeverTwo vial set (active + excipient)10Bio-Manguinhos/FiocruzAgencia Nacional da Vigilancia Sanitaria"
  },
  {
    "code" : "YellowFeverProducte0534dbc71a6cc09f56dce25216c538c",
    "display" : "17/10/2001Yellow FeverYellow FeverTwo vial set (active + excipient)50Bio-Manguinhos/FiocruzAgencia Nacional da Vigilancia Sanitaria"
  },
  {
    "code" : "EbolavaccineAd26ZEBOVGPrProduct72c1ff5266fc6bf3683b0076c250cbff",
    "display" : "27/04/2021Ebola vaccine (Ad26.ZEBOV-GP [recombinant])ZabdenoVial1Janssen Cilag International N.V.European Medicines Agency"
  },
  {
    "code" : "TyphoidConjugateProductaa2deeb320b1ef154bbde64ba6ce78fe",
    "display" : "21/10/2024Typhoid (Conjugate)ZyVac®Vial5Zydus Lifesciences LimitedCentral Drugs Standard Control Organization"
  }]
}

```
