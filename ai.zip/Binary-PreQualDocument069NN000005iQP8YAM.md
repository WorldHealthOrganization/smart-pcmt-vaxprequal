# PreQual Document: Package Insert-pq_192_199_318_Pneumococcal_GSK_PI_2022 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Package Insert-pq_192_199_318_Pneumococcal_GSK_PI_2022**

## Example Binary: PreQual Document: Package Insert-pq_192_199_318_Pneumococcal_GSK_PI_2022

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iQP8YAM"
  },
  "documentName": "Package Insert-pq_192_199_318_Pneumococcal_GSK_PI_2022",
  "documentType": "ProductInsert",
  "versionId": "068NN000005z9lFYAQ",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
