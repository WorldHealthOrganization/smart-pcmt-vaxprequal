# PreQualDB1de83fee04f2d8630ea4ff089ae47443 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB1de83fee04f2d8630ea4ff089ae47443**

## Binary: PreQualDB1de83fee04f2d8630ea4ff089ae47443

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2018-05-25",
  "vaccineType": {
    "coding": [
      {
        "code": "InfluenzaseasonalTrivale",
        "display": "Influenza, seasonal (Trivalent)"
      }
    ]
  },
  "commercialName": "Serinflu",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 1,
  "manufacturer": {
    "text": "Abbott Biologicals BV"
  },
  "responsibleNRA": {
    "text": "Medicines Evaluation Board (MEB)"
  },
  "index": {
    "value": "1de83fee04f2d8630ea4ff089ae47443"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufactureraaca2980acaa19a41085d36efc6a5a84"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderba27f505e9f51f464d1a574696de85c5"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/InfluenzaseasonalTrivaleProduct1de83fee04f2d8630ea4ff089ae47443"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
