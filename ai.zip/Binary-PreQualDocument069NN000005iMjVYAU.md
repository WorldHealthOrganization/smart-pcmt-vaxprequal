# PreQual Document: Container Photo-pq_176_YF_2dose_FSBSI_active_container_image - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_176_YF_2dose_FSBSI_active_container_image**

## Example Binary: PreQual Document: Container Photo-pq_176_YF_2dose_FSBSI_active_container_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iMjVYAU"
  },
  "documentName": "Container Photo-pq_176_YF_2dose_FSBSI_active_container_image",
  "documentType": "Photo",
  "versionId": "068NN000005z5xZYAQ",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
