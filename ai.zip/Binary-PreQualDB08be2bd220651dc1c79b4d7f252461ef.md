# PreQualDB08be2bd220651dc1c79b4d7f252461ef - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB08be2bd220651dc1c79b4d7f252461ef**

## Binary: PreQualDB08be2bd220651dc1c79b4d7f252461ef

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2010-09-22",
  "vaccineType": {
    "coding": [
      {
        "code": "DiphtheriaTetanusPertuss",
        "display": "Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type b"
      }
    ]
  },
  "commercialName": "Diphtheria, Tetanus, Pertussis, Hepatitis B and Haemophilus influenzae type b Conjugate Vaccine Adsorbed",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 2,
  "manufacturer": {
    "text": "Serum Institute of India Pvt. Ltd."
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "08be2bd220651dc1c79b4d7f252461ef"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/DiphtheriaTetanusPertussProduct08be2bd220651dc1c79b4d7f252461ef"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
