# MeningococcalACYW135conjProduct4caa75a5785775ab99aa60248da4fc29 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **MeningococcalACYW135conjProduct4caa75a5785775ab99aa60248da4fc29**

## Binary: MeningococcalACYW135conjProduct4caa75a5785775ab99aa60248da4fc29

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/Product",
  "status": "active",
  "name": [
    {
      "nameType": "official",
      "value": "Menactra"
    }
  ],
  "manufacturer": {
    "reference": "Organization/Manufacturere22cd18269d4ef7420dadcc919bda6e0"
  },
  "doseQuantity": {
    "value": 1,
    "code": "doses",
    "system": "http://unitsofmeasure.org"
  },
  "classification": [
    {
      "coding": [
        {
          "code": "MeningococcalACYW135conj"
        }
      ]
    }
  ],
  "unitOfUse": {
    "coding": [
      {
        "code": "doses"
      }
    ]
  },
  "dosageForm": {
    "coding": [
      {
        "code": "Vial"
      }
    ]
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
