# PreQualDB2c48b25fdefb970fc85dbb63e04fe744 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB2c48b25fdefb970fc85dbb63e04fe744**

## Binary: PreQualDB2c48b25fdefb970fc85dbb63e04fe744

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "1996-11-22",
  "vaccineType": {
    "coding": [
      {
        "code": "HepatitisB",
        "display": "Hepatitis B"
      }
    ]
  },
  "commercialName": "Euvax B",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 1,
  "manufacturer": {
    "text": "LG Chem Ltd"
  },
  "responsibleNRA": {
    "text": "Ministry of Food and Drug Safety"
  },
  "index": {
    "value": "2c48b25fdefb970fc85dbb63e04fe744"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer83c80215b20b5251e1c62eac65c9e90a"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderd4e6bca678dea34fa256538a18200187"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/HepatitisBProduct2c48b25fdefb970fc85dbb63e04fe744"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
