# PreQual2c7bb1d3d1f6b656f2b91e6399ac8935 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual2c7bb1d3d1f6b656f2b91e6399ac8935**

## Binary: PreQual2c7bb1d3d1f6b656f2b91e6399ac8935

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "validityPeriod": {
    "start": "2004-11-12"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/HepatitisBProduct2c7bb1d3d1f6b656f2b91e6399ac8935"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
