# PreQualDB300c6fe07dc895ee2b3022528850d26e - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB300c6fe07dc895ee2b3022528850d26e**

## Binary: PreQualDB300c6fe07dc895ee2b3022528850d26e

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2019-12-18",
  "vaccineType": {
    "coding": [
      {
        "code": "Pneumococcalconjugate",
        "display": "Pneumococcal (conjugate)"
      }
    ]
  },
  "commercialName": "PNEUMOSIL®",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 5,
  "manufacturer": {
    "text": "Serum Institute of India Pvt. Ltd."
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "300c6fe07dc895ee2b3022528850d26e"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/PneumococcalconjugateProduct300c6fe07dc895ee2b3022528850d26e"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
