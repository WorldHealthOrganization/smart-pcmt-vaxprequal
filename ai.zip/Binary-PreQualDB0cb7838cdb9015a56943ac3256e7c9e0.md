# PreQualDB0cb7838cdb9015a56943ac3256e7c9e0 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB0cb7838cdb9015a56943ac3256e7c9e0**

## Binary: PreQualDB0cb7838cdb9015a56943ac3256e7c9e0

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "1995-04-04",
  "vaccineType": {
    "coding": [
      {
        "code": "TetanusToxoid",
        "display": "Tetanus Toxoid"
      }
    ]
  },
  "commercialName": "Tetanus  Toxoid Vaccine Adsorbed",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 20,
  "manufacturer": {
    "text": "Serum Institute of India Pvt. Ltd."
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "0cb7838cdb9015a56943ac3256e7c9e0"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/TetanusToxoidProduct0cb7838cdb9015a56943ac3256e7c9e0"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
