# Security and Privacy Considerations - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Deployment**](deployment.md)
* **Security and Privacy Considerations**

## Security and Privacy Considerations

This page will contain security and privacy considerations related to SMART Guidelines for **[insert health domain here]**.

For an illustrative, starting set of non-functional requirements, which includes security and privacy-related requirements from the Digital Adaptation Kit for **[insert health domain here]**, see the [Non-functional Requirements](non-functional-requirements.md).

