# PreQual918ff9b5bd4b52ff9f2adf81368501a5 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual918ff9b5bd4b52ff9f2adf81368501a5**

## Binary: PreQual918ff9b5bd4b52ff9f2adf81368501a5

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "validityPeriod": {
    "start": "1995-04-04"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/TetanusToxoidProduct918ff9b5bd4b52ff9f2adf81368501a5"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
