# PreQual01c42855480e72f00caf639ab9157baf - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual01c42855480e72f00caf639ab9157baf**

## Binary: PreQual01c42855480e72f00caf639ab9157baf

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holdera1ed2fb3196a19ac1010392bdc5e8646"
  },
  "validityPeriod": {
    "start": "1997-07-22"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/DiphtheriaTetanusreducedProduct01c42855480e72f00caf639ab9157baf"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
