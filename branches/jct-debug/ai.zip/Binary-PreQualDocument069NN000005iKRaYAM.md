# PreQual Document: pq_144_MMR_5dose_SII_vial%26diluent_image-2022 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: pq_144_MMR_5dose_SII_vial%26diluent_image-2022**

## Example Binary: PreQual Document: pq_144_MMR_5dose_SII_vial%26diluent_image-2022

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iKRaYAM"
  },
  "documentName": "pq_144_MMR_5dose_SII_vial%26diluent_image-2022",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005z3m6YAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
