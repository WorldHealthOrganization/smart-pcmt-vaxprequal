# Home - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/pcmt-vaxprequal/ImplementationGuide/smart.who.int.pcmt-vaxprequal | *Version*:0.2.0 |
| Draft as of 2026-04-02 | *Computable Name*:PCMTVAXPreQual |

 This DAK and set of implementation tools are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This WHO **[insert health domain here]** DAK **add content here**

### L1 Narrative guidelines

**[insert content here]**

### L2 Operational guidelines

The L2 **[insert health domain here]** Digital adaptation kit publications and implementations tools can be found here:

* [Published DAK Document]()
* [Link to core data dictionary]()
* [Link to decision support logic]()
* [Link to scheduling logic]()
* [Link to indicators table]()
* [Link to functional and non functional requirements]()

### L3 Machine readable guidelines

The L3 FHIR Implementation Guide for the **[insert health domain here]** SMART Guidelines is yet to be published. Links will be published here as soon as they're available.

### L4 Executable guidelines

Reference implementations representing the L4 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### L5 Dynamic guidelines

Content representing the L5 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### News

### Contact Us

Please let us know about your experience in using the DAK and questions you may have by contacting us at [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)

### License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 IGO License](http://creativecommons.org/licenses/by-nc-sa/3.0/igo/).

![](https://i.creativecommons.org/l/by-nc-sa/3.0/igo/88x31.png)

### Providing Feedback

 Feedback specific to this specification can provided through: 

* Clicking on one of the Feedbacks link to the right of any section header
* Sending an email to [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)
* Creating an issue on GitHub [pcmt-vaxprequal repository](https://github.com/WorldHealthOrganization/pcmt-vaxprequal)

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

This WHO **[insert health domain here]** Implementation Guide details how to use Health Level 7 (HL7) Fast Healthcare Interoperability Resources (FHIR) for consistent digital representation of **[insert health domain here]** services.

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This implementation guide includes a machine-readable representation of WHO guidelines for **[insert health domain here]**, as documented in the WHO Digital Adaptation Kit for **[insert health domain here]** (link forthcoming) and explicitly encodes computer-interoperable logic, including data models, terminologies, and logic expressions, in a computable language to support implementation of **[insert health domain here]** use cases by WHO Member States.

The guide is part of the [WHO SMART Guidelines approach](https://www.who.int/teams/digital-health-and-innovation/smart-guidelines) to support countries to integrate WHO global health and data recommendations into digital systems accurately and consistently. It defines a series of FHIR Resources, Profiles, Extensions, and Terminology based on the WHO **[insert health domain here]** Digital Adaptation Kit (link forthcoming).

Supporting guidance, recommendations, resources, and standards are included in the [References](references.md) and [Dependencies](dependencies.md).

### About this implementation guide

This implementation guide is broken into the following levels of [knowledge representation](https://hl7.org/fhir/uv/cpg/documentation-approach-06-01-levels-of-knowledge-representation.html):

* [Home](index.md) - contains references to the guidance, guidelines, policies and recommendations underpinning this implementation guide.
* [Business Requirements](business-requirements.md) - contains the requirements for this implementation guide including the definition of key concepts, use cases, and a data dictionary.
* [Data Models and Exchange](data-models-and-exchange.md) - contains the data models and data exchange protocols with actors and transactions defined.
* [Deployment Guidance ](deployment.md) - contains relevant technical specifications and guidance, testing resources, reference implementation materials, and supporting guidance for adaptation to local contexts.

This guide is prepared to facilitate digital implementation of WHO **[insert health domain here]** guidelines by providing FHIR-based computable representations of and implementation guidance for using the key components of the WHO **[insert health domain here]** digital adaptation kit (DAK):

* Health Interventions & Recommendations
* Generic Personas
* User Scenarios
* Business Processes & Workflows
* Core Data Elements
* Decision Support Logic
* Indicators & Monitoring
* Functional & Non-functional Requirements

This guide is a companion to the Digital Adaptation Kit (DAK) and should be used side-by-side with it. Implementers are strongly encouraged to make use of the Digital Adaptation Kit. The focus of this guide is on the explanation and use of the computable artifacts.

This guide assumes use of the following resources:

* [IPS Patient](http://hl7.org/fhir/uv/ips/StructureDefinition/Patient-uv-ips)
* [CPG ActivityDefinitions](https://hl7.org/fhir/uv/cpg/artifacts.html#activitydefinition-index)
* For a complete listing of the artifacts defined in this implementation guide, refer to the [Artifact Index](artifacts.md).
* A complete offline copy of this implementation guide can be found on the [Downloads](downloads.md) page.
* This Implementation Guide makes use of [Clinical Quality Language](https://cql.hl7.org/) for the decision support artifacts including the PlanDefinitions and Measures. They are used to express how a calculation should occur and can be used with a CQL engine in order to process the decision or indicator directly from the applicable FHIR resources. Links to this specification, the FHIR Clinical Practice Guidelines Speciciation, and other helpful resources can be found in the Support dropdown.

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "smart.who.int.pcmt-vaxprequal",
  "meta" : {
    "profile" : ["http://smart.who.int/smart-base/ImplementationGuide-SGImplementationGuide"]
  },
  "url" : "http://smart.who.int/pcmt-vaxprequal/ImplementationGuide/smart.who.int.pcmt-vaxprequal",
  "version" : "0.2.0",
  "name" : "PCMTVAXPreQual",
  "title" : "SMART Product Dataset for Prequalified Vaccines",
  "status" : "draft",
  "date" : "2026-04-02T16:08:13+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Data exchange specifications for Product Catalog supporting the SMART Guidelines",
  "packageId" : "smart.who.int.pcmt-vaxprequal",
  "license" : "CC0-1.0",
  "fhirVersion" : ["5.0.0"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r5",
    "version" : "7.1.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r5",
    "version" : "5.2.0"
  },
  {
    "id" : "smart_who_int_base",
    "uri" : "http://smart.who.int/base/ImplementationGuide/smart.who.int.base",
    "packageId" : "smart.who.int.base",
    "version" : "0.1.0"
  },
  {
    "id" : "smart_who_int_pcmt",
    "uri" : "http://smart.who.int/pcmt/ImplementationGuide/smart.who.int.pcmt",
    "packageId" : "smart.who.int.pcmt",
    "version" : "0.1.0"
  },
  {
    "id" : "IHE_ITI_mCSD",
    "uri" : "https://profiles.ihe.net/ITI/mCSD/ImplementationGuide/ihe.iti.mcsd",
    "packageId" : "ihe.iti.mcsd",
    "version" : "4.0.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r5#1.1.2"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualBulkSupplier0013X0000498p3IQAQ"
      },
      "name" : "PreQual Bulk Supplier: PT Bio Farma (Persero)",
      "description" : "WHO PreQual Bulk Supplier: PT Bio Farma (Persero)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualBulkSupplier"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005lDwoYAE"
      },
      "name" : "PreQual Document: -FVP-P-446-447_R21Malaria_SIIPL_PI-2023_1",
      "description" : "WHO PreQual Document: -FVP-P-446-447_R21Malaria_SIIPL_PI-2023_1 (Product Insert)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005lDn4YAE"
      },
      "name" : "PreQual Document: -FVP-P-446-447_R21Malaria_SIIPL_PI-2023_2",
      "description" : "WHO PreQual Document: -FVP-P-446-447_R21Malaria_SIIPL_PI-2023_2 (Product Insert)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iAiPYAU"
      },
      "name" : "PreQual Document: Container Photo (Bigger Higher Resolution)-pq_125_DTP_1dose_SII_container_image",
      "description" : "WHO PreQual Document: Container Photo (Bigger Higher Resolution)-pq_125_DTP_1dose_SII_container_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i8GuYAI"
      },
      "name" : "PreQual Document: Container Photo (Bigger Higher Resolution)-pq_126_DTP_10dose_SII_container_image_VVM",
      "description" : "WHO PreQual Document: Container Photo (Bigger Higher Resolution)-pq_126_DTP_10dose_SII_container_image_VVM (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iJTxYAM"
      },
      "name" : "PreQual Document: Container Photo (Bigger Higher Resolution)-pq_137_TT_20dose_SII_container_image_VVM",
      "description" : "WHO PreQual Document: Container Photo (Bigger Higher Resolution)-pq_137_TT_20dose_SII_container_image_VVM (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hvDPYAY"
      },
      "name" : "PreQual Document: Container Photo (Bigger Higher Resolution)-pq_62_MMR_1dose_GSK_vial%2Bampl_image",
      "description" : "WHO PreQual Document: Container Photo (Bigger Higher Resolution)-pq_62_MMR_1dose_GSK_vial%2Bampl_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i48IYAQ"
      },
      "name" : "PreQual Document: Container Photo (Bigger Higher Resolution)-pq_64_OPV_20dose_Haffkine_vials_image_",
      "description" : "WHO PreQual Document: Container Photo (Bigger Higher Resolution)-pq_64_OPV_20dose_Haffkine_vials_image_ (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i1dXYAQ"
      },
      "name" : "PreQual Document: Container Photo (Bigger Higher Resolution)-pq_66_YF_20dose_IPD_carton%2Bampl_image",
      "description" : "WHO PreQual Document: Container Photo (Bigger Higher Resolution)-pq_66_YF_20dose_IPD_carton%2Bampl_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i0W8YAI"
      },
      "name" : "PreQual Document: Container Photo (Bigger Higher Resolution)-pq_67_YF_10dose_IPD_carton%2Bampl_image",
      "description" : "WHO PreQual Document: Container Photo (Bigger Higher Resolution)-pq_67_YF_10dose_IPD_carton%2Bampl_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i60aYAA"
      },
      "name" : "PreQual Document: Container Photo-pq_125_DTP_1dose_SII_container_image_580",
      "description" : "WHO PreQual Document: Container Photo-pq_125_DTP_1dose_SII_container_image_580 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iGHVYA2"
      },
      "name" : "PreQual Document: Container Photo-pq_126_DTP_10dose_SII_container_image_580",
      "description" : "WHO PreQual Document: Container Photo-pq_126_DTP_10dose_SII_container_image_580 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iLDxYAM"
      },
      "name" : "PreQual Document: Container Photo-pq_137_TT_20dose_SII_continer_image_VVM_580",
      "description" : "WHO PreQual Document: Container Photo-pq_137_TT_20dose_SII_continer_image_VVM_580 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iJyYYAU"
      },
      "name" : "PreQual Document: Container Photo-pq_138_MR_1dose_SII_vial%26ampoule_image-2022",
      "description" : "WHO PreQual Document: Container Photo-pq_138_MR_1dose_SII_vial%26ampoule_image-2022 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iGB5YAM"
      },
      "name" : "PreQual Document: Container Photo-pq_139_MR_2dose_SII_vial%26ampoule_image-2022",
      "description" : "WHO PreQual Document: Container Photo-pq_139_MR_2dose_SII_vial%26ampoule_image-2022 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iK8HYAU"
      },
      "name" : "PreQual Document: Container Photo-pq_142_MMR_1dose_SIIPL_vial%26diluent_image-2022",
      "description" : "WHO PreQual Document: Container Photo-pq_142_MMR_1dose_SIIPL_vial%26diluent_image-2022 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iLkDYAU"
      },
      "name" : "PreQual Document: Container Photo-pq_143_MMR_2dose_SII_vial%26diluent_image-2022",
      "description" : "WHO PreQual Document: Container Photo-pq_143_MMR_2dose_SII_vial%26diluent_image-2022 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iGiyYAE"
      },
      "name" : "PreQual Document: Container Photo-pq_144_MMR_5dose_SII_vial%26diluent_image-2022",
      "description" : "WHO PreQual Document: Container Photo-pq_144_MMR_5dose_SII_vial%26diluent_image-2022 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iKkwYAE"
      },
      "name" : "PreQual Document: Container Photo-pq_145_MMR_10dose_SII_vial%26diluent_image-2022",
      "description" : "WHO PreQual Document: Container Photo-pq_145_MMR_10dose_SII_vial%26diluent_image-2022 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iA7QYAU"
      },
      "name" : "PreQual Document: Container Photo-pq_146_Measles%20_1dose_SII_%20vial%26ampoule_image-2022",
      "description" : "WHO PreQual Document: Container Photo-pq_146_Measles%20_1dose_SII_%20vial%26ampoule_image-2022 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005kErVYAU"
      },
      "name" : "PreQual Document: Container Photo-pq_271_JE_live_5doses_Chengdu_vials_image_580",
      "description" : "WHO PreQual Document: Container Photo-pq_271_JE_live_5doses_Chengdu_vials_image_580 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005kGJsYAM"
      },
      "name" : "PreQual Document: Container Photo-pq_325_bOPV_1%263_20dose_BIBP_vial%26carton_image",
      "description" : "WHO PreQual Document: Container Photo-pq_325_bOPV_1%263_20dose_BIBP_vial%26carton_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hpfqYAA"
      },
      "name" : "PreQual Document: Container Photo-pq_62_MMR_1dose_GSK_vial%2Bampl_image_510",
      "description" : "WHO PreQual Document: Container Photo-pq_62_MMR_1dose_GSK_vial%2Bampl_image_510 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hxOcYAI"
      },
      "name" : "PreQual Document: Container Photo-pq_63_Rota_GSK_container%20image_2Dbarcode_2021",
      "description" : "WHO PreQual Document: Container Photo-pq_63_Rota_GSK_container%20image_2Dbarcode_2021 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hsVMYAY"
      },
      "name" : "PreQual Document: Container Photo-pq_64_OPV_20dose_Haffkine_vials_image_580",
      "description" : "WHO PreQual Document: Container Photo-pq_64_OPV_20dose_Haffkine_vials_image_580 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i2svYAA"
      },
      "name" : "PreQual Document: Container Photo-pq_66_YF_20dose_IPD_carton%2Bampl_image_580",
      "description" : "WHO PreQual Document: Container Photo-pq_66_YF_20dose_IPD_carton%2Bampl_image_580 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i57cYAA"
      },
      "name" : "PreQual Document: Container Photo-pq_67_YF_10dose_IPD_carton%2Bampl_image_580",
      "description" : "WHO PreQual Document: Container Photo-pq_67_YF_10dose_IPD_carton%2Bampl_image_580 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i0uTYAQ"
      },
      "name" : "PreQual Document: Container Photo-pq_68_317_BCG_JBL_vial%26ampoule_image-2020",
      "description" : "WHO PreQual Document: Container Photo-pq_68_317_BCG_JBL_vial%26ampoule_image-2020 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i5QyYAI"
      },
      "name" : "PreQual Document: Container Photo-pq_69_EuvaxB_1dose%28adult%29_LG_carton%26vial_image",
      "description" : "WHO PreQual Document: Container Photo-pq_69_EuvaxB_1dose%28adult%29_LG_carton%26vial_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i2ZZYAY"
      },
      "name" : "PreQual Document: Container Photo-pq_72_EuvaxB_10dose%28adult%29_LG_carton%26vial_image",
      "description" : "WHO PreQual Document: Container Photo-pq_72_EuvaxB_10dose%28adult%29_LG_carton%26vial_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i5aeYAA"
      },
      "name" : "PreQual Document: Container Photo-pq_72_EuvaxB_10dose%28paed%29_LG_carton%26vial_image",
      "description" : "WHO PreQual Document: Container Photo-pq_72_EuvaxB_10dose%28paed%29_LG_carton%26vial_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i0XuYAI"
      },
      "name" : "PreQual Document: Container Photo-pq_74_BCG_10dose_BB-NCIPD_container_image_active",
      "description" : "WHO PreQual Document: Container Photo-pq_74_BCG_10dose_BB-NCIPD_container_image_active (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i1VTYAY"
      },
      "name" : "PreQual Document: Container Photo-pq_74_BCG_10dose_BB-NCIPD_container_image_active",
      "description" : "WHO PreQual Document: Container Photo-pq_74_BCG_10dose_BB-NCIPD_container_image_active (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hziIYAQ"
      },
      "name" : "PreQual Document: Container Photo-pq_74_BCG_10dose_BB-NCIPD_container_image_diluent",
      "description" : "WHO PreQual Document: Container Photo-pq_74_BCG_10dose_BB-NCIPD_container_image_diluent (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i2JVYAY"
      },
      "name" : "PreQual Document: Container Photo-pq_74_BCG_10dose_BB-NCIPD_container_image_diluent",
      "description" : "WHO PreQual Document: Container Photo-pq_74_BCG_10dose_BB-NCIPD_container_image_diluent (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i7PWYAY"
      },
      "name" : "PreQual Document: Container Photo-pq_76_TT_10dose_BB-NCIPD_container_image",
      "description" : "WHO PreQual Document: Container Photo-pq_76_TT_10dose_BB-NCIPD_container_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hyzMYAQ"
      },
      "name" : "PreQual Document: Container Photo-pq_77_TT_20dose_BB-NCIPD_container_image",
      "description" : "WHO PreQual Document: Container Photo-pq_77_TT_20dose_BB-NCIPD_container_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i51DYAQ"
      },
      "name" : "PreQual Document: Container Photo-pq_78_DT_10dose_BB-NCIPD_carton_image",
      "description" : "WHO PreQual Document: Container Photo-pq_78_DT_10dose_BB-NCIPD_carton_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i9hYYAQ"
      },
      "name" : "PreQual Document: Container Photo-pq_79_DT_20dose_BB-NCIPD_carton_image",
      "description" : "WHO PreQual Document: Container Photo-pq_79_DT_20dose_BB-NCIPD_carton_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iAAVYA2"
      },
      "name" : "PreQual Document: Container Photo-pq_79_DT_20dose_BB-NCIPD_carton_image",
      "description" : "WHO PreQual Document: Container Photo-pq_79_DT_20dose_BB-NCIPD_carton_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i4mgYAA"
      },
      "name" : "PreQual Document: Container Photo-pq_81_Td_20dose_BB-NCIPD_container_image",
      "description" : "WHO PreQual Document: Container Photo-pq_81_Td_20dose_BB-NCIPD_container_image (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005kJG6YAM"
      },
      "name" : "PreQual Document: General-pq_325_bOPV_shipping%20box%20configuration-2023",
      "description" : "WHO PreQual Document: General-pq_325_bOPV_shipping%20box%20configuration-2023 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hzzuYAA"
      },
      "name" : "PreQual Document: General-pq_63_Rotavirus_1dose_GSK_plastic_tube_instruction_sheet",
      "description" : "WHO PreQual Document: General-pq_63_Rotavirus_1dose_GSK_plastic_tube_instruction_sheet (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i287YAA"
      },
      "name" : "PreQual Document: General-pq_63_Rotavirus_1dose_GSK_tubes_image_580",
      "description" : "WHO PreQual Document: General-pq_63_Rotavirus_1dose_GSK_tubes_image_580 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iFy9YAE"
      },
      "name" : "PreQual Document: Package Insert-pq_125_126_127_DTP_SII_PI-2020",
      "description" : "WHO PreQual Document: Package Insert-pq_125_126_127_DTP_SII_PI-2020 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iC2hYAE"
      },
      "name" : "PreQual Document: Package Insert-pq_125_126_127_DTP_SII_PI-2020",
      "description" : "WHO PreQual Document: Package Insert-pq_125_126_127_DTP_SII_PI-2020 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iHaBYAU"
      },
      "name" : "PreQual Document: Package Insert-pq_135_136_137_TT_SII_PI-2020",
      "description" : "WHO PreQual Document: Package Insert-pq_135_136_137_TT_SII_PI-2020 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iKMmYAM"
      },
      "name" : "PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-PAHO_2022",
      "description" : "WHO PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-PAHO_2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iHf1YAE"
      },
      "name" : "PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-PAHO_2022",
      "description" : "WHO PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-PAHO_2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iDEtYAM"
      },
      "name" : "PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-UNICEF_2022",
      "description" : "WHO PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-UNICEF_2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iLInYAM"
      },
      "name" : "PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-UNICEF_2022",
      "description" : "WHO PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-UNICEF_2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iKrOYAU"
      },
      "name" : "PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_PAHO-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_PAHO-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iL9AYAU"
      },
      "name" : "PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_PAHO-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_PAHO-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iCqdYAE"
      },
      "name" : "PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_PAHO-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_PAHO-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iLQxYAM"
      },
      "name" : "PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_PAHO-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_PAHO-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iGEMYA2"
      },
      "name" : "PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iJiVYAU"
      },
      "name" : "PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iLcCYAU"
      },
      "name" : "PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iIUfYAM"
      },
      "name" : "PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iK6fYAE"
      },
      "name" : "PreQual Document: Package Insert-pq_146_147_148_149_Measles_SII_PI_PAHO-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_146_147_148_149_Measles_SII_PI_PAHO-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iLnTYAU"
      },
      "name" : "PreQual Document: Package Insert-pq_146_147_148_149_Measles_SII_PI_UNICEF-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_146_147_148_149_Measles_SII_PI_UNICEF-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005kEQ6YAM"
      },
      "name" : "PreQual Document: Package Insert-pq_271_JE_live_5dose_Chengdu_PI-2019",
      "description" : "WHO PreQual Document: Package Insert-pq_271_JE_live_5dose_Chengdu_PI-2019 (Product Insert)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005kHUSYA2"
      },
      "name" : "PreQual Document: Package Insert-pq_323-324_HepA_1dose_Sinovac_PI-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_323-324_HepA_1dose_Sinovac_PI-2022 (Product Insert)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005kJhVYAU"
      },
      "name" : "PreQual Document: Package Insert-pq_325_bOPV_1%263_20dose_BIBP_PI-2019",
      "description" : "WHO PreQual Document: Package Insert-pq_325_bOPV_1%263_20dose_BIBP_PI-2019 (Product Insert)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005knsbYAA"
      },
      "name" : "PreQual Document: Package Insert-pq_357_Dengue_5dose_SP_PL-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_357_Dengue_5dose_SP_PL-2022 (Product Insert)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hx6rYAA"
      },
      "name" : "PreQual Document: Package Insert-pq_62_252_MMR_GSK_PI_2019",
      "description" : "WHO PreQual Document: Package Insert-pq_62_252_MMR_GSK_PI_2019 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i3fGYAQ"
      },
      "name" : "PreQual Document: Package Insert-pq_63%20Rota_liquid_1dose_GSK_PI_tube-2022",
      "description" : "WHO PreQual Document: Package Insert-pq_63%20Rota_liquid_1dose_GSK_PI_tube-2022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i3IgYAI"
      },
      "name" : "PreQual Document: Package Insert-pq_64_OPV_20dose_Haffkine_PI",
      "description" : "WHO PreQual Document: Package Insert-pq_64_OPV_20dose_Haffkine_PI (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i24tYAA"
      },
      "name" : "PreQual Document: Package Insert-pq_65_66_67_YF_5dose_IPD_PI",
      "description" : "WHO PreQual Document: Package Insert-pq_65_66_67_YF_5dose_IPD_PI (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i2OIYAY"
      },
      "name" : "PreQual Document: Package Insert-pq_65_66_67_YF_5dose_IPD_PI",
      "description" : "WHO PreQual Document: Package Insert-pq_65_66_67_YF_5dose_IPD_PI (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i4hmYAA"
      },
      "name" : "PreQual Document: Package Insert-pq_65_66_67_YF_5dose_IPD_PI",
      "description" : "WHO PreQual Document: Package Insert-pq_65_66_67_YF_5dose_IPD_PI (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i6DJYAY"
      },
      "name" : "PreQual Document: Package Insert-pq_68_317_BCG_JapanBCG_PI_082022",
      "description" : "WHO PreQual Document: Package Insert-pq_68_317_BCG_JapanBCG_PI_082022 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i2jEYAQ"
      },
      "name" : "PreQual Document: Package Insert-pq_69_HepB_1dose_LG_PI-2020_PAHO",
      "description" : "WHO PreQual Document: Package Insert-pq_69_HepB_1dose_LG_PI-2020_PAHO (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hwyuYAA"
      },
      "name" : "PreQual Document: Package Insert-pq_69_HepB_1dose_LG_PI-2020_UNICEF",
      "description" : "WHO PreQual Document: Package Insert-pq_69_HepB_1dose_LG_PI-2020_UNICEF (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i4mdYAA"
      },
      "name" : "PreQual Document: Package Insert-pq_72_HepB_10doses_LG_PI-2020_PAHO",
      "description" : "WHO PreQual Document: Package Insert-pq_72_HepB_10doses_LG_PI-2020_PAHO (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i2XxYAI"
      },
      "name" : "PreQual Document: Package Insert-pq_72_HepB_10doses_LG_PI-2020_UNICEF",
      "description" : "WHO PreQual Document: Package Insert-pq_72_HepB_10doses_LG_PI-2020_UNICEF (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005huyhYAA"
      },
      "name" : "PreQual Document: Package Insert-pq_74_75_BCG_BB-NCIPD_PI-2019",
      "description" : "WHO PreQual Document: Package Insert-pq_74_75_BCG_BB-NCIPD_PI-2019 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i1nFYAQ"
      },
      "name" : "PreQual Document: Package Insert-pq_74_75_BCG_BB-NCIPD_PI-2019",
      "description" : "WHO PreQual Document: Package Insert-pq_74_75_BCG_BB-NCIPD_PI-2019 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i9CoYAI"
      },
      "name" : "PreQual Document: Package Insert-pq_76_77_TT_BB-NCIPD_PI-2020",
      "description" : "WHO PreQual Document: Package Insert-pq_76_77_TT_BB-NCIPD_PI-2020 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i0HgYAI"
      },
      "name" : "PreQual Document: Package Insert-pq_76_77_TT_BB-NCIPD_PI-2020",
      "description" : "WHO PreQual Document: Package Insert-pq_76_77_TT_BB-NCIPD_PI-2020 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i5CfYAI"
      },
      "name" : "PreQual Document: Package Insert-pq_78_79_DT_BB-NCIPD_PI-2020",
      "description" : "WHO PreQual Document: Package Insert-pq_78_79_DT_BB-NCIPD_PI-2020 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iAIXYA2"
      },
      "name" : "PreQual Document: Package Insert-pq_78_79_DT_BB-NCIPD_PI-2020",
      "description" : "WHO PreQual Document: Package Insert-pq_78_79_DT_BB-NCIPD_PI-2020 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i65LYAQ"
      },
      "name" : "PreQual Document: Package Insert-pq_78_79_DT_BB-NCIPD_PI-2020",
      "description" : "WHO PreQual Document: Package Insert-pq_78_79_DT_BB-NCIPD_PI-2020 (Photo)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i0mQYAQ"
      },
      "name" : "PreQual Document: Package Insert-pq_80_81_Td_BB-NCIPD_PI-2020",
      "description" : "WHO PreQual Document: Package Insert-pq_80_81_Td_BB-NCIPD_PI-2020 (Vaccine General Document)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iFlFYAU"
      },
      "name" : "PreQual Document: pq_125_DTP_1dose_SII_container_image_580",
      "description" : "WHO PreQual Document: pq_125_DTP_1dose_SII_container_image_580 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i8GtYAI"
      },
      "name" : "PreQual Document: pq_126_DTP_10dose_SII_container_image_580",
      "description" : "WHO PreQual Document: pq_126_DTP_10dose_SII_container_image_580 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iJ7LYAU"
      },
      "name" : "PreQual Document: pq_137_TT_20dose_SII_continer_image_VVM_580",
      "description" : "WHO PreQual Document: pq_137_TT_20dose_SII_continer_image_VVM_580 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iKxrYAE"
      },
      "name" : "PreQual Document: pq_138_MR_1dose_SII_vial%26ampoule_image-2022",
      "description" : "WHO PreQual Document: pq_138_MR_1dose_SII_vial%26ampoule_image-2022 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iH8nYAE"
      },
      "name" : "PreQual Document: pq_139_MR_2dose_SII_vial%26ampoule_image-2022",
      "description" : "WHO PreQual Document: pq_139_MR_2dose_SII_vial%26ampoule_image-2022 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iKWQYA2"
      },
      "name" : "PreQual Document: pq_142_MMR_1dose_SIIPL_vial%26diluent_image-2022",
      "description" : "WHO PreQual Document: pq_142_MMR_1dose_SIIPL_vial%26diluent_image-2022 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iEvgYAE"
      },
      "name" : "PreQual Document: pq_143_MMR_2dose_SII_vial%26diluent_image-2022",
      "description" : "WHO PreQual Document: pq_143_MMR_2dose_SII_vial%26diluent_image-2022 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iKRaYAM"
      },
      "name" : "PreQual Document: pq_144_MMR_5dose_SII_vial%26diluent_image-2022",
      "description" : "WHO PreQual Document: pq_144_MMR_5dose_SII_vial%26diluent_image-2022 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iKTCYA2"
      },
      "name" : "PreQual Document: pq_145_MMR_10dose_SII_vial%26diluent_image-2022",
      "description" : "WHO PreQual Document: pq_145_MMR_10dose_SII_vial%26diluent_image-2022 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005iLQyYAM"
      },
      "name" : "PreQual Document: pq_146_Measles%20_1dose_SII_%20vial%26ampoule_image-2022",
      "description" : "WHO PreQual Document: pq_146_Measles%20_1dose_SII_%20vial%26ampoule_image-2022 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005kEZlYAM"
      },
      "name" : "PreQual Document: pq_271_JE_live_5doses_Chengdu_vials_image_580",
      "description" : "WHO PreQual Document: pq_271_JE_live_5doses_Chengdu_vials_image_580 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005kFnaYAE"
      },
      "name" : "PreQual Document: pq_325_bOPV_1%263_20dose_BIBP_vial%26carton_image",
      "description" : "WHO PreQual Document: pq_325_bOPV_1%263_20dose_BIBP_vial%26carton_image (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005huAeYAI"
      },
      "name" : "PreQual Document: pq_62_MMR_1dose_GSK_vial%2Bampl_image_510",
      "description" : "WHO PreQual Document: pq_62_MMR_1dose_GSK_vial%2Bampl_image_510 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hwh7YAA"
      },
      "name" : "PreQual Document: pq_63_Rota_GSK_container%20image_2Dbarcode_2021",
      "description" : "WHO PreQual Document: pq_63_Rota_GSK_container%20image_2Dbarcode_2021 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hykYYAQ"
      },
      "name" : "PreQual Document: pq_64_OPV_20dose_Haffkine_vials_image_580",
      "description" : "WHO PreQual Document: pq_64_OPV_20dose_Haffkine_vials_image_580 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i4HzYAI"
      },
      "name" : "PreQual Document: pq_66_YF_20dose_IPD_carton%2Bampl_image_580",
      "description" : "WHO PreQual Document: pq_66_YF_20dose_IPD_carton%2Bampl_image_580 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hzTfYAI"
      },
      "name" : "PreQual Document: pq_67_YF_10dose_IPD_carton%2Bampl_image_580",
      "description" : "WHO PreQual Document: pq_67_YF_10dose_IPD_carton%2Bampl_image_580 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hzjwYAA"
      },
      "name" : "PreQual Document: pq_68_317_BCG_JBL_vial%26ampoule_image-2020",
      "description" : "WHO PreQual Document: pq_68_317_BCG_JBL_vial%26ampoule_image-2020 (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005hyvmYAA"
      },
      "name" : "PreQual Document: pq_69_EuvaxB_1dose%28adult%29_LG_carton%26vial_image",
      "description" : "WHO PreQual Document: pq_69_EuvaxB_1dose%28adult%29_LG_carton%26vial_image (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i3AhYAI"
      },
      "name" : "PreQual Document: pq_72_EuvaxB_10dose%28adult%29_LG_carton%26vial_image",
      "description" : "WHO PreQual Document: pq_72_EuvaxB_10dose%28adult%29_LG_carton%26vial_image (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i873YAA"
      },
      "name" : "PreQual Document: pq_74_BCG_10dose_BB-NCIPD_container_image_active",
      "description" : "WHO PreQual Document: pq_74_BCG_10dose_BB-NCIPD_container_image_active (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i4umYAA"
      },
      "name" : "PreQual Document: pq_74_BCG_10dose_BB-NCIPD_container_image_active",
      "description" : "WHO PreQual Document: pq_74_BCG_10dose_BB-NCIPD_container_image_active (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i1aFYAQ"
      },
      "name" : "PreQual Document: pq_76_TT_10dose_BB-NCIPD_container_image",
      "description" : "WHO PreQual Document: pq_76_TT_10dose_BB-NCIPD_container_image (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i5igYAA"
      },
      "name" : "PreQual Document: pq_77_TT_20dose_BB-NCIPD_container_image",
      "description" : "WHO PreQual Document: pq_77_TT_20dose_BB-NCIPD_container_image (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i55zYAA"
      },
      "name" : "PreQual Document: pq_78_DT_10dose_BB-NCIPD_carton_image",
      "description" : "WHO PreQual Document: pq_78_DT_10dose_BB-NCIPD_carton_image (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i4gCYAQ"
      },
      "name" : "PreQual Document: pq_79_DT_20dose_BB-NCIPD_carton_image",
      "description" : "WHO PreQual Document: pq_79_DT_20dose_BB-NCIPD_carton_image (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i5UHYAY"
      },
      "name" : "PreQual Document: pq_80_Td_10dose_BB-NCIPD_container_image",
      "description" : "WHO PreQual Document: pq_80_Td_10dose_BB-NCIPD_container_image (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005i5XUYAY"
      },
      "name" : "PreQual Document: pq_81_Td_20dose_BB-NCIPD_container_image",
      "description" : "WHO PreQual Document: pq_81_Td_20dose_BB-NCIPD_container_image (Photo-Main Image)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualDocument069NN000005kEI2YAM"
      },
      "name" : "PreQual Document: VPSAR (Vaccine Public Summary Assessment Report)-pq_270_271_JE_live_Chengdu_VPSAR_12nov13",
      "description" : "WHO PreQual Document: VPSAR (Vaccine Public Summary Assessment Report)-pq_270_271_JE_live_Chengdu_VPSAR_12nov13 (VSPAR)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MihuUACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MihvUACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MihwUACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MihxUACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MihxUACIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MihyUACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MihyUACIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii0UACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii0UACIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii0UACIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii0UACIng4"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii1UACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii1UACIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii2UACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii2UACIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii3UACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii3UACIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii3UACIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii5UACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii6UACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii6UACIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii7UACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii8UACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii8UACIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii8UACIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii9UACIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii9UACIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006Mii9UACIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiAUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiAUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiAUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiBUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiBUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiBUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiBUASIng4"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiBUASIng5"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiCUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiCUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiDUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiDUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiEUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiEUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiEUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiFUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiFUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiGUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiGUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiGUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiHUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiHUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiHUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiHUASIng4"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiIUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiIUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiIUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiIUASIng4"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiJUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiJUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiJUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiJUASIng4"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiKUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiKUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiKUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiKUASIng4"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiLUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiMUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Diluent)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiMUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiNUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiNUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiNUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiNUASIng4"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiOUASIng1"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiOUASIng2"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiOUASIng3"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualIngredienta3K3X000006MiiOUASIng4"
      },
      "name" : "PreQual Ingredient: Vx FVP",
      "description" : "WHO PreQual Product Ingredient: Vx FVP (Active)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X0000498p4LQAQ"
      },
      "name" : "PreQual Manufacturer: Beijing Institute of Biological Products Co., Ltd.",
      "description" : "WHO PreQual Manufacturer: Beijing Institute of Biological Products Co., Ltd. (China)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X0000498p4LQAQ"
      },
      "name" : "PreQual Manufacturer: Beijing Institute of Biological Products Co., Ltd.",
      "description" : "Vaccine Manufacturer Organization: Beijing Institute of Biological Products Co., Ltd.",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X0000498p2jQAA"
      },
      "name" : "PreQual Manufacturer: Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "description" : "WHO PreQual Manufacturer: Bul Bio-National Center of Infectious and Parasitic Diseases Ltd. (Bulgaria)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X0000498p2jQAA"
      },
      "name" : "PreQual Manufacturer: Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "description" : "Vaccine Manufacturer Organization: Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X0000498p2qQAA"
      },
      "name" : "PreQual Manufacturer: Chengdu Institute of Biological Products Co. Ltd",
      "description" : "WHO PreQual Manufacturer: Chengdu Institute of Biological Products Co. Ltd (China)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X0000498p2qQAA"
      },
      "name" : "PreQual Manufacturer: Chengdu Institute of Biological Products Co. Ltd",
      "description" : "Vaccine Manufacturer Organization: Chengdu Institute of Biological Products Co. Ltd",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X0000498p3gQAA"
      },
      "name" : "PreQual Manufacturer: GlaxoSmithKline Biologicals SA",
      "description" : "WHO PreQual Manufacturer: GlaxoSmithKline Biologicals SA (Belgium)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X0000498p3gQAA"
      },
      "name" : "PreQual Manufacturer: GlaxoSmithKline Biologicals SA",
      "description" : "Vaccine Manufacturer Organization: GlaxoSmithKline Biologicals SA",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X0000498p2wQAA"
      },
      "name" : "PreQual Manufacturer: Haffkine Bio Pharmaceutical Corporation Ltd",
      "description" : "WHO PreQual Manufacturer: Haffkine Bio Pharmaceutical Corporation Ltd (India)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X0000498p2wQAA"
      },
      "name" : "PreQual Manufacturer: Haffkine Bio Pharmaceutical Corporation Ltd",
      "description" : "Vaccine Manufacturer Organization: Haffkine Bio Pharmaceutical Corporation Ltd",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X000049bJ9SQAU"
      },
      "name" : "PreQual Manufacturer: Institut Pasteur de Dakar (IPD)",
      "description" : "WHO PreQual Manufacturer: Institut Pasteur de Dakar (IPD) (Senegal)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X000049bJ9SQAU"
      },
      "name" : "PreQual Manufacturer: Institut Pasteur de Dakar (IPD)",
      "description" : "Vaccine Manufacturer Organization: Institut Pasteur de Dakar (IPD)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X0000498p4ZQAQ"
      },
      "name" : "PreQual Manufacturer: Japan BCG Laboratory (JBL)",
      "description" : "WHO PreQual Manufacturer: Japan BCG Laboratory (JBL) (Japan)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X0000498p4ZQAQ"
      },
      "name" : "PreQual Manufacturer: Japan BCG Laboratory (JBL)",
      "description" : "Vaccine Manufacturer Organization: Japan BCG Laboratory (JBL)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X00004993qnQAA"
      },
      "name" : "PreQual Manufacturer: LG Chem Ltd (LGC)",
      "description" : "WHO PreQual Manufacturer: LG Chem Ltd (LGC) (Republic of Korea)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X00004993qnQAA"
      },
      "name" : "PreQual Manufacturer: LG Chem Ltd (LGC)",
      "description" : "Vaccine Manufacturer Organization: LG Chem Ltd (LGC)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X0000498p3PQAQ"
      },
      "name" : "PreQual Manufacturer: Sanofi Pasteur SA",
      "description" : "WHO PreQual Manufacturer: Sanofi Pasteur SA (France)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X0000498p3PQAQ"
      },
      "name" : "PreQual Manufacturer: Sanofi Pasteur SA",
      "description" : "Vaccine Manufacturer Organization: Sanofi Pasteur SA",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X00003cPkzfQAC"
      },
      "name" : "PreQual Manufacturer: Serum Institute of India",
      "description" : "WHO PreQual Manufacturer: Serum Institute of India (India)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X00003cPkzfQAC"
      },
      "name" : "PreQual Manufacturer: Serum Institute of India",
      "description" : "Vaccine Manufacturer Organization: Serum Institute of India",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualManufacturer0013X0000498p3ZQAQ"
      },
      "name" : "PreQual Manufacturer: Sinovac Biotech Co. Ltd",
      "description" : "WHO PreQual Manufacturer: Sinovac Biotech Co. Ltd (China)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Manufacturer0013X0000498p3ZQAQ"
      },
      "name" : "PreQual Manufacturer: Sinovac Biotech Co. Ltd",
      "description" : "Vaccine Manufacturer Organization: Sinovac Biotech Co. Ltd",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Holder0013X0000498p4bQAA"
      },
      "name" : "PreQual NRA/Holder: Agence nationale de sécurité du médicament et des produits de santé (ANSM)",
      "description" : "National Regulatory Authority: Agence nationale de sécurité du médicament et des produits de santé (ANSM)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Holder0013X00003cPkgXQAS"
      },
      "name" : "PreQual NRA/Holder: Bulgarian Drug Agency (BDA)",
      "description" : "National Regulatory Authority: Bulgarian Drug Agency (BDA)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Holder0013X0000498p4fQAA"
      },
      "name" : "PreQual NRA/Holder: Central Drugs Standard Control Organization (CDSCO)",
      "description" : "National Regulatory Authority: Central Drugs Standard Control Organization (CDSCO)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Holder0013X0000498p67QAA"
      },
      "name" : "PreQual NRA/Holder: Federal Agency for Medicines and Health Products  (FAMPH)",
      "description" : "National Regulatory Authority: Federal Agency for Medicines and Health Products  (FAMPH)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Holder0013X00004993qyQAA"
      },
      "name" : "PreQual NRA/Holder: Ministry of Food and Drug Safety (MFDS)",
      "description" : "National Regulatory Authority: Ministry of Food and Drug Safety (MFDS)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Holder0013X0000498p53QAA"
      },
      "name" : "PreQual NRA/Holder: Ministère de la Santé publique (DPM)",
      "description" : "National Regulatory Authority: Ministère de la Santé publique (DPM)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Holder0013X0000498p4wQAA"
      },
      "name" : "PreQual NRA/Holder: National Medical Products Administration  (NMPA)",
      "description" : "National Regulatory Authority: National Medical Products Administration  (NMPA)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/Holder0013X0000498p4mQAA"
      },
      "name" : "PreQual NRA/Holder: Pharmaceutical and Medical Devices Agency (PMDA)",
      "description" : "National Regulatory Authority: Pharmaceutical and Medical Devices Agency (PMDA)",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualNRA0013X0000498p4bQAA"
      },
      "name" : "PreQual NRA: Agence nationale de sécurité du médicament et des produits de santé (ANSM)",
      "description" : "WHO PreQual NRA: Agence nationale de sécurité du médicament et des produits de santé (ANSM) (France)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualNRA0013X00003cPkgXQAS"
      },
      "name" : "PreQual NRA: Bulgarian Drug Agency (BDA)",
      "description" : "WHO PreQual NRA: Bulgarian Drug Agency (BDA) (Bulgaria)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualNRA0013X0000498p4fQAA"
      },
      "name" : "PreQual NRA: Central Drugs Standard Control Organization (CDSCO)",
      "description" : "WHO PreQual NRA: Central Drugs Standard Control Organization (CDSCO) (India)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualNRA0013X0000498p67QAA"
      },
      "name" : "PreQual NRA: Federal Agency for Medicines and Health Products  (FAMPH)",
      "description" : "WHO PreQual NRA: Federal Agency for Medicines and Health Products  (FAMPH) (Belgium)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualNRA0013X00004993qyQAA"
      },
      "name" : "PreQual NRA: Ministry of Food and Drug Safety (MFDS)",
      "description" : "WHO PreQual NRA: Ministry of Food and Drug Safety (MFDS) (Republic of Korea)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualNRA0013X0000498p53QAA"
      },
      "name" : "PreQual NRA: Ministère de la Santé publique (DPM)",
      "description" : "WHO PreQual NRA: Ministère de la Santé publique (DPM) (Senegal)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualNRA0013X0000498p4wQAA"
      },
      "name" : "PreQual NRA: National Medical Products Administration  (NMPA)",
      "description" : "WHO PreQual NRA: National Medical Products Administration  (NMPA) (China)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualNRA0013X0000498p4mQAA"
      },
      "name" : "PreQual NRA: Pharmaceutical and Medical Devices Agency (PMDA)",
      "description" : "WHO PreQual NRA: Pharmaceutical and Medical Devices Agency (PMDA) (Japan)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaIUAS"
      },
      "name" : "PreQual Packaging: 10",
      "description" : "WHO PreQual Product Packaging: 10",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaJUAS"
      },
      "name" : "PreQual Packaging: 10",
      "description" : "WHO PreQual Product Packaging: 10",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaKUAS"
      },
      "name" : "PreQual Packaging: 20",
      "description" : "WHO PreQual Product Packaging: 20",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabbUAC"
      },
      "name" : "PreQual Packaging: 24 cartons of 50 vials (1200 vials/12000 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: 24 cartons of 50 vials (1200 vials/12000 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaHUAS"
      },
      "name" : "PreQual Packaging: 50",
      "description" : "WHO PreQual Product Packaging: 50",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab7UAC"
      },
      "name" : "PreQual Packaging: Active: Box containing 175 cartons of 20 ampoules ( 70 000 doses/ 3500 ampoules )[Dimensions: 58 x 58 x 53 cm]",
      "description" : "WHO PreQual Product Packaging: Active: Box containing 175 cartons of 20 ampoules ( 70 000 doses/ 3500 ampoules )[Dimensions: 58 x 58 x 53 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab3UAC"
      },
      "name" : "PreQual Packaging: Active: Box containing 175 cartons of 20 ampoules (35000 doses/ 3500 ampoules)[Dimensions: 58 x 58 x 53 cm]",
      "description" : "WHO PreQual Product Packaging: Active: Box containing 175 cartons of 20 ampoules (35000 doses/ 3500 ampoules)[Dimensions: 58 x 58 x 53 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaNUAS"
      },
      "name" : "PreQual Packaging: Active: Box containing 4 000 amps. (80 000 doses)[Dimensions: 61 x 76 x 43 cm]",
      "description" : "WHO PreQual Product Packaging: Active: Box containing 4 000 amps. (80 000 doses)[Dimensions: 61 x 76 x 43 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaLUAS"
      },
      "name" : "PreQual Packaging: Active: Carton of 100 ampoules (2 000 doses)[Dimensions: 13.6 x 13.3 x 8 cm]",
      "description" : "WHO PreQual Product Packaging: Active: Carton of 100 ampoules (2 000 doses)[Dimensions: 13.6 x 13.3 x 8 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab1UAC"
      },
      "name" : "PreQual Packaging: Active: Carton of 20 ampoules (200 doses)[Dimensions: 14.5 x 9.8 x 2.8 cm]",
      "description" : "WHO PreQual Product Packaging: Active: Carton of 20 ampoules (200 doses)[Dimensions: 14.5 x 9.8 x 2.8 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab5UAC"
      },
      "name" : "PreQual Packaging: Active: Carton of 20 ampoules (400 doses)[Dimensions: 14.5 x 9.8 x 2.8 cm]",
      "description" : "WHO PreQual Product Packaging: Active: Carton of 20 ampoules (400 doses)[Dimensions: 14.5 x 9.8 x 2.8 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaanUAC"
      },
      "name" : "PreQual Packaging: Box containing 1500 vials (1500 doses)[Dimensions: 60 x 50 x 45 cm]",
      "description" : "WHO PreQual Product Packaging: Box containing 1500 vials (1500 doses)[Dimensions: 60 x 50 x 45 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaamUAC"
      },
      "name" : "PreQual Packaging: Box containing 1600 single dose cartons (1600 doses)[Dimensions: 84 x 64 x 71 cm]",
      "description" : "WHO PreQual Product Packaging: Box containing 1600 single dose cartons (1600 doses)[Dimensions: 84 x 64 x 71 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaeUAC"
      },
      "name" : "PreQual Packaging: Box containing 192 cartons of 10 vials (19 200 doses /     1 920 vials)  [Dimensions: 58 x 58 x 53 cm]",
      "description" : "WHO PreQual Product Packaging: Box containing 192 cartons of 10 vials (19 200 doses /     1 920 vials)  [Dimensions: 58 x 58 x 53 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaawUAC"
      },
      "name" : "PreQual Packaging: Box containing 192 cartons of 10 vials (19 200 doses /     1 920 vials)  [Dimensions: 58 x 58 x 53 cm]",
      "description" : "WHO PreQual Product Packaging: Box containing 192 cartons of 10 vials (19 200 doses /     1 920 vials)  [Dimensions: 58 x 58 x 53 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaaUAC"
      },
      "name" : "PreQual Packaging: Box containing 192 cartons of 10 vials (19200 doses / 1920 vials)[Dimensions: 5.8 x 5.8 x 5.3 cm]",
      "description" : "WHO PreQual Product Packaging: Box containing 192 cartons of 10 vials (19200 doses / 1920 vials)[Dimensions: 5.8 x 5.8 x 5.3 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaacUAC"
      },
      "name" : "PreQual Packaging: Box containing 192 cartons of 10 vials (38 400 doses /    1 920 vials)[Dimensions: 5.8 x 5.8 x 5.3 cm]",
      "description" : "WHO PreQual Product Packaging: Box containing 192 cartons of 10 vials (38 400 doses /    1 920 vials)[Dimensions: 5.8 x 5.8 x 5.3 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaauUAC"
      },
      "name" : "PreQual Packaging: Box containing 192 cartons of 10 vials (38 400 doses /    1920 vials) [Dimensions: 58 x 58 x 53 cm]",
      "description" : "WHO PreQual Product Packaging: Box containing 192 cartons of 10 vials (38 400 doses /    1920 vials) [Dimensions: 58 x 58 x 53 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaayUAC"
      },
      "name" : "PreQual Packaging: Box containing 192 cartons of 10 vials (38 400 doses /    1920 vials) [Dimensions: 58 x 58 x 53 cm]",
      "description" : "WHO PreQual Product Packaging: Box containing 192 cartons of 10 vials (38 400 doses /    1920 vials) [Dimensions: 58 x 58 x 53 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3HNN0000007wYk2AI"
      },
      "name" : "PreQual Packaging: Box containing 300 vials (600 doses). Dimensions: 31 x 19 x 9.3 cm",
      "description" : "WHO PreQual Product Packaging: Box containing 300 vials (600 doses). Dimensions: 31 x 19 x 9.3 cm",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaalUAC"
      },
      "name" : "PreQual Packaging: Box containing 400 single dose cartons (400 doses)[Dimensions: 47 x 38 x 38 cm].",
      "description" : "WHO PreQual Product Packaging: Box containing 400 single dose cartons (400 doses)[Dimensions: 47 x 38 x 38 cm].",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab0UAC"
      },
      "name" : "PreQual Packaging: Box containing 80 cartons of 5 vials (400 vials/2000 doses)[Dimensions: 393 x 147 x 207 cm]",
      "description" : "WHO PreQual Product Packaging: Box containing 80 cartons of 5 vials (400 vials/2000 doses)[Dimensions: 393 x 147 x 207 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaasUAC"
      },
      "name" : "PreQual Packaging: box of 120 cartons of 10 vials (12000 doses) [dimensions: 57.5 x 53.5 x 49.0 cm]",
      "description" : "WHO PreQual Product Packaging: box of 120 cartons of 10 vials (12000 doses) [dimensions: 57.5 x 53.5 x 49.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaapUAC"
      },
      "name" : "PreQual Packaging: Box of 20 wrapped cartons containing 10 boxes of 3 vials each (600 vials/12000 doses)[Dimensions: 46 x 29.5 x 14 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 20 wrapped cartons containing 10 boxes of 3 vials each (600 vials/12000 doses)[Dimensions: 46 x 29.5 x 14 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaEUAS"
      },
      "name" : "PreQual Packaging: Box of 220 cartons (220 doses) [Dimensions: 34.2 x 25.1 x 43.1 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 220 cartons (220 doses) [Dimensions: 34.2 x 25.1 x 43.1 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaQUAS"
      },
      "name" : "PreQual Packaging: Box of 220 cartons of 10 vials (2 200 doses) [Dimensions: 57.5 x 53.5 x 49.0 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 220 cartons of 10 vials (2 200 doses) [Dimensions: 57.5 x 53.5 x 49.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaXUAS"
      },
      "name" : "PreQual Packaging: Box of 24 cartons of 100 vials (active) (2400 vials/ 2400 doses)[Dimensions 34 x 25 x 43 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 24 cartons of 100 vials (active) (2400 vials/ 2400 doses)[Dimensions 34 x 25 x 43 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabDUAS"
      },
      "name" : "PreQual Packaging: Box of 24 cartons of 25 vials (600 vials/12000 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 24 cartons of 25 vials (600 vials/12000 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabBUAS"
      },
      "name" : "PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials / 1200 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 24 cartons of 50 vials (1200 vials / 1200 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabPUAS"
      },
      "name" : "PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials / 12000 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 24 cartons of 50 vials (1200 vials / 12000 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabJUAS"
      },
      "name" : "PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials/1200 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 24 cartons of 50 vials (1200 vials/1200 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabXUAS"
      },
      "name" : "PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials/1200 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 24 cartons of 50 vials (1200 vials/1200 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabGUAS"
      },
      "name" : "PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials/2400 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 24 cartons of 50 vials (1200 vials/2400 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabMUAS"
      },
      "name" : "PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials/2400 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 24 cartons of 50 vials (1200 vials/2400 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabSUAS"
      },
      "name" : "PreQual Packaging: Box of 24 cartons of 50 vials (1200 vials/6000 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 24 cartons of 50 vials (1200 vials/6000 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaGUAS"
      },
      "name" : "PreQual Packaging: Box of 30 cartons (1500 doses) [Dimensions: 34.2 x 25.1 x 43.1 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 30 cartons (1500 doses) [Dimensions: 34.2 x 25.1 x 43.1 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000002OBWgUAO"
      },
      "name" : "PreQual Packaging: Box of 300 vials (300 doses). Dimensions: 31 x 19 x 9.3 cm",
      "description" : "WHO PreQual Product Packaging: Box of 300 vials (300 doses). Dimensions: 31 x 19 x 9.3 cm",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabZUAS"
      },
      "name" : "PreQual Packaging: Box of 36 cartons of 50 ampoules (1800 ampoules/1800 doses) [Dimensions 60x48x41 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 36 cartons of 50 ampoules (1800 ampoules/1800 doses) [Dimensions 60x48x41 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaFUAS"
      },
      "name" : "PreQual Packaging: Box of 68 cartons (680 doses) [Dimensions: 34.2 x 25.1 x 43.1 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 68 cartons (680 doses) [Dimensions: 34.2 x 25.1 x 43.1 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaYUAS"
      },
      "name" : "PreQual Packaging: Box of 8 cartons of 100 ampoules/800 doses (diluent) [Dimensions 32 x 20 x 39 cm]",
      "description" : "WHO PreQual Product Packaging: Box of 8 cartons of 100 ampoules/800 doses (diluent) [Dimensions 32 x 20 x 39 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaoUAC"
      },
      "name" : "PreQual Packaging: Carton containing 3 vials (60 doses)[Dimensions: 5.4 x 5.3 x 2.2 cm]",
      "description" : "WHO PreQual Product Packaging: Carton containing 3 vials (60 doses)[Dimensions: 5.4 x 5.3 x 2.2 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaajUAC"
      },
      "name" : "PreQual Packaging: Carton of 1 single dose vial [Dimensions 3.0 x 2.0 x 5.4 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 1 single dose vial [Dimensions 3.0 x 2.0 x 5.4 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaBUAS"
      },
      "name" : "PreQual Packaging: Carton of 1 tube [Dimensions: 5.3 x 8.7 x 2.5 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 1 tube [Dimensions: 5.3 x 8.7 x 2.5 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaCUAS"
      },
      "name" : "PreQual Packaging: Carton of 10 tubes [Dimensions: 12.8 x 8.7 x 2.5 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 tubes [Dimensions: 12.8 x 8.7 x 2.5 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaPUAS"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (10 doses) [Dimensions: 8.5 x 3.8 x 4.5 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (10 doses) [Dimensions: 8.5 x 3.8 x 4.5 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaarUAC"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (100 adult doses) [Dimensions: 13.5x5.4x6.7 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (100 adult doses) [Dimensions: 13.5x5.4x6.7 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaadUAC"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (100 doses) [Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (100 doses) [Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaavUAC"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (100 doses) [Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (100 doses) [Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaZUAS"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (100 doses)[Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (100 doses)[Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaqUAC"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (100 paediatric doses) [Dimensions: 11.5 x 4.7 x 5.3 cm].",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (100 paediatric doses) [Dimensions: 11.5 x 4.7 x 5.3 cm].",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaatUAC"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (200 doses)  [Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (200 doses)  [Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaxUAC"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (200 doses)  [Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (200 doses)  [Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaabUAC"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (200 doses)[Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (200 doses)[Dimensions: 12.5 x 5.5 x 5.7 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabTUAS"
      },
      "name" : "PreQual Packaging: Carton of 10 vials (active) [Dimensions 8.3 x 4.35 x 3.85 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 10 vials (active) [Dimensions 8.3 x 4.35 x 3.85 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaWUAS"
      },
      "name" : "PreQual Packaging: Carton of 100 ampoules (diluent) [Dimensions 19 x 18 x 7.5 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 100 ampoules (diluent) [Dimensions 19 x 18 x 7.5 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaVUAS"
      },
      "name" : "PreQual Packaging: Carton of 100 vials (active) [Dimensions 17.8 x 14.7 x 3.7 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 100 vials (active) [Dimensions 17.8 x 14.7 x 3.7 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabCUAS"
      },
      "name" : "PreQual Packaging: Carton of 25 vials (500 doses) [Dimensions 13.3x13.3x6.0 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 25 vials (500 doses) [Dimensions 13.3x13.3x6.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaazUAC"
      },
      "name" : "PreQual Packaging: Carton of 5 vials (25 dose)[Dimensions: 77 x 35 x 48.5 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 5 vials (25 dose)[Dimensions: 77 x 35 x 48.5 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabYUAS"
      },
      "name" : "PreQual Packaging: carton of 50 ampoules (50 doses) [Dimensions 14.5x6.0x7.0]",
      "description" : "WHO PreQual Product Packaging: carton of 50 ampoules (50 doses) [Dimensions 14.5x6.0x7.0]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabRUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 ampoules (diluent) [Dimensions 10.5x8.7x15.0 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 ampoules (diluent) [Dimensions 10.5x8.7x15.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabOUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 ampoules (diluent) [Dimensions 10.5x8.7x17.2 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 ampoules (diluent) [Dimensions 10.5x8.7x17.2 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabFUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 ampoules (diluent) [Dimensions 14.5x6.0x7.2 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 ampoules (diluent) [Dimensions 14.5x6.0x7.2 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabIUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 ampoules (diluent) [Dimensions 14.5x6.0x7.2 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 ampoules (diluent) [Dimensions 14.5x6.0x7.2 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabLUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 ampoules (diluent) [dimensions 14.5x6.0x7.2 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 ampoules (diluent) [dimensions 14.5x6.0x7.2 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabWUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 ampoules (diluent) [Dimensions 14.5x6.0x7.2 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 ampoules (diluent) [Dimensions 14.5x6.0x7.2 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabAUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 ampoules (diluent) [Dimesions 14.5x6.0x7.2 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 ampoules (diluent) [Dimesions 14.5x6.0x7.2 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaakUAC"
      },
      "name" : "PreQual Packaging: Carton of 50 single dose vials (50 doses)[Dimensions: 16.3 x 8.5 x 4.4 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 single dose vials (50 doses)[Dimensions: 16.3 x 8.5 x 4.4 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaDUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 tubes [Dimensions: 14.6 x 8.5 x 6.9 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 tubes [Dimensions: 14.6 x 8.5 x 6.9 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3HNN0000007wYj2AI"
      },
      "name" : "PreQual Packaging: Carton of 50 vials (100 doses). Dimensions: 18.5 x 9.5 x 4.0 cm",
      "description" : "WHO PreQual Product Packaging: Carton of 50 vials (100 doses). Dimensions: 18.5 x 9.5 x 4.0 cm",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000002OBWeUAO"
      },
      "name" : "PreQual Packaging: Carton of 50 vials (50 doses). Dimensions 18.5 x 9.5 x 4.0 cm",
      "description" : "WHO PreQual Product Packaging: Carton of 50 vials (50 doses). Dimensions 18.5 x 9.5 x 4.0 cm",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabaUAC"
      },
      "name" : "PreQual Packaging: carton of 50 vials (500 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "description" : "WHO PreQual Product Packaging: carton of 50 vials (500 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabEUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 vials (active)(100 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 vials (active)(100 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabKUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 vials (active)(100 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 vials (active)(100 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabQUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 vials (active)(250 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 vials (active)(250 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab9UAC"
      },
      "name" : "PreQual Packaging: Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabHUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabVUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabNUAS"
      },
      "name" : "PreQual Packaging: Carton of 50 vials (active)(500 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "description" : "WHO PreQual Product Packaging: Carton of 50 vials (active)(500 doses) [Dimensions 18.5x9.5x6.0 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab4UAC"
      },
      "name" : "PreQual Packaging: Diluent: Box containing 175 cartons of 20 ampoules (35000 doses/3500 ampoules)[Dimensions: 46x x 31 x 33 cm]",
      "description" : "WHO PreQual Product Packaging: Diluent: Box containing 175 cartons of 20 ampoules (35000 doses/3500 ampoules)[Dimensions: 46x x 31 x 33 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab8UAC"
      },
      "name" : "PreQual Packaging: Diluent: Box containing 175 cartons of 20 ampoules (70 000 doses/ 3500 ampoules)[Dimensions: 46 x 31 x 33 cm]",
      "description" : "WHO PreQual Product Packaging: Diluent: Box containing 175 cartons of 20 ampoules (70 000 doses/ 3500 ampoules)[Dimensions: 46 x 31 x 33 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaOUAS"
      },
      "name" : "PreQual Packaging: Diluent: Box containing 5000 amps (100 000 doses)[Dimensions: 75 x 41 x 37 cm]",
      "description" : "WHO PreQual Product Packaging: Diluent: Box containing 5000 amps (100 000 doses)[Dimensions: 75 x 41 x 37 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VaaMUAS"
      },
      "name" : "PreQual Packaging: Diluent:Carton of 100 ampoules (2 000 doses)[Dimensions: 13.6 x 13.3 x 6.6 cm]",
      "description" : "WHO PreQual Product Packaging: Diluent:Carton of 100 ampoules (2 000 doses)[Dimensions: 13.6 x 13.3 x 6.6 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab2UAC"
      },
      "name" : "PreQual Packaging: Diluent:Carton of 20 ampoules (200 doses)[Dimensions: 14.5 x 5.7 x 2.6 cm]",
      "description" : "WHO PreQual Product Packaging: Diluent:Carton of 20 ampoules (200 doses)[Dimensions: 14.5 x 5.7 x 2.6 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001Vab6UAC"
      },
      "name" : "PreQual Packaging: Diluent:Carton of 20 ampoules (400 doses)[Dimensions: 14.5 x 5.7 x 2.6 cm]",
      "description" : "WHO PreQual Product Packaging: Diluent:Carton of 20 ampoules (400 doses)[Dimensions: 14.5 x 5.7 x 2.6 cm]",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3HNN0000007wYl2AI"
      },
      "name" : "PreQual Packaging: Shipping Container",
      "description" : "WHO PreQual Product Packaging: Shipping Container",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000002OBWfUAO"
      },
      "name" : "PreQual Packaging: Shipping Container",
      "description" : "WHO PreQual Product Packaging: Shipping Container",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualPackaginga3H3X000001VabUUAS"
      },
      "name" : "PreQual Packaging: Shipping Container",
      "description" : "WHO PreQual Product Packaging: Shipping Container",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MihxUAC"
      },
      "name" : "PreQual Product: BCG Freeze Dried Glutamate vaccine - BCG",
      "description" : "BCG Freeze Dried Glutamate vaccine (BCG) by Japan BCG Laboratory (JBL)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiCUAS"
      },
      "name" : "PreQual Product: BCG Vaccine - BCG",
      "description" : "BCG Vaccine (BCG) by Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiDUAS"
      },
      "name" : "PreQual Product: BCG Vaccine - BCG",
      "description" : "BCG Vaccine (BCG) by Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000005atRtUAI"
      },
      "name" : "PreQual Product: CYVAC - Malaria",
      "description" : "CYVAC (Malaria) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000005atSwUAI"
      },
      "name" : "PreQual Product: CYVAC - Malaria",
      "description" : "CYVAC (Malaria) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiBUAS"
      },
      "name" : "PreQual Product: Dengvaxia - TDV",
      "description" : "Dengvaxia (TDV) by Sanofi Pasteur SA",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006Mii3UAC"
      },
      "name" : "PreQual Product: Diftet - DT",
      "description" : "Diftet (DT) by Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006Mii8UAC"
      },
      "name" : "PreQual Product: Diftet - DT",
      "description" : "Diftet (DT) by Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiNUAS"
      },
      "name" : "PreQual Product: Diphtheria-Tetanus-Pertussis Vaccine Adsorbed - DTwP",
      "description" : "Diphtheria-Tetanus-Pertussis Vaccine Adsorbed (DTwP) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiOUAS"
      },
      "name" : "PreQual Product: Diphtheria-Tetanus-Pertussis Vaccine Adsorbed - DTwP",
      "description" : "Diphtheria-Tetanus-Pertussis Vaccine Adsorbed (DTwP) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MihyUAC"
      },
      "name" : "PreQual Product: Euvax B - HepB",
      "description" : "Euvax B (HepB) by LG Chem Ltd (LGC)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006Mii7UAC"
      },
      "name" : "PreQual Product: Euvax B - HepB",
      "description" : "Euvax B (HepB) by LG Chem Ltd (LGC)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006Mii5UAC"
      },
      "name" : "PreQual Product: HEALIVE - HepA",
      "description" : "HEALIVE (HepA) by Sinovac Biotech Co. Ltd",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiLUAS"
      },
      "name" : "PreQual Product: Japanese Encephalitis Vaccine Live (SA14-14-2) - JE",
      "description" : "Japanese Encephalitis Vaccine Live (SA14-14-2) (JE) by Chengdu Institute of Biological Products Co. Ltd",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiEUAS"
      },
      "name" : "PreQual Product: Measles and Rubella Vaccine Live Attenuated - MR",
      "description" : "Measles and Rubella Vaccine Live Attenuated (MR) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiGUAS"
      },
      "name" : "PreQual Product: Measles and Rubella Vaccine Live Attenuated - MR",
      "description" : "Measles and Rubella Vaccine Live Attenuated (MR) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiHUAS"
      },
      "name" : "PreQual Product: Measles Mumps and Rubella Vaccine Live Attenuated - MMR",
      "description" : "Measles Mumps and Rubella Vaccine Live Attenuated (MMR) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiIUAS"
      },
      "name" : "PreQual Product: Measles Mumps and Rubella Vaccine Live Attenuated - MMR",
      "description" : "Measles Mumps and Rubella Vaccine Live Attenuated (MMR) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiJUAS"
      },
      "name" : "PreQual Product: Measles Mumps and Rubella Vaccine Live Attenuated - MMR",
      "description" : "Measles Mumps and Rubella Vaccine Live Attenuated (MMR) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiKUAS"
      },
      "name" : "PreQual Product: Measles Mumps and Rubella Vaccine Live Attenuated - MMR",
      "description" : "Measles Mumps and Rubella Vaccine Live Attenuated (MMR) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiMUAS"
      },
      "name" : "PreQual Product: Measles Vaccine Live Attenuated - M",
      "description" : "Measles Vaccine Live Attenuated (M) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006Mii6UAC"
      },
      "name" : "PreQual Product: Poliomyelitis Vaccine (live oral attenuated human Diploid Cell) type 1 and 3 - bOPV",
      "description" : "Poliomyelitis Vaccine (live oral attenuated human Diploid Cell) type 1 and 3 (bOPV) by Beijing Institute of Biological Products Co., Ltd.",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MihtUAC"
      },
      "name" : "PreQual Product: Polioviral vaccine - tOPV",
      "description" : "Polioviral vaccine (tOPV) by Haffkine Bio Pharmaceutical Corporation Ltd",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006Mii0UAC"
      },
      "name" : "PreQual Product: Priorix - MMR",
      "description" : "Priorix (MMR) by GlaxoSmithKline Biologicals SA",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MihsUAC"
      },
      "name" : "PreQual Product: Rotarix - LARV",
      "description" : "Rotarix (LARV) by GlaxoSmithKline Biologicals SA",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MihuUAC"
      },
      "name" : "PreQual Product: Stabilized Yellow Fever Vaccine - YF",
      "description" : "Stabilized Yellow Fever Vaccine (YF) by Institut Pasteur de Dakar (IPD)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MihvUAC"
      },
      "name" : "PreQual Product: Stabilized Yellow Fever Vaccine - YF",
      "description" : "Stabilized Yellow Fever Vaccine (YF) by Institut Pasteur de Dakar (IPD)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MihwUAC"
      },
      "name" : "PreQual Product: Stabilized Yellow Fever Vaccine - YF",
      "description" : "Stabilized Yellow Fever Vaccine (YF) by Institut Pasteur de Dakar (IPD)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006Mii9UAC"
      },
      "name" : "PreQual Product: Tetadif - dT",
      "description" : "Tetadif (dT) by Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiAUAS"
      },
      "name" : "PreQual Product: Tetadif - dT",
      "description" : "Tetadif (dT) by Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006MiiFUAS"
      },
      "name" : "PreQual Product: Tetanus  Toxoid Vaccine Adsorbed - TT",
      "description" : "Tetanus  Toxoid Vaccine Adsorbed (TT) by Serum Institute of India",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006Mii1UAC"
      },
      "name" : "PreQual Product: Tetatox - TT",
      "description" : "Tetatox (TT) by Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/FinishedProducta3K3X000006Mii2UAC"
      },
      "name" : "PreQual Product: Tetatox - TT",
      "description" : "Tetatox (TT) by Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/FinishedVaccineProducts"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X0000498p4LQAQ"
      },
      "name" : "PreQual Site: Beijing Institute of Biological Products Co., Ltd.",
      "description" : "WHO PreQual Manufacturing Site: Beijing Institute of Biological Products Co., Ltd. (China)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X0000498p2jQAA"
      },
      "name" : "PreQual Site: Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
      "description" : "WHO PreQual Manufacturing Site: Bul Bio-National Center of Infectious and Parasitic Diseases Ltd. (Bulgaria)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X0000498p2qQAA"
      },
      "name" : "PreQual Site: Chengdu Institute of Biological Products Co. Ltd",
      "description" : "WHO PreQual Manufacturing Site: Chengdu Institute of Biological Products Co. Ltd (China)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X0000498p3gQAA"
      },
      "name" : "PreQual Site: GlaxoSmithKline Biologicals SA",
      "description" : "WHO PreQual Manufacturing Site: GlaxoSmithKline Biologicals SA (Belgium)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X0000498p2wQAA"
      },
      "name" : "PreQual Site: Haffkine Bio Pharmaceutical Corporation Ltd",
      "description" : "WHO PreQual Manufacturing Site: Haffkine Bio Pharmaceutical Corporation Ltd (India)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X000049bJ9SQAU"
      },
      "name" : "PreQual Site: Institut Pasteur de Dakar (IPD)",
      "description" : "WHO PreQual Manufacturing Site: Institut Pasteur de Dakar (IPD) (Senegal)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X0000498p4ZQAQ"
      },
      "name" : "PreQual Site: Japan BCG Laboratory (JBL)",
      "description" : "WHO PreQual Manufacturing Site: Japan BCG Laboratory (JBL) (Japan)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X00004993qnQAA"
      },
      "name" : "PreQual Site: LG Chem Ltd (LGC)",
      "description" : "WHO PreQual Manufacturing Site: LG Chem Ltd (LGC) (Republic of Korea)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X0000498p3IQAQ"
      },
      "name" : "PreQual Site: PT Bio Farma (Persero)",
      "description" : "WHO PreQual Manufacturing Site: PT Bio Farma (Persero) (Indonesia)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X0000498p3PQAQ"
      },
      "name" : "PreQual Site: Sanofi Pasteur SA",
      "description" : "WHO PreQual Manufacturing Site: Sanofi Pasteur SA (France)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X00003cPkzfQAC"
      },
      "name" : "PreQual Site: Serum Institute of India",
      "description" : "WHO PreQual Manufacturing Site: Serum Institute of India (India)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualSite0013X0000498p3ZQAQ"
      },
      "name" : "PreQual Site: Sinovac Biotech Co. Ltd",
      "description" : "WHO PreQual Manufacturing Site: Sinovac Biotech Co. Ltd (China)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSogUAE"
      },
      "name" : "PreQual Vaccine: BCG",
      "description" : "WHO PreQual Vaccine: BCG (BCG)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSoiUAE"
      },
      "name" : "PreQual Vaccine: Dengue tetravalent vaccine (live, attenuated)",
      "description" : "WHO PreQual Vaccine: Dengue tetravalent vaccine (live, attenuated) (TDV)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSojUAE"
      },
      "name" : "PreQual Vaccine: Diphtheria and tetanus vaccine (adsorbed)",
      "description" : "WHO PreQual Vaccine: Diphtheria and tetanus vaccine (adsorbed) (DT)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSokUAE"
      },
      "name" : "PreQual Vaccine: Diphtheria and tetanus vaccine (adsorbed, reduced diphtheria antigen content)",
      "description" : "WHO PreQual Vaccine: Diphtheria and tetanus vaccine (adsorbed, reduced diphtheria antigen content) (dT)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSomUAE"
      },
      "name" : "PreQual Vaccine: Diphtheria, tetanus and (whole cell) pertussis vaccine (adsorbed)",
      "description" : "WHO PreQual Vaccine: Diphtheria, tetanus and (whole cell) pertussis vaccine (adsorbed) (DTwP)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpIUAU"
      },
      "name" : "PreQual Vaccine: Hepatitis A vaccine (inactivated)",
      "description" : "WHO PreQual Vaccine: Hepatitis A vaccine (inactivated) (HepA)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpJUAU"
      },
      "name" : "PreQual Vaccine: Hepatitis B vaccine (recombinant)",
      "description" : "WHO PreQual Vaccine: Hepatitis B vaccine (recombinant) (HepB)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpXUAU"
      },
      "name" : "PreQual Vaccine: Japanese encephalitis vaccine (live, attenuated) for human use",
      "description" : "WHO PreQual Vaccine: Japanese encephalitis vaccine (live, attenuated) for human use (JE)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpZUAU"
      },
      "name" : "PreQual Vaccine: Measles vaccine (live, attenuated)",
      "description" : "WHO PreQual Vaccine: Measles vaccine (live, attenuated) (M)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpaUAE"
      },
      "name" : "PreQual Vaccine: Measles, mumps, rubella combined vaccine (live, attenuated)",
      "description" : "WHO PreQual Vaccine: Measles, mumps, rubella combined vaccine (live, attenuated) (MMR)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpbUAE"
      },
      "name" : "PreQual Vaccine: Measles, rubella combined vaccine (live, attenuated)",
      "description" : "WHO PreQual Vaccine: Measles, rubella combined vaccine (live, attenuated) (MR)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpiUAE"
      },
      "name" : "PreQual Vaccine: Poliomyelitis vaccines (bivalent live, oral, innactivated, type 1, 3)",
      "description" : "WHO PreQual Vaccine: Poliomyelitis vaccines (bivalent live, oral, innactivated, type 1, 3) (bOPV)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpjUAE"
      },
      "name" : "PreQual Vaccine: Poliomyelitis vaccines (trivalent live, oral, innactivated, type 1,2, 3)",
      "description" : "WHO PreQual Vaccine: Poliomyelitis vaccines (trivalent live, oral, innactivated, type 1,2, 3) (tOPV)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpnUAE"
      },
      "name" : "PreQual Vaccine: Recombinant malaria vaccine",
      "description" : "WHO PreQual Vaccine: Recombinant malaria vaccine (Malaria)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpYUAU"
      },
      "name" : "PreQual Vaccine: Rotavirus vaccine (live attenuated) (oral)",
      "description" : "WHO PreQual Vaccine: Rotavirus vaccine (live attenuated) (oral) (LARV)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpqUAE"
      },
      "name" : "PreQual Vaccine: Tetanus vaccine (adsorbed)",
      "description" : "WHO PreQual Vaccine: Tetanus vaccine (adsorbed) (TT)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      }],
      "reference" : {
        "reference" : "Binary/PreQualVaccinea3S3X000003cSpuUAE"
      },
      "name" : "PreQual Vaccine: Yellow fever vaccine (live attenuated)",
      "description" : "WHO PreQual Vaccine: Yellow fever vaccine (live attenuated) (YF)",
      "isExample" : true,
      "profile" : ["http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PreQualBulkSupplier"
      },
      "name" : "WHO PreQual Bulk Supplier",
      "description" : "Logical model for the bulk supplier organization\nfrom the WHO PreQual API (ProductDetails.BulkSupplier).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PreQualDocumentDetail"
      },
      "name" : "WHO PreQual Document Detail",
      "description" : "Logical model for document details\nfrom the WHO PreQual API (DocumentDetails).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PreQualManufacturer"
      },
      "name" : "WHO PreQual Manufacturer",
      "description" : "Logical model for the manufacturer/applicant organization\nfrom the WHO PreQual API (ProductDetails.ApplicantOrganization).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PreQualNRA"
      },
      "name" : "WHO PreQual NRA",
      "description" : "Logical model for the responsible National Regulatory Authority (NRA)\nfrom the WHO PreQual API (ProductDetails.NRADetails).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PreQualProductIngredient"
      },
      "name" : "WHO PreQual Product Ingredient",
      "description" : "Logical model for product ingredient details\nfrom the WHO PreQual API (ProductIngredients).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PreQualProductPackaging"
      },
      "name" : "WHO PreQual Product Packaging",
      "description" : "Logical model for product packaging details\nfrom the WHO PreQual API (ProductPackaging).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PreQualSiteDetail"
      },
      "name" : "WHO PreQual Site Detail",
      "description" : "Logical model for manufacturing site details\nfrom the WHO PreQual API (SiteDetails).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PreQualVaccine"
      },
      "name" : "WHO PreQual Vaccine",
      "description" : "Logical model for the vaccine type details\nfrom the WHO PreQual API (ProductDetails.VaccineDetails).\nContains only vaccine-type-level fields that are stable across products.\nProduct-specific fields (CommercialName, RouteOfAdministration) remain on FinishedVaccineProducts.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/PreQualPresentation"
      },
      "name" : "WHO PreQualificaiton Presentation ",
      "description" : "WHO PreQualificaiton Presentation",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/PreQualPresentation"
      },
      "name" : "WHO PreQualificaiton Vaccine Presentations",
      "description" : "WHO PreQualificaiton Vaccine Presentations",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/PreQualProductIds"
      },
      "name" : "WHO PreQualificaiton Vaccine Product Ids",
      "description" : "WHO PreQualificaiton Vaccine Product Ids",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/PreQualProductIds"
      },
      "name" : "WHO PreQualificaiton Vaccine Product Ids",
      "description" : "WHO PreQualificaiton Vaccine Product Ids",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/PreQualVaccineType"
      },
      "name" : "WHO PreQualificaiton Vaccine VaccineTypes",
      "description" : "WHO PreQualificaiton Vaccine VaccineTypes",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/PreQualVaccineType"
      },
      "name" : "WHO PreQualificaiton VaccineType ",
      "description" : "WHO PreQualificaiton VaccineType",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/PreQualDatabaseMetadata"
      },
      "name" : "WHO PreQualification Database Metadata",
      "description" : "Coded metadata values from the WHO PreQualification database",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/PreQualDatabaseMetadata"
      },
      "name" : "WHO PreQualification Database Metadata",
      "description" : "Coded metadata values from the WHO PreQualification database",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/FinishedVaccineProducts"
      },
      "name" : "WHO Vaccine PreQual DB - Finished Vaccine Products",
      "description" : "WHO Vaccine PreQual DB - Finished Vaccine Products.\nLogical model for the WHO PreQual DB as provided by the backend API at:\n     https://extranet.who.int/prequal/vaccines/prequalified-vaccines\nThis model provides authoritative vaccine product IDs and a richer data structure compared to the CSV export.\nSub-objects with Identification.Id are modeled as separate logical models and linked via references.\n\nKey fields from the API (FinishedVaccineProducts):\n  ProductDetails.Identification.Id - Vaccine Product ID (authoritative)\n  ProductDetails.Identification.Name - Product reference name (e.g. FVP-P-447)\n  ProductDetails.Type - Product type code (e.g. Finished Vaccine Product)\n  ProductDetails.DateOfPreQualifiedAcceptance - Date of prequalification\n  ProductDetails.AssessmentProcedure - Assessment procedure code\n  ProductDetails.ApplicantOrganization - Manufacturer/applicant with ID, name, address\n  ProductDetails.Presentation - Presentation form (Vial, Ampoule, etc.)\n  ProductDetails.PharmaceuticalForm - Pharmaceutical form details\n  ProductDetails.DosageDetails.NoOfDosagesPerPrimaryContainer - Number of doses\n  ProductDetails.NRADetails - Responsible NRA with ID, name, address\n  ProductDetails.VaccineDetails - Vaccine type with full, abbreviated, and commercial names\n  ProductDetails.StorageDetails - Storage temperature and shelf life\n  ProductDetails.Status - Prequalification status code",
      "isExample" : false
    }],
    "page" : {
      "sourceUrl" : "toc.html",
      "name" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "sourceUrl" : "index.html",
        "name" : "index.html",
        "title" : "Home",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "changes.html",
          "name" : "changes.html",
          "title" : "Changes",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "dependencies.html",
          "name" : "dependencies.html",
          "title" : "Dependencies",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "references.html",
          "name" : "references.html",
          "title" : "References",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "adapting.html",
          "name" : "adapting.html",
          "title" : "Adapting Guidelines for Country use",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "license.html",
          "name" : "license.html",
          "title" : "License",
          "generation" : "markdown"
        }]
      },
      {
        "sourceUrl" : "business-requirements.html",
        "name" : "business-requirements.html",
        "title" : "Business Requirements",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "concepts.html",
          "name" : "concepts.html",
          "title" : "Concepts",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "personas.html",
          "name" : "personas.html",
          "title" : "Generic Personas",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "scenarios.html",
          "name" : "scenarios.html",
          "title" : "User Scenarios",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "business-processes.html",
          "name" : "business-processes.html",
          "title" : "Business Processes",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "dictionary.html",
          "name" : "dictionary.html",
          "title" : "Data Dictionary",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "decision-logic.html",
          "name" : "decision-logic.html",
          "title" : "Decision-support logic",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "indicators.html",
          "name" : "indicators.html",
          "title" : "Indicator and Performance Metrics",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "functional-requirements.html",
          "name" : "functional-requirements.html",
          "title" : "Functional Requirements",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "non-functional-requirements.html",
          "name" : "non-functional-requirements.html",
          "title" : "Non-functional Requirements",
          "generation" : "markdown"
        }]
      },
      {
        "sourceUrl" : "data-models-and-exchange.html",
        "name" : "data-models-and-exchange.html",
        "title" : "Data Models and Exchange",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "system-actors.html",
          "name" : "system-actors.html",
          "title" : "System Actors",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "sequence-diagrams.html",
          "name" : "sequence-diagrams.html",
          "title" : "Sequence Diagrams",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "transactions.html",
          "name" : "transactions.html",
          "title" : "Transactions",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "indicators-measures.html",
          "name" : "indicators-measures.html",
          "title" : "Indicators and Measures",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "codings.html",
          "name" : "codings.html",
          "title" : "Codings",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "prequal-data.html",
          "name" : "prequal-data.html",
          "title" : "PreQual Data",
          "generation" : "markdown"
        }]
      },
      {
        "sourceUrl" : "deployment.html",
        "name" : "deployment.html",
        "title" : "Deployment",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "security-privacy.html",
          "name" : "security-privacy.html",
          "title" : "Security and Privacy Considerations",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "testing.html",
          "name" : "testing.html",
          "title" : "Testing",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "test-data.html",
          "name" : "test-data.html",
          "title" : "Test Data",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "reference-implementations.html",
          "name" : "reference-implementations.html",
          "title" : "Reference Implementations",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "trust_domain.html",
          "name" : "trust_domain.html",
          "title" : "Trust Domains",
          "generation" : "markdown"
        },
        {
          "sourceUrl" : "downloads.html",
          "name" : "downloads.html",
          "title" : "Downloads",
          "generation" : "markdown"
        }]
      },
      {
        "sourceUrl" : "indices.html",
        "name" : "indices.html",
        "title" : "Indices",
        "generation" : "markdown",
        "page" : [{
          "sourceUrl" : "artifacts.html",
          "name" : "artifacts.html",
          "title" : "Artifact Index",
          "generation" : "html"
        },
        {
          "sourceUrl" : "maps.html",
          "name" : "maps.html",
          "title" : "Mappings",
          "generation" : "markdown"
        }]
      },
      {
        "sourceUrl" : "dak-api.html",
        "name" : "dak-api.html",
        "title" : "DAK API Documentation Hub",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "copyrightyear"
      },
      "value" : "2023+"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "releaselabel"
      },
      "value" : "ci-build"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "autoload-resources"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/capabilities"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/examples"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/extensions"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/models"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/operations"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/profiles"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/vocabulary"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/maps"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/testing"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/history"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "fsh-generated/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "template/config"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "input/images"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "template/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "input/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-qa"
      },
      "value" : "temp/qa"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-temp"
      },
      "value" : "temp/pages"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-output"
      },
      "value" : "output"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-tx-cache"
      },
      "value" : "input-cache/txcache"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-suppressed-warnings"
      },
      "value" : "input/ignoreWarnings.txt"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-history"
      },
      "value" : "http://smart.who.int/pcmt-vaxprequal/history.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-html"
      },
      "value" : "template-page.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-md"
      },
      "value" : "template-page-md.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-contact"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-context"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-copyright"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-jurisdiction"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-license"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-publisher"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-version"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-wg"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "active-tables"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "fmm-definition"
      },
      "value" : "http://hl7.org/fhir/versions.html#maturity"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "propagate-status"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "excludelogbinaryformat"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "tabbed-snapshots"
      },
      "value" : "true"
    }]
  }
}

```
