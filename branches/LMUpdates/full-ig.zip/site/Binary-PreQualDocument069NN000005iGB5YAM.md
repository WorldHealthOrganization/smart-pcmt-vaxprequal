# PreQual Document: Container Photo-pq_139_MR_2dose_SII_vial%26ampoule_image-2022 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_139_MR_2dose_SII_vial%26ampoule_image-2022**

## Binary: PreQual Document: Container Photo-pq_139_MR_2dose_SII_vial%26ampoule_image-2022

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iGB5YAM"
  },
  "documentName": "Container Photo-pq_139_MR_2dose_SII_vial%26ampoule_image-2022",
  "documentType": "Photo",
  "versionId": "068NN000005z0GMYAY",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
