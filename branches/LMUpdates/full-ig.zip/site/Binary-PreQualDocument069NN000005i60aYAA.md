# PreQual Document: Container Photo-pq_125_DTP_1dose_SII_container_image_580 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_125_DTP_1dose_SII_container_image_580**

## Binary: PreQual Document: Container Photo-pq_125_DTP_1dose_SII_container_image_580

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i60aYAA"
  },
  "documentName": "Container Photo-pq_125_DTP_1dose_SII_container_image_580",
  "documentType": "Photo",
  "versionId": "068NN000005ypMiYAI",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
