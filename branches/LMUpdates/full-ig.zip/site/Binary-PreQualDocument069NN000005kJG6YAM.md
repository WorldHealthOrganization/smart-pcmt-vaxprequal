# PreQual Document: General-pq_325_bOPV_shipping%20box%20configuration-2023 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: General-pq_325_bOPV_shipping%20box%20configuration-2023**

## Binary: PreQual Document: General-pq_325_bOPV_shipping%20box%20configuration-2023

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005kJG6YAM"
  },
  "documentName": "General-pq_325_bOPV_shipping%20box%20configuration-2023",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN00000613ekYAA",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
