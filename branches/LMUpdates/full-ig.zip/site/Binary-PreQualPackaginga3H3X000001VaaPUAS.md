# PreQual Packaging: Carton of 10 vials (10 doses) [Dimensions: 8.5 x 3.8 x 4.5 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Carton of 10 vials (10 doses) [Dimensions: 8.5 x 3.8 x 4.5 cm]**

## Binary: PreQual Packaging: Carton of 10 vials (10 doses) [Dimensions: 8.5 x 3.8 x 4.5 cm]

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "description": "Carton of 10 vials (10 doses) [Dimensions: 8.5 x 3.8 x 4.5 cm]",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaaPUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "14.54",
  "height": "3.8",
  "length": "8.5",
  "width": "4.5",
  "primaryContainers": "10"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
