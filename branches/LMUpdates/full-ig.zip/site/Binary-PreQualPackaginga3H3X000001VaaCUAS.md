# PreQual Packaging: Carton of 10 tubes [Dimensions: 12.8 x 8.7 x 2.5 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Carton of 10 tubes [Dimensions: 12.8 x 8.7 x 2.5 cm]**

## Binary: PreQual Packaging: Carton of 10 tubes [Dimensions: 12.8 x 8.7 x 2.5 cm]

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "description": "Carton of 10 tubes [Dimensions: 12.8 x 8.7 x 2.5 cm]",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaaCUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "27.84",
  "height": "8.7",
  "length": "12.8",
  "width": "2.5",
  "primaryContainers": "1"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
