# PreQual Document: Container Photo-pq_72_EuvaxB_10dose%28adult%29_LG_carton%26vial_image - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_72_EuvaxB_10dose%28adult%29_LG_carton%26vial_image**

## Binary: PreQual Document: Container Photo-pq_72_EuvaxB_10dose%28adult%29_LG_carton%26vial_image

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i2ZZYAY"
  },
  "documentName": "Container Photo-pq_72_EuvaxB_10dose%28adult%29_LG_carton%26vial_image",
  "documentType": "Photo",
  "versionId": "068NN000005ylu6YAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
