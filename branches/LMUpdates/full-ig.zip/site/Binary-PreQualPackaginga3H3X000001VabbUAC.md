# PreQual Packaging: 24 cartons of 50 vials (1200 vials/12000 doses) [Dimensions 60x48x41 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: 24 cartons of 50 vials (1200 vials/12000 doses) [Dimensions 60x48x41 cm]**

## Binary: PreQual Packaging: 24 cartons of 50 vials (1200 vials/12000 doses) [Dimensions 60x48x41 cm]

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "description": "24 cartons of 50 vials (1200 vials/12000 doses) [Dimensions 60x48x41 cm]",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VabbUAC"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "volume": "60 x 48 x 41 cm",
  "totalDoses": "12000",
  "totalContainers": "1200"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
