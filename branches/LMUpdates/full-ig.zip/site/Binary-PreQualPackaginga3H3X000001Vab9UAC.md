# PreQual Packaging: Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0 cm]**

## Binary: PreQual Packaging: Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0 cm]

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "description": "Carton of 50 vials (active)(50 doses) [Dimensions 18.5x9.5x6.0 cm]",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001Vab9UAC"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "21.09",
  "height": "9.5",
  "length": "18.5",
  "width": "6.0",
  "primaryContainers": "50"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
