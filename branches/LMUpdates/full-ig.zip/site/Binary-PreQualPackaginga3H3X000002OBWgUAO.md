# PreQual Packaging: Box of 300 vials (300 doses). Dimensions: 31 x 19 x 9.3 cm - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Box of 300 vials (300 doses). Dimensions: 31 x 19 x 9.3 cm**

## Binary: PreQual Packaging: Box of 300 vials (300 doses). Dimensions: 31 x 19 x 9.3 cm

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "description": "Box of 300 vials (300 doses). Dimensions: 31 x 19 x 9.3 cm",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000002OBWgUAO"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "volume": "31 x 19 x 9.3",
  "totalDoses": "300",
  "totalContainers": "300"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
