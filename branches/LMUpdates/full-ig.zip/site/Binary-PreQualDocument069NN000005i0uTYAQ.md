# PreQual Document: Container Photo-pq_68_317_BCG_JBL_vial%26ampoule_image-2020 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_68_317_BCG_JBL_vial%26ampoule_image-2020**

## Binary: PreQual Document: Container Photo-pq_68_317_BCG_JBL_vial%26ampoule_image-2020

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i0uTYAQ"
  },
  "documentName": "Container Photo-pq_68_317_BCG_JBL_vial%26ampoule_image-2020",
  "documentType": "Photo",
  "versionId": "068NN000005ykGbYAI",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
