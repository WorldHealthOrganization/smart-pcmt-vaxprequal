# PreQual Site: GlaxoSmithKline Biologicals SA - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Site: GlaxoSmithKline Biologicals SA**

## Binary: PreQual Site: GlaxoSmithKline Biologicals SA

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail",
  "siteOrganizationId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p3gQAA"
  },
  "siteOrganizationName": "GlaxoSmithKline Biologicals SA",
  "addressLine1": "20 Avenue Fleming 1300 Wavre  Belgium",
  "city": "Wavre",
  "country": "Belgium",
  "postalCode": "B-1300",
  "siteStatus": "Accepted",
  "siteActivity": "FVPManufacture"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
