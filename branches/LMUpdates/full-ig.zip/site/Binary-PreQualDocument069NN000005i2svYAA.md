# PreQual Document: Container Photo-pq_66_YF_20dose_IPD_carton%2Bampl_image_580 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_66_YF_20dose_IPD_carton%2Bampl_image_580**

## Binary: PreQual Document: Container Photo-pq_66_YF_20dose_IPD_carton%2Bampl_image_580

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i2svYAA"
  },
  "documentName": "Container Photo-pq_66_YF_20dose_IPD_carton%2Bampl_image_580",
  "documentType": "Photo",
  "versionId": "068NN000005ymDRYAY",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
