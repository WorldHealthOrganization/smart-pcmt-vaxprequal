# PreQual Document: FVP-P-111_Rabies_1dose_Sanofi_PI-2026 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: FVP-P-111_Rabies_1dose_Sanofi_PI-2026**

## Example Binary: PreQual Document: FVP-P-111_Rabies_1dose_Sanofi_PI-2026

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i5hCYAQ"
  },
  "documentName": "FVP-P-111_Rabies_1dose_Sanofi_PI-2026",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068Vj00000WSseGIAT",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
