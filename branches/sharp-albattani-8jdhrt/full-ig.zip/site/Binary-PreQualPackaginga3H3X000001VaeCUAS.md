# PreQual Packaging: Carton of 10 vials (10 doses) [Dimensions: 9.0 x 3.8 x 4.5 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Carton of 10 vials (10 doses) [Dimensions: 9.0 x 3.8 x 4.5 cm]**

## Example Binary: PreQual Packaging: Carton of 10 vials (10 doses) [Dimensions: 9.0 x 3.8 x 4.5 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaeCUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "15.39",
  "description": "Carton of 10 vials (10 doses) [Dimensions: 9.0 x 3.8 x 4.5 cm]",
  "height": "3.8",
  "length": "9.0",
  "width": "4.5",
  "primaryContainers": "10"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
