# PreQual Packaging: Carton of 24 vials (active)(240 doses) [Dimensions 14.5x10.8x4.5] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Carton of 24 vials (active)(240 doses) [Dimensions 14.5x10.8x4.5]**

## Example Binary: PreQual Packaging: Carton of 24 vials (active)(240 doses) [Dimensions 14.5x10.8x4.5]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VadBUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "2.94",
  "description": "Carton of 24 vials (active)(240 doses) [Dimensions 14.5x10.8x4.5]",
  "height": "10.8",
  "length": "14.5",
  "width": "4.5",
  "primaryContainers": "24"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
