# PreQual Packaging: Box of 40 cartons of 25 vials [1000 vials/ 20000 doses] [Dimensions: 57.0 x 46.0 x 37.5 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Box of 40 cartons of 25 vials [1000 vials/ 20000 doses] [Dimensions: 57.0 x 46.0 x 37.5 cm]**

## Example Binary: PreQual Packaging: Box of 40 cartons of 25 vials [1000 vials/ 20000 doses] [Dimensions: 57.0 x 46.0 x 37.5 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001Vae9UAC"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Box of 40 cartons of 25 vials [1000 vials/ 20000 doses] [Dimensions: 57.0 x 46.0 x 37.5 cm]",
  "volume": "57.0 x 46.0 x 37.5 cm",
  "totalDoses": "20000",
  "totalContainers": "1000"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
