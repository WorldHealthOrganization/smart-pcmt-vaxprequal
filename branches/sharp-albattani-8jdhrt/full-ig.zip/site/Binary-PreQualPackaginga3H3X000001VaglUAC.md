# PreQual Packaging: 50 vial carton (200 doses) [dimensions: 17.9 x 9.2 x 4.3 cm] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: 50 vial carton (200 doses) [dimensions: 17.9 x 9.2 x 4.3 cm]**

## Example Binary: PreQual Packaging: 50 vial carton (200 doses) [dimensions: 17.9 x 9.2 x 4.3 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaglUAC"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "3.54",
  "description": "50 vial carton (200 doses) [dimensions: 17.9 x 9.2 x 4.3 cm]",
  "height": "9.2",
  "length": "17.9",
  "width": "4.3",
  "primaryContainers": "50"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
