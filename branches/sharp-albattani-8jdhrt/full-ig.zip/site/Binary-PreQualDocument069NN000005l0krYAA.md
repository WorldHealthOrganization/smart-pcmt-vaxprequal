# PreQual Document: pq_315_Euvichol-Plus_1dose_EuBiol_tube%26carton_image - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: pq_315_Euvichol-Plus_1dose_EuBiol_tube%26carton_image**

## Example Binary: PreQual Document: pq_315_Euvichol-Plus_1dose_EuBiol_tube%26carton_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005l0krYAA"
  },
  "documentName": "pq_315_Euvichol-Plus_1dose_EuBiol_tube%26carton_image",
  "documentType": "PhotoMainImage",
  "versionId": "068NN0000061maDYAQ",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
