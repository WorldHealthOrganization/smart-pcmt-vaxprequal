# PreQual Packaging: Carton of 50 ampoules (diluent) [Dimensions 10.5x8.7x15.0] - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Carton of 50 ampoules (diluent) [Dimensions 10.5x8.7x15.0]**

## Example Binary: PreQual Packaging: Carton of 50 ampoules (diluent) [Dimensions 10.5x8.7x15.0]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VacCUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "Diluent",
  "coldChainVolume": "5.48",
  "description": "Carton of 50 ampoules (diluent) [Dimensions 10.5x8.7x15.0]",
  "height": "8.7",
  "length": "10.5",
  "width": "15.0",
  "primaryContainers": "50"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
