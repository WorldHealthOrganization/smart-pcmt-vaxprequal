# PreQual Document: VPSAR (Vaccine Public Summary Assessment Report)-FVP-244_bOPV_bharat_vpsar - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: VPSAR (Vaccine Public Summary Assessment Report)-FVP-244_bOPV_bharat_vpsar**

## Example Binary: PreQual Document: VPSAR (Vaccine Public Summary Assessment Report)-FVP-244_bOPV_bharat_vpsar

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005j1eeYAA"
  },
  "documentName": "VPSAR (Vaccine Public Summary Assessment Report)-FVP-244_bOPV_bharat_vpsar",
  "documentType": "VSPAR",
  "versionId": "068NN000005zmL3YAI",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
