<?php
function Redirect($url)
{
  header('Location: ' . $url, true, 302);
  exit();
}

$accept = $_SERVER['HTTP_ACCEPT'];
if (strpos($accept, 'application/json+fhir') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-DiphtheriaTetanusPertussProduct2b5b9b19671826d92dff00f622588487.json2');
elseif (strpos($accept, 'application/fhir+json') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-DiphtheriaTetanusPertussProduct2b5b9b19671826d92dff00f622588487.json1');
elseif (strpos($accept, 'json') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-DiphtheriaTetanusPertussProduct2b5b9b19671826d92dff00f622588487.json');
elseif (strpos($accept, 'application/xml+fhir') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-DiphtheriaTetanusPertussProduct2b5b9b19671826d92dff00f622588487.xml2');
elseif (strpos($accept, 'application/fhir+xml') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-DiphtheriaTetanusPertussProduct2b5b9b19671826d92dff00f622588487.xml1');
elseif (strpos($accept, 'html') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-DiphtheriaTetanusPertussProduct2b5b9b19671826d92dff00f622588487.html');
else 
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-DiphtheriaTetanusPertussProduct2b5b9b19671826d92dff00f622588487.xml');
?>
    
You should not be seeing this page. If you do, PHP has failed badly.
