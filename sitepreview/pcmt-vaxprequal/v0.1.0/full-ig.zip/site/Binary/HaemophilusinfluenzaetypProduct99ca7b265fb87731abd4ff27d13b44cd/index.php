<?php
function Redirect($url)
{
  header('Location: ' . $url, true, 302);
  exit();
}

$accept = $_SERVER['HTTP_ACCEPT'];
if (strpos($accept, 'application/json+fhir') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-HaemophilusinfluenzaetypProduct99ca7b265fb87731abd4ff27d13b44cd.json2');
elseif (strpos($accept, 'application/fhir+json') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-HaemophilusinfluenzaetypProduct99ca7b265fb87731abd4ff27d13b44cd.json1');
elseif (strpos($accept, 'json') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-HaemophilusinfluenzaetypProduct99ca7b265fb87731abd4ff27d13b44cd.json');
elseif (strpos($accept, 'application/xml+fhir') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-HaemophilusinfluenzaetypProduct99ca7b265fb87731abd4ff27d13b44cd.xml2');
elseif (strpos($accept, 'application/fhir+xml') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-HaemophilusinfluenzaetypProduct99ca7b265fb87731abd4ff27d13b44cd.xml1');
elseif (strpos($accept, 'html') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-HaemophilusinfluenzaetypProduct99ca7b265fb87731abd4ff27d13b44cd.html');
else 
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-HaemophilusinfluenzaetypProduct99ca7b265fb87731abd4ff27d13b44cd.xml');
?>
    
You should not be seeing this page. If you do, PHP has failed badly.
